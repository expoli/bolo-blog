title: 极路由（OpenWrt）配置DHCP自动指配DNS
date: '2020-10-01 13:27:33'
updated: '2020-10-01 13:28:38'
tags: [Openwrt]
permalink: /articles/2020/10/01/1601530053926.html
---
![photo202009231714542.jpg](https://expoli.tech/image/fLx_photo_2020-09-23_17-14-54+28229.jpg)

极路由的DHCP设置中无法手动设置网关和DNS，所以只好手动修改配置文件。

# 打开'开发者模式'

在极路由后台的云插件市场找到开发者模式插件，直接安装，连接方式与用户名密码插件详细信息已经给出。

![image.png](https://expoli.tech/image/uAZ_image.png)

# 固件基于OpenWrt

## 修改DHCP配置文件

### 备份原始配置文件

```bash
cd /etc/config/
cp dhcp dhcp.back

```

### 分析配置文件

1. 原始配置文件如下：可以看出有两个`lan`那么我们究竟需要修改哪个配置呢。

```
config dnsmasq
	option domainneeded '0'
	option boguspriv '1'
	option filterwin2k '0'
	...

config dhcp 'lan'
	option interface 'lan'
	option start '100'
	option limit '150'
	option leasetime '12h'
	option force '1'
	option ignore '0'

config dhcp 'wan'
	option interface 'wan'
	option ignore '1'

config dhcp 'lan1'
	option interface 'lan1'
	option start '100'
	option limit '150'
	option leasetime '12h'
	option force '1'

```

2. ip命令查看接口信息

可以看到，`br-lan`与`br-lan1`是属于不同网段的，而我们现在所使用的网段为`192.168.199.1/24`，所以我们可以确定我们所需要修改的就是`lan`的配置网段。

```
ip a


28: br-lan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default 
    link/ether d4:00 brd ff:ff:ff:ff:ff:ff
    inet 192.168.199.1/24 brd 192.168.199.255 scope global br-lan
       valid_lft forever preferred_lft forever
    inet6 fe80::d6ee:7ff:fe62:a784/64 scope link 
       valid_lft forever preferred_lft forever

30: br-lan1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default 
    link/ether d4:00 brd ff:ff:ff:ff:ff:ff
    inet 192.168.200.1/24 brd 192.168.200.255 scope global br-lan1
       valid_lft forever preferred_lft forever
    inet6 fe80::d6ee:7ff:fe62:a786/64 scope link 
       valid_lft forever preferred_lft forever
```

### 修改配置文件

DHCP中的DNS与网关都是由DHCP配置文件中的`dhcp_option`进行配置的。

启动代号为`3`的代表默认网关的配置，代号为`6`的配置项为DNS的配置项。

```bash
config dhcp 'lan'
	option interface 'lan'
	option start '100'
	option limit '150'
	option leasetime '12h'
	option force '1'
	option ignore '0'
####################### 下面的为手动添加的项目
        list dhcp_option "3,192.168.199.1 6,192.168.199.216,80.67.188.188,80.67.169.12"
        list dns         "2001:913::8"
        list dns         "2001:910:800::12"
```

## 重启dnsmasq服务

```bash
/etc/inid.d/dnsmasq restart
```

## 重新连接网络即可

可以看到已经能够获取到相应的预设DNS了。

![image.png](https://expoli.tech/image/JBw_image.png)

# 参考文献

https://openwrt.org/zh/docs/guide-user/base-system/dhcp_configuration
