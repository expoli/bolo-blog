title: 自动化部署学习之——sonar 与 jenkins 结合
date: '2019-08-18 14:43:51'
updated: '2019-08-19 21:52:28'
tags: [运维, Sonar, Jenkins]
permalink: /articles/2019/08/18/1566110631575.html
---
![](https://img.hacpai.com/bing/20180321.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# jenkins实战——sonar与jenkins结合

## 1. 环境要求

### 1.1 SonarQube 与 Jenkins安装并启动完成

Jenkins 插件要求

- SonarQube Scanner

## 2. 设置 Jenkins 与 Sonarqube 进行通信

### 2.1 修改系统设置

![7-jenkinssonarjenkins8.png](http://tc.expoli.tech/images/2019/08/19/7-jenkinssonarjenkins8.png)

### 1.2 在系统设置内添加 Sonar server

- 名字可以自己起一个自己认为比较好看的名字。
- Server URL 填入自己的 sonarqube 的URL
- 认证 token 留空
- 点击保存即可

![7-jenkinssonarjenkins9.png](http://tc.expoli.tech/images/2019/08/19/7-jenkinssonarjenkins9.png)

## 2. 添加 SonarQube Scanner

### 3.1 打开全局工具进行配置

![7-jenkinssonarjenkins11.png](http://tc.expoli.tech/images/2019/08/19/7-jenkinssonarjenkins11.png)

### 3.2 添加SonarQube Scanner

- Name 自己填写
- 在这里我选择自动安装、如果不愿自动安装，可以手动安装之后将 SonarQube 的安装路径进行填写。
- 可以选择自动安装的版本

![7-jenkinssonarjenkins12.png](http://tc.expoli.tech/images/2019/08/19/7-jenkinssonarjenkins12.png)

![7-jenkinssonarjenkins1.png](http://tc.expoli.tech/images/2019/08/18/7-jenkinssonarjenkins1.png)

## 3. 配置项目使用 SonarQuber

### 3.1 打开配置面板

点击名字旁边的小箭头、点击下拉菜单的 Configure 按钮

![7-jenkinssonarjenkins10.png](http://tc.expoli.tech/images/2019/08/19/7-jenkinssonarjenkins10.png)

### 3.2 添加 build 内 SonarQube

![7-jenkinssonarjenkins2.png](http://tc.expoli.tech/images/2019/08/18/7-jenkinssonarjenkins2.png)

### 3.3 配置 build 内 SonarQube、添加构建参数

```yaml
sonar.projectKey=auto-deploy-demo
sonar.projectName=auto-deploy-demo
sonar.projectVersion=1.0
sonar.sources=.
sonar.sourceEncoding=UTF-8
```

![7-jenkinssonarjenkins13.png](http://tc.expoli.tech/images/2019/08/19/7-jenkinssonarjenkins13.png)

### 3.4 保存配置

## 4. 进行测试

### 4.1 进行立即构建测试

点击 build now 进行测试

![7-jenkinssonarjenkins14.png](http://tc.expoli.tech/images/2019/08/19/7-jenkinssonarjenkins14.png)

### 4.2 查看控制台输出观察构建状态

![7-jenkinssonarjenkins15.png](http://tc.expoli.tech/images/2019/08/19/7-jenkinssonarjenkins15.png)

### 4.3 等待构建结束查看 SonarQube 报表

![7-jenkinssonarjenkins16.png](http://tc.expoli.tech/images/2019/08/19/7-jenkinssonarjenkins16.png)

## 5. 设置构建完成后的动作

### 5.1 发送邮件

### 5.2 执行一个shell脚本

1. 遇到权限问题、可以将 Jenkins 用户加入到 soduers 文件内部、以便于执行 sudo 

```bash
jenkins ALL=(ALL) NOPASSWD: /usr/bin/ssh
```

2. 遇到 使用 sudo 需要一个 tty 的时候可以将 /etc/sudoers 的注释掉

```bash
Defaults requiretyy
```

## 6. 添加构建后动作

### 6.1 构建完成后开始构建另一项工程

![7-jenkinssonarjenkins3.png](http://tc.expoli.tech/images/2019/08/18/7-jenkinssonarjenkins3.png)

## 7. 安装构建流水线插件 Build Pipeline

### 7.1 新建 buid-pipeline 视图

![7-jenkinssonarjenkins4.png](http://tc.expoli.tech/images/2019/08/18/7-jenkinssonarjenkins4.png)

![7-jenkinssonarjenkins5.png](http://tc.expoli.tech/images/2019/08/18/7-jenkinssonarjenkins5.png)

### 7.2 配置相关信息

![7-jenkinssonarjenkins6.png](http://tc.expoli.tech/images/2019/08/18/7-jenkinssonarjenkins6.png)

### 7.3 查看效果

查看 pipeline 视图、可以很直观的看出构建的流程、同时也可以很方便的打开控制台、查看输出便于排错。

![7-jenkinssonarjenkins7.png](http://tc.expoli.tech/images/2019/08/18/7-jenkinssonarjenkins7.png)
