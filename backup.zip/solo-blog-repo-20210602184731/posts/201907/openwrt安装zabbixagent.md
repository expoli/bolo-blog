title: openwrt 安装 zabbix-agent
date: '2019-07-30 13:47:08'
updated: '2019-08-19 19:49:41'
tags: [Openwrt, zabbix]
permalink: /articles/2019/07/30/1564656214475.html
---
# openwrt 安装 zabbix-agent

## 1. 更新数据

```bash
opkg update
opkg install zabbix-agentd
```
## 2. 修改配置文件

```bash
# 日志类型、可以守护进程方式后台运行
LogType=system
# zabbix server IP 、被动模式、即允许向我询问状态的 zabbix-server IP地址
Server=192.168.0.*
# 被动模式
StartAgents=1
# 主动模式的 zabbix server IP地址与端口
ServerActive=192.168.0.*:10051
# zabbix-server 上配置的主机名称
Hostname=openwrt-route-********
# 配置文件路径
Include=/etc/zabbix_agentd.conf.d/
```

### 1. server name
![2019-03-30-openwrt-install-zabbix-agent547fa087d8daf15b.png](http://tc.expoli.tech/images/2019/07/30/2019-03-30-openwrt-install-zabbix-agent547fa087d8daf15b.png)

### 2. 配置文件

![2019-03-30-openwrt-install-zabbix-agent.png](http://tc.expoli.tech/images/2019/07/30/2019-03-30-openwrt-install-zabbix-agent.png)