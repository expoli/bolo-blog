title: 我在 GitHub 上的开源项目
date: '2021-04-02 16:36:19'
updated: '2021-04-02 16:36:19'
tags: [开源, GitHub]
permalink: /github
---
![GitHub Repo](/images/github_repo.jpg)

## Github Stats

![Github Stats](https://github-readme-stats.vercel.app/api?username=expoli&show_icons=true) 

## 所有开源项目
| 仓库 |  项目简介 | Stars | fork | 编程语言 |
| ---- | ---- | ---- | ---- | ---- |
| [docker-compose-files](https://github.com/expoli/docker-compose-files) | 此项目是对一些实用软件的 docker-compose 化模板，旨在提供开箱即用的使用体验。欢迎大家提供宝贵建议！ | 22 | 10 | HTML|
| [bolo-blog](https://github.com/expoli/bolo-blog) | ✍️ 糖醋鱼的小破站 - 🐠生成长记 | 2 | 0 | |
| [docker-hub-image-php](https://github.com/expoli/docker-hub-image-php) | Self-compiled php mirror Basic mirror: php:7.2-fpm adds some basic PHP components such as gd \ mysqli \ pdo \ pdo_mysql \ zip | 2 | 1 | Dockerfile|
| [DrawLotsNew](https://github.com/expoli/DrawLotsNew) | DrawLotsNew 基于 DrawLots mirai 插件进行开发 | 1 | 0 | Kotlin|
| [bolo-docker-image-builder](https://github.com/expoli/bolo-docker-image-builder) | bolo-docker builder | 0 | 0 | |
| [clash-docker-image-builder](https://github.com/expoli/clash-docker-image-builder) |  | 0 | 0 | |
| [computer-systems-a-programmer-s-perspective](https://github.com/expoli/computer-systems-a-programmer-s-perspective) | 深入理解计算机系统第三版-练习题 | 0 | 0 | C|
| [Data-Structure-Learn](https://github.com/expoli/Data-Structure-Learn) | Data-Structure-Learn | 0 | 0 | C++|
| [dnscrypt-server-docker-image-builder](https://github.com/expoli/dnscrypt-server-docker-image-builder) | dnscrypt-server docker image build repository, support arm | 0 | 0 | |
| [dnsmasq-server](https://github.com/expoli/dnsmasq-server) | dnsmasq server docker image | 0 | 0 | Dockerfile|
| [Docker-install-menu-bash](https://github.com/expoli/Docker-install-menu-bash) | Docker install menu bash can run in centos, ubuntu and debian | 0 | 0 | Shell|
| [dotfiles](https://github.com/expoli/dotfiles) |  | 0 | 0 | |
| [Electronic-system-practice](https://github.com/expoli/Electronic-system-practice) | Electronic system practice 郑州大学电子系统设计实践 | 0 | 0 | Python|
| [expoli](https://github.com/expoli/expoli) |  | 0 | 1 | |
| [gopl.io](https://github.com/expoli/gopl.io) |  | 0 | 0 | Go|
| [Learn-tensorflow](https://github.com/expoli/Learn-tensorflow) | https://www.tensorflow.org/ | 0 | 0 | Python|
