title: Windows 挂载 WebDAV
date: '2020-12-30 19:18:18'
updated: '2022-09-15 09:36:41'
tags: [WebDAV, Windows, raidrive]
permalink: /articles/2020/12/30/1609327097930.html
---
![image.png](https://oss.expoli.tech/img/W6X_image.png)

# Windows 挂载 WebDAV

## 推荐方式（[raidrive](https://www.raidrive.com/)）

官网地址：https://www.raidrive.com/

![image.png](https://oss.expoli.tech/img/RGN_image.png)

### 配置 webdav

![webdavnewdrive.png](https://oss.expoli.tech/img/sao_webdav_newdrive.png)

## 方法一 使用文件管理器映射网络磁盘

1. 右键我的电脑->选择映射网络驱动器
2. 选择一个你喜欢的盘符（一般默认是Z）
3. 输入你的 WebDav 连接地址，例如: `https://example.com/nextcloud/remote.php/dav/files/USERNAME/`

> 对于受SSL保护的服务器，请选中“登录时重新连接”以确保映射在以后的重新启动后是仍然可用。如果需要以其他用户身份连接到 WebDAV 服务器，请选中“使用其他凭据连接”。

![explorerwebdav.png](https://oss.expoli.tech/img/qPK_explorer_webdav.png)

4. 点击完成即可在文件管理器中查看到所映射的网络驱动器。

![dwVimage.png](https://oss.expoli.tech/img/VWX_dwV_image.png)

### 注意

**因为WebDAV协议不支持查询硬盘容量，所以所挂载的硬盘容量与C盘容量一致！！**

## 方法二 使用命令映射驱动器

此方法在进行测试时发现根据Windows版本的不同、使用命令映射的网络驱动器无法在文件管理器中显示，可以尝试在任务管理器中重启 `explorer`。

1. 打开命令提示符窗口
2. 按照以下示例输入命令 `https://<drive_path>/remote.php/dav/files/USERNAME/` 为自己相应的WebDAV URL。

```
net use Z: https://<drive_path>/remote.php/dav/files/USERNAME/ /user:youruser yourpassword
```

## 已知的一些问题

### 问题一 Error 0x800700DF

您收到以下错误信息：错误0x800700DF：文件大小超出允许的限制，无法保存。

Windows限制了从WebDAV共享传输或传输到WebDAV共享的文件的最大大小。可以通过修改注册表 **HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WebClient\Parameters** 中的**FileSizeLimitInBytes** 值来解决。

要将限制增加到最大值4GB，请选择“**Decimal** 十进制”，输入值 `4294967295`，然后重新启动Windows或重新启动WebClient服务。

![image.png](https://oss.expoli.tech/img/C9g_image.png)

![image.png](https://oss.expoli.tech/img/BKU_image.png)

### 问题二 找不到网络名

> 发生系统错误 67。

> 找不到网络名。

**局域网里的WebDAV没开HTTPS不能挂载**

Solution：打开注册表编辑器，定位到`HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\WebClient\Parameters`，修改键`BasicAuthLevel`值为`2`，即同时允许HTTP与HTTPS。
