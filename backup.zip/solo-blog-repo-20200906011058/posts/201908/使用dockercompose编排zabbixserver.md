title: 使用 docker-compose 编排 zabbix-server
date: '2019-08-01 17:47:08'
updated: '2020-04-03 09:28:58'
tags: [Docker, docker-compose, zabbix]
permalink: /articles/2019/08/01/1564656221752.html
---
![](https://img.hacpai.com/bing/20190221.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 使用 docker-compose 编排 zabbix-server

## 1. docker-compose.yaml

```yaml
version: '2'
services:
  zabbix-server:
    image: zabbix/zabbix-server-mysql
    restart: always
    ports:
      - "10051:10051"
    volumes:
      - /etc/localtime:/etc/localtime:ro
      - /etc/timezone:/etc/timezone:ro 
      - ./zbx_env/usr/lib/zabbix/alertscripts:/usr/lib/zabbix/alertscripts:ro
      - ./zbx_env/usr/lib/zabbix/externalscripts:/usr/lib/zabbix/externalscripts:ro
      - ./zbx_env/var/lib/zabbix/modules:/var/lib/zabbix/modules:ro
      - ./zbx_env/var/lib/zabbix/enc:/var/lib/zabbix/enc:ro
      - ./zbx_env/var/lib/zabbix/ssh_keys:/var/lib/zabbix/ssh_keys:ro
      - ./zbx_env/var/lib/zabbix/mibs:/var/lib/zabbix/mibs:ro
    volumes_from:
      - zabbix-snmptraps:ro
    links:
      - mysql-server:mysql-server
      - zabbix-java-gateway:zabbix-java-gateway
    ulimits:
      nproc: 65535
      nofile:
        soft: 20000
        hard: 40000
    mem_limit: 512m
    env_file:
      - .env_db_mysql
      - .env_srv
    container_name: "zabbix-server-mysql"

  zabbix-web-nginx-mysql:
    image: zabbix/zabbix-web-nginx-mysql
    restart: always
    ports:
      - "8081:80"
      - "8443:443"
    links:
      - mysql-server:mysql-server
      - zabbix-server:zabbix-server
    mem_limit: 512m
    volumes:
      - /etc/localtime:/etc/localtime:ro
      - /etc/timezone:/etc/timezone:ro
      - ./zbx_env/etc/ssl/nginx:/etc/ssl/nginx:ro
      - ./simkai.ttf:/usr/share/zabbix/fonts/graphfont.ttf:ro
    env_file:
      - .env_db_mysql
      - .env_web
    container_name: "zabbix-web-nginx-mysql"

  zabbix-agent:
    image: zabbix/zabbix-agent
    restart: always
    ports:
      - "10050:10050"
    volumes:
      - /etc/localtime:/etc/localtime:ro
      - /etc/timezone:/etc/timezone:ro
      - ./zbx_env/etc/zabbix/zabbix_agentd.d:/etc/zabbix/zabbix_agentd.d:ro
      - ./zbx_env/var/lib/zabbix/modules:/var/lib/zabbix/modules:ro
      - ./zbx_env/var/lib/zabbix/enc:/var/lib/zabbix/enc:ro
      - ./zbx_env/var/lib/zabbix/ssh_keys:/var/lib/zabbix/ssh_keys:ro
    links:
      - zabbix-server:zabbix-server
    env_file:
      - .env_agent
    privileged: true
    pid: "host"
    container_name: "zabbix-server-agent"

  zabbix-java-gateway:
    image: zabbix/zabbix-java-gateway
    restart: always
    ports:
      - "10052:10052"
    env_file:
      - .env_java
    container_name: "zabbix-java-gateway"
 
  zabbix-snmptraps:
    image: zabbix/zabbix-snmptraps
    restart: always
    ports:
      - "162:162/udp"
    volumes:
      - ./zbx_env/var/lib/zabbix/snmptraps:/var/lib/zabbix/snmptraps:rw
    container_name: "zabbix-snmptraps"

  mysql-server:
    image: mysql:5.7
    command: [mysqld, --character-set-server=utf8, --collation-server=utf8_bin]
    restart: always
    volumes_from:
      - db_data_mysql
    volume_driver: local
    env_file:
      - .env_db_mysql
    container_name: "mysql-for-zabbix"

  db_data_mysql:
      image: busybox
      volumes:
        - ./zbx_env/var/lib/mysql:/var/lib/mysql:rw

networks:
  default:
    external: 
      name: your_net
```

## 2. `.env_agent`

```bash
# ZBX_SOURCEIP=
# ZBX_DEBUGLEVEL=3
# ZBX_ENABLEREMOTECOMMANDS=0
# ZBX_LOGREMOTECOMMANDS=0
ZBX_SERVER_HOST=zabbix-server
# ZBX_PASSIVE_ALLOW=true
# ZBX_PASSIVESERVERS=
# ZBX_ACTIVE_ALLOW=true
# ZBX_ACTIVESERVERS=
# ZBX_LISTENIP=
# ZBX_STARTAGENTS=3
ZBX_HOSTNAME=zabbix-server
# ZBX_HOSTNAMEITEM=system.hostname
# ZBX_METADATA=
# ZBX_METADATAITEM=
# ZBX_REFRESHACTIVECHECKS=120
# ZBX_BUFFERSEND=5
# ZBX_BUFFERSIZE=100
# ZBX_MAXLINESPERSECOND=20
# ZBX_ALIAS=""
# ZBX_TIMEOUT=3
# ZBX_UNSAFEUSERPARAMETERS=0
# ZBX_LOADMODULE="dummy1.so,dummy2.so,dummy10.so"
# ZBX_TLSCONNECT=unencrypted
# ZBX_TLSACCEPT=unencrypted
# ZBX_TLSCAFILE=
# ZBX_TLSCRLFILE=
# ZBX_TLSSERVERCERTISSUER=
# ZBX_TLSSERVERCERTSUBJECT=
# ZBX_TLSCERTFILE=
# ZBX_TLSKEYFILE=
# ZBX_TLSPSKIDENTITY=
# ZBX_TLSPSKFILE=
```

## 3. `.env_db_mysql`

```bash
DB_SERVER_HOST=mysql-server
DB_SERVER_PORT=3306
# MYSQL_USER=zabbix
MYSQL_USER=zabbix
# MYSQL_PASSWORD=zabbix
MYSQL_PASSWORD=zabbix
# MYSQL_ROOT_PASSWORD=
MYSQL_ROOT_PASSWORD=root_passwd
# MYSQL_ALLOW_EMPTY_PASSWORD=false
# MYSQL_DATABASE=zabbix
MYSQL_DATABASE=zabbix
```

## 4. `.env_java `

```bash
ZBX_START_POLLERS=5
ZBX_TIMEOUT=3
# Possible values: trace, debug, info, want, error, all, off
ZBX_DEBUGLEVEL=info
```

## 5. `.env_srv`

```bash
# ZBX_LISTENIP=
# ZBX_HISTORYSTORAGEURL=http://elasticsearch:9200/ # Available since 3.4.5
# ZBX_HISTORYSTORAGETYPES=uint,dbl,str,log,text # Available since 3.4.5
# ZBX_DEBUGLEVEL=3
# ZBX_STARTPOLLERS=5
# ZBX_IPMIPOLLERS=0
# ZBX_STARTPREPROCESSORS=3 # Available since 3.4.0
# ZBX_STARTPOLLERSUNREACHABLE=1
# ZBX_STARTTRAPPERS=5
# ZBX_STARTPINGERS=1
# ZBX_STARTDISCOVERERS=1
# ZBX_STARTHTTPPOLLERS=1
# ZBX_STARTTIMERS=1
# ZBX_STARTESCALATORS=1
# ZBX_STARTALERTERS=3 # Available since 3.4.0
ZBX_JAVAGATEWAY_ENABLE=true
# ZBX_JAVAGATEWAY=zabbix-java-gateway
# ZBX_JAVAGATEWAYPORT=10052
ZBX_STARTJAVAPOLLERS=5
# ZBX_STARTVMWARECOLLECTORS=0
# ZBX_VMWAREFREQUENCY=60
# ZBX_VMWAREPERFFREQUENCY=60
# ZBX_VMWARECACHESIZE=8M
# ZBX_VMWARETIMEOUT=10
ZBX_ENABLE_SNMP_TRAPS=true
# ZBX_SOURCEIP=
# ZBX_HOUSEKEEPINGFREQUENCY=1
# ZBX_MAXHOUSEKEEPERDELETE=5000
# ZBX_SENDERFREQUENCY=30
# ZBX_CACHESIZE=8M
# ZBX_CACHEUPDATEFREQUENCY=60
# ZBX_STARTDBSYNCERS=4
# ZBX_HISTORYCACHESIZE=16M
# ZBX_HISTORYINDEXCACHESIZE=4M
# ZBX_TRENDCACHESIZE=4M
# ZBX_VALUECACHESIZE=8M
# ZBX_TIMEOUT=4
# ZBX_TRAPPERIMEOUT=300
# ZBX_UNREACHABLEPERIOD=45
# ZBX_UNAVAILABLEDELAY=60
# ZBX_UNREACHABLEDELAY=15
# ZBX_LOGSLOWQUERIES=3000
# ZBX_STARTPROXYPOLLERS=1
# ZBX_PROXYCONFIGFREQUENCY=3600
# ZBX_PROXYDATAFREQUENCY=1
# ZBX_LOADMODULE="dummy1.so,dummy2.so,dummy10.so"
# ZBX_TLSCAFILE=
# ZBX_TLSCRLFILE=
# ZBX_TLSCERTFILE=
# ZBX_TLSKEYFILE=
```

## 6. `.env_web`

```bash
ZBX_SERVER_HOST=zabbix-server
ZBX_SERVER_PORT=10051
ZBX_SERVER_NAME=Composed installation
# ZBX_HISTORYSTORAGEURL=http://elasticsearch:9200/ # Available since 3.4.5
# ZBX_HISTORYSTORAGETYPES=['uint', 'dbl', 'str', 'text', 'log'] # Available since 3.4.5
ZBX_MAXEXECUTIONTIME=600
ZBX_MEMORYLIMIT=128M
ZBX_POSTMAXSIZE=16M
ZBX_UPLOADMAXFILESIZE=2M
ZBX_MAXINPUTTIME=300
# Timezone one of: http://php.net/manual/en/timezones.php
PHP_TZ=Asia/Shanghai
```

## 7. 启动测试

```bash
# 确保端口不被占用
docker-compose up -d
```

## 8. 目录结构
![2019-08-01-zabbix-server-docker-compose.png](http://tc.expoli.tech/images/2019/08/01/2019-08-01-zabbix-server-docker-compose.png)
