title: KDE Ctrl-Alt-Backspace无法退出X
date: '2020-04-27 09:22:10'
updated: '2020-04-27 09:22:10'
tags: [Linux, Arch, KDE]
permalink: /articles/2020/04/27/1587950530272.html
---
# KDE Ctrl-Alt-Backspace无法退出X

## 其它发行版的解决方法

一般其它发行版只需要在，`/etc/X11/xorg.conf.d/10-evdev.conf` 文件里，加入下面的句子即可。

但是在KDE中这种方法无效。

```
Section "InputClass"
    Identifier          "Keyboard Defaults"
    MatchIsKeyboard	"yes"
    Option              "XkbOptions" "terminate:ctrl_alt_bksp"
EndSection
```

## KDE 解决方案

1. 打开设置

![](https://oss.expoli.tech/img/20200427090602.png)

2. 依次选择，键盘->高级->配置键盘选项->杀死X服务器的按键序;然后保存应用即可。

![](https://oss.expoli.tech/img/20200427090828.png)

