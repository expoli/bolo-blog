title: wiki.osdev.org 系列之（七）- 我应该按什么顺序做东西？
date: '2022-06-11 10:07:05'
updated: '2022-06-11 21:39:48'
tags: [OS, osdev]
permalink: /articles/2022/06/11/1654913225694.html
---
这是风格问题。您可以从头开始直接深入研究，编写引导扇区，然后编写最小内核，然后从那里构建。您可以跳过引导扇区，并使用像 GRUB 这样的现成引导加载程序（开发自己的引导加载程序是一种宝贵的体验还是浪费时间，这一点有待讨论）。你也可以不按特定顺序写一些零碎的东西，只是在最后把它们放在一起。做这件事可能没有对错之分。如果您想了解一些易于使用的东西（实际上是每个操作系统都必须的），您可以继续阅读。

# 对于初学者

1. 在屏幕上打印字符串和整数（十进制和十六进制）当然是必须的。这是最基本的调试方法之一，实际上我们所有人都经历过 0.01 版中的 kprint() 或 kout。
2. 输出到串口将为你节省大量调试时间。你不必担心由于滚动而丢失信息。你将能够从控制台测试你的操作系统，过滤有趣的调试消息，并自动化一些测试。
3. 拥有一个可以转储寄存器内容(也许还有错误地址)的工作可靠的中断/异常处理系统将非常有用。
4. 规划您的内存映射（虚拟和物理）：决定您希望数据的位置
5. 堆:现阶段在运行时分配内存(malloc和free)几乎是不可能的。应该尽快实现。

一旦这些步骤完成，您是否会在拥有文件系统、多任务处理或模块加载之前尝试拥有一个工作的 GUI 完全取决于你。试着勾勒出什么可能依赖于什么，并以“最小依赖优先”的顺序做事。

例如，GUI 可以依赖文件系统来加载位图或资源，但在您的第一个 GUI 中不一定需要位图。在这种情况下，好的建议是首先设计文件系统的接口（无论是打开/关闭/读/写还是其他），然后按照您喜欢的方式继续，考虑双方的接口。

## 风格极端

OSDev 似乎在 OSDevers（以及他们开发的操作系统）中有“原型”。当然，大多数人对“完整”内核的想法包括下面列出的大部分（如果不是全部的话）项目。

### Lino Commando

*Main article:* [Lino Commando](https://wiki.osdev.org/Lino_Commando "Lino Commando")
DOS时代的“裸体之美”给他留下了深刻的印象。他想要的第一件事是在“>”符号后面有一个闪烁的光标，以便他可以输入命令。不管有没有办法同时启动两个程序：他只需要一个文本编辑器和一个文件系统驱动程序。

### Nick Stacky

*Main article:* [Nick Stacky](https://wiki.osdev.org/Nick_Stacky "Nick Stacky")
他的测试机没有键盘也没有屏幕（没有人需要）。他所需要的只是 NIC（网络接口卡）……大量的 NIC……和一根以太网电缆，以查看他的内核是否响应 ping 并正确路由数据包。当然，他的内核具有强大的多线程和完整的 TCP/IP 堆栈。

### James T. Klik

*Main article:* [James T. Klik](https://wiki.osdev.org/James_T._Klik "James T. Klik")
透过窗口看：看到那个有阿尔法混合和反锯齿字体的背景了吗？看到屏幕的一角了吗？那是 Klik 的开始菜单！嗯，不：我没有所谓的“程序”文件夹，因为我现在无法加载任何应用程序，但这里有一个我的 WidgetToolKit 的 16 项测试用例列表。

### Eleanore Semaphore

*Main article:* [Eleanore Semaphore](https://wiki.osdev.org/Eleanore_Semaphore "Eleanore Semaphore")
在一个到处都是列表的小房间的黑暗角落里工作。自去年以来，她的系统已经有了很大的发展，尽管她能向你展示的一切仍然是一样的：一串A和B以没有明显顺序的方式显示在一个文本控制台上，她用神奇的组合键控制这个控制台。你会听到她谈论她是如何实现组件编程、自动依赖解析以及为她的调度程序实现虚拟时钟算法的。

### Alta Lang

*Main article:* [Alta Lang](https://wiki.osdev.org/Alta_Lang "Alta Lang")

为什么会有人想用 C 语言这样笨拙而古老的东西来编写像操作系统这样复杂的东西呢？ Alta 想要为她的系统提供一些不同的东西：一种更优雅的操作系统的新语言。她花在语言设计上的时间至少和系统设计一样多，希望如果她能将语言设计得足够干净、足够强大，系统就会顺利到位。

### Stan Dard

*Main article:* [Stan Dard](https://wiki.osdev.org/Stan_Dard "Stan Dard")

斯坦知道事情应该是怎样的。这一切都很好地写在标准中。他看到它们如何组合在一起形成一个漂亮的系统，好吧，如果你忽略标准愚蠢的所有部分。他对他所知道的领域有相当完整的实现，对自己不熟悉的领域有一个不太令人印象深刻的代码。

### Richard Theseus

*Main article:* [Richard Theseus](https://wiki.osdev.org/Richard_Theseus "Richard Theseus")

Richard 非常喜欢他目前的操作系统，除了一点：它不是由他编写的。一点一点地，他想用自己的代码替换他当前操作系统的部分。他的最终目标是拥有与他的主机操作系统相同的副本，但要用他的代码。

### Mister Perfect

*Main article:* [Mister Perfect](https://wiki.osdev.org/Mister_Perfect "Mister Perfect")

完美先生想要编写一个完美的操作系统，因为他看到了当前操作系统的所有缺陷。他研究了许多设计和实现的可能性，以确定什么更好。他多次重新开始，以确保质量和完美。

### Andy Microbaum

*Main article:* [Andy Microbaum](https://wiki.osdev.org/Andy_Microbaum "Andy Microbaum")

Andy 是小内核的粉丝，他将在单片内核中完成的许多工作放入用户空间。

### Dizz Tracked

*Main article:* [Dizz Tracked](https://wiki.osdev.org/Dizz_Tracked "Dizz Tracked")

迪兹被不必要的副业分散了注意力。

### Mono Lizzy

*Main article:* [Mono Lizzy](https://wiki.osdev.org/Mono_Lizzy "Mono Lizzy")

Lizzy喜欢把所有的东西都放进一个大的内核里。

### Ideas for new Archetypes

* **Edward Scissorhands** - Sounds like something designed on paper to do everything but completely broken in practice, I see architecture astronauts rather doing vaporware (e.g. you'd never get to see the Scissorhanded implementation the architecture would require)
* **Real Man** - Writes an entire operating system in Assembly, preferably in real mode. Abhors [Quiche Eaters](http://en.wikipedia.org/wiki/Real_Men_Don't_Eat_Quiche) and [Pascal](http://en.wikipedia.org/wiki/Real_Programmers_Don%27t_Use_Pascal).
* **Vizier Studio** - Visual Studio people.
* **Barry Pi** - ARM people.
* **Racing Carl** - Does all in protected mode Assembler and rewrites the latest 3D library and tries to squeeze the last bit of speed out of the code.

### Archetypes to avoid

* **[Cowboy Coder](https://wiki.osdev.org/Cowboy_Coder "Cowboy Coder")** - Someone who eagerly jumps into coding without any plan.
  * 一个在没有任何计划的情况下急切投入编码的人。
* **[Dae Dreamer](https://wiki.osdev.org/Dae_Dreamer "Dae Dreamer")** - Someone who spends all their time day dreaming and reading about operating systems, but hasn't yet started one.
  * 有人把所有的时间都花在做白日梦和阅读关于操作系统的书籍上，但是还没有开始做。
* **[Duct von Tape](https://wiki.osdev.org/Duct_von_Tape "Duct von Tape")** - Someone that reuses a lot of code and combines it into a horrible frankenstein of a project. Or perhaps [lovecraftian](https://wiki.osdev.org/Category:Lovecraftian "Category:Lovecraftian")?
  * 重用大量代码并将其组合成可怕的项目科学怪人的人。
* **[Sir Dunning-Kruger](https://wiki.osdev.org/Sir_Dunning-Kruger "Sir Dunning-Kruger")** - Someone overestimating his/her skills dramatically.
  * 有人高估了他/她的技能。
