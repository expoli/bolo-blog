title: 糖醋鱼的 Linux 工作环境配置方案（2021-07-30）（Arch）系列
date: '2021-07-30 11:01:06'
updated: '2021-07-31 15:53:26'
tags: [Arch, Linux]
permalink: /articles/2021/07/30/1627614066701.html
---
![ArchLinux.png](https://oss.expoli.tech/img/S5H_Arch-Linux.png)

# 1. 适用操作系统（Arch）系列

- EndeavourOS
- Arch
- Manjaro

# 2. 常用软件

## 2.1 输入法

我的桌面环境为 xfce 所以选择的输入法框架为 `fcitx5` 、具体输入法为 [fcitx5-rime](https://archlinux.org/packages/?name=fcitx5-rime) 、具体配置方式 `Archlinux wiki` 很详细、详情参见 [Fcitix5（简体中文）](https://wiki.archlinux.org/title/Fcitx5_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87))

这里补充一个懒人的 `rime` 配置仓库 [https://github.com/wongdean/rime-settings](https://github.com/wongdean/rime-settings)

```shell
cd ~/.local/share/fcitx5/
git clone https://github.com/wongdean/rime-settings
mv rime-settings rime
```

- 默认配置文件为 `~/.local/share/fcitx5/rime/default.custom.yaml` 根据需要进行修改、更多配置请参照官方 `README`

## 2.2 截图工具

- 推荐火焰截图、功能多易用
- xfce 可以直接添加 `flameshot gui` 快捷键命令

```shell
sudo pacman -S flameshot
```

## 2.3 剪切板工具(适用于xfce)

```shell
sudo pacman -S clipman
```

## 2.4 显卡管理工具

- 建议使用 `optimus` 方式

具体配置方式可以参考

1. EndeavourOS

[https://discovery.endeavouros.com/nvidia/optimus-manager-for-nvidia/2021/03/](https://discovery.endeavouros.com/nvidia/optimus-manager-for-nvidia/2021/03/)

2. Arch Linux

[Arch wiki optimus 简体中文](https://wiki.archlinux.org/title/NVIDIA_Optimus_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87))

## 2.5 聊天工具

```shell
sudo pacman -S telegram-desktop
```

## 2.6 虚拟机

- 使用 VirtualBox 的无缝模式、开启一个 win7 用来聊天的感觉还是挺不错的
- 推荐一个微软官方打包好的虚拟机镜像下载地址 [Virtual Machines - Microsoft Edge Developer](https://developer.microsoft.com/en-us/microsoft-edge/tools/vms/)
  - 注意：导入完成后注意关闭自动更新、要不然虚拟机会自动下载并安装更新

```shell
sudo pacman -S virtualbox-ext-oracle virtualbox
```

# 3. 字体配置

## 3.1 中文

- 与 emoji 一样、默认的 Linux 字体是没有完整的中文支持的、所以很多时候会遇到好多显示为◻️的字体，所以需要额外安装字体支持

```shell
sudo pacman -S noto-fonts-cjk
```

## 3.2 emoji

默认的 Linux 字体是没有完整的 emoji 支持的，所以需要额外安装字体

```shell
sudo pacman -S noto-fonts-emoji
```

具体配置方式参考我的这篇文章  [Arch Linux 安装 Emojis（转载）](https://expoli.tech/articles/2020/02/07/1581074240634.html) (2021-07-30 测试通过)

# 4. 开发环境

## 4.1 visual-studio-code

```shell
sudo pacman -S visual-studio-code-bin
```

## 4.2 jetbrains-toolbox^(aur)

- 因为使用了 yay 所以需要完成 `yay` 的安装之后才能使用

```shell
yay -S jetbrains-toolbox
```

## 4.3 docker

```shell
sudo pacman -S docker
```

# 5. 系统工具

## 5.1 yay

- Manjaro 默认自带 yay
- EndeavourOS 默认自带 yay

### 5.1.1 Arch 安装 yay

```shell
$ sudo pacman -S --needed git base-devel
$ git clone https://aur.archlinux.org/yay.git
$ cd yay
$ makepkg -si
```

## 5.2 archlinuxcn

### 5.2.1 修改 `pacman.conf` 配置文件

`vim /etc/pacman.conf`

```shell
[archlinuxcn]
Include = /etc/pacman.d/archlinuxcn-mirrorlist
```

### 5.2.2 添加 `archlinuxcn-mirrorlist` 文件

- [Arch Linux CN Community repo mirrors list](https://github.com/archlinuxcn/mirrorlist-repo)

`vim /etc/pacman.d/archlinuxcn-mirrorlist`

```shell

##
## Arch Linux CN community repository mirrorlist
## Generated on 2021-07-17
##

## Our main server (Amsterdam, the Netherlands) (ipv4, ipv6, http, https)
Server = https://repo.archlinuxcn.org/$arch

## OpenTUNA (China CDN) (ipv4, https)
Server = https://opentuna.cn/archlinuxcn/$arch

## 北京外国语大学 (北京) (ipv4, ipv6, http, https)
Server = https://mirrors.bfsu.edu.cn/archlinuxcn/$arch

## 腾讯云 (Global CDN) (ipv4, http, https)
Server = https://mirrors.cloud.tencent.com/archlinuxcn/$arch

## 网易 (China CDN) (ipv4, http, https)
Server = https://mirrors.163.com/archlinux-cn/$arch

## 阿里云 (Global CDN) (ipv4, http, https)
Server = https://mirrors.aliyun.com/archlinuxcn/$arch

## 华为云 (Global CDN) (ipv4, http, https)
Server = https://repo.huaweicloud.com/archlinuxcn/$arch

## 清华大学 (北京) (ipv4, ipv6, http, https)
Server = https://mirrors.tuna.tsinghua.edu.cn/archlinuxcn/$arch

## 中国科学技术大学 (安徽合肥) (ipv4, ipv6, http, https)
Server = https://mirrors.ustc.edu.cn/archlinuxcn/$arch

## 哈尔滨工业大学 (黑龙江哈尔滨) (ipv4, ipv6, http, https)
Server = https://mirrors.hit.edu.cn/archlinuxcn/$arch

## 浙江大学 (浙江杭州) (ipv4, http, https)
Server = https://mirrors.zju.edu.cn/archlinuxcn/$arch

## 重庆大学 (重庆) (ipv4, ipv6, https)
Server = https://mirrors.cqu.edu.cn/archlinuxcn/$arch

## SJTUG 软件源镜像服务 (上海) (ipv4, https)
Server = https://mirrors.sjtug.sjtu.edu.cn/archlinux-cn/$arch

## 南京大学 (江苏南京) (ipv4, ipv6, http, https)
Server = https://mirrors.nju.edu.cn/archlinuxcn/$arch

## 莞工 GNU/Linux 协会 开源软件镜像站 (广东东莞) (ipv4, https)
Server = https://mirrors.dgut.edu.cn/archlinuxcn/$arch

## NCKU CCNS (Taiwan) (ipv4, http, https)
#Server = https://archlinux.ccns.ncku.edu.tw/archlinuxcn/$arch

## xTom (Hong Kong server) (Hong Kong) (ipv4, ipv6, http, https)
#Server = https://mirror.xtom.com.hk/archlinuxcn/$arch

## xTom (US server) (Fremont, CA, United States) (ipv4, ipv6, http, https)
#Server = https://mirror.xtom.com/archlinuxcn/$arch

## xTom (Netherlands server) (Amsterdam, the Netherlands) (ipv4, ipv6, http, https)
#Server = https://mirror.xtom.nl/archlinuxcn/$arch

## xTom (Germany server) (Dueseeldorf, Germany) (ipv4, ipv6, http, https)
#Server = https://mirror.xtom.de/archlinuxcn/$arch

## xTom (Estonia server) (Tallinn, Estonia) (ipv4, ipv6, http, https)
#Server = https://mirror.xtom.ee/archlinuxcn/$arch

## Open Computing Facility, UC Berkeley (Berkeley, CA, United States) (ipv4, ipv6, http, https)
#Server = https://mirrors.ocf.berkeley.edu/archlinuxcn/$arch
```

### 5.2.3 安装 `archlinuxcn-keyring`

如果不安装此软件、会导致签名校验无法通过、无法安装 `archlinuxcn` 源内部的软件。

## 5.3 keychain

此软件是 Linux 密钥保存后端实现、如果默认没有安装的话、一些开发工具的密码永久保存机制是无法使用的

```shell
sudo pacman -S keychain
```

## 5.4 蓝牙

```shell
sudo pacman -S --needed bluez bluez-utils pulseaudio-bluetooth
```

## 5.5 timeshift

一个非常好用的备份工具、如果文件系统是 `btrfs` 的话、可以使用其 `subvolume` 机制制作快照。

```shell
sudo pacman -S timeshift
```

## 5.6 v2raya

- 一款新出的 `v2ray` 透明代理配置工具、web界面、支持订阅

```shell
sudo pacman -S v2raya
```

## 5.7 os-prober

> 在生成 GRUB 配置文件的时候、为 GRUB 提供查询其他操作系统的支持。

1. 安装

```shell
sudo pacman -S os-prober
```

2. 配置 `grub.conf`

```shell
sudo vim /etc/default/grub
```

在配置文件的最后加上下面的配置

```shell
# Check Other OS
GRUB_DISABLE_OS_PROBER=false
```

3. 重新生成配置文件

```shell
sudo grub-mkconfig -o /boot/grub/grub.cfg
```
