title: 将Google相册导出到阿里云盘(webdav)
date: '2021-07-18 19:11:33'
updated: '2021-07-18 19:14:28'
tags: [Linux, WebDAV]
permalink: /articles/2021/07/18/1626606693060.html
---
![FileBackup.png](https://oss.expoli.tech/img/QhB_File-Backup-.png)

# 分析

## 需求分析

1. Google宣布停止 Google 相册的高画质无限储存容量的服务支持、难免面临着储存空间不足的情况、需要将相册数据取回本地进行备份保存
2. 多地异地保存、防止数据丢失

## 可行性分析

- Google 相册方面

因Google提供数据导出服务，所以能够做到批量导出相册数据，方便快捷

- 阿里云盘方面

阿里云盘拥有不限速服务而且容量足够、有着[第三方 `webdav` 服务支持](https://github.com/zxbu/webdav-aliyundriver)

# 行动

## Google 相册数据导出

关于数据导出问题 Google 已经明确给出 [指导文档](https://support.google.com/accounts/answer/3024190)

### 第 1 步：选择要包含在您的归档文件中的数据

1. 转到[下载您的数据](https://takeout.google.com/)页面。系统会自动选择包含您数据的 Google 产品。
   * 如果您不想下载某个产品中的数据，请取消选中该产品旁边的复选框。
   * 如果对于某个产品，您只想下载其中的部分数据，您或许可以选择一个类似于“![列表](https://lh3.googleusercontent.com/0HZmF-PjS6LzUGN4aXEFbNo_hbtIJxWbjDL9ya6dDY7hWcWKElyRQOhddmKb1WFxqp94=w24 "列表") 已包含所有…数据”的按钮，然后取消选中不想下载的数据旁边的复选框。
2. 选择**下一步** 。

#### Google 相册 数据的格式

我们将以如下格式导出您的 Google 相册 数据：

- 照片

**原始格式/PNG/JPG/WEBP** 每个影集中包含的未经编辑和编辑过的照片。格式取决于上传图片时所选的画质。

- 视频

**原始格式/MP4** 每个影集中包含的视频。格式取决于上传图片时所选的画质。

- 影集元数据

**JSON** 与每个影集关联的数据，例如标题或说明。

- 照片元数据

**JSON** 与每张照片或每个视频关联的数据，例如创建时间或评论。

### 第2步：选择文件类型、频率和目标位置

在这里你可以选择导出文件类型、分卷大小、频率等参数、根据自己需要进行选取

![image.png](https://oss.expoli.tech/img/DXR_image.png)

### 第3步：查看下载并保存导出数据

- 导出完成后会生成导出报告

![image.png](https://oss.expoli.tech/img/X5R_image.png)

- 下载并保存导出数据

![image.png](https://oss.expoli.tech/img/1aj_image.png)

## 使用 webdav 挂载阿里云盘

### 安装 [webdav-aliyundriver](https://github.com/zxbu/webdav-aliyundriver)

具体安装方法请参照 [webdav-aliyundriver](https://github.com/zxbu/webdav-aliyundriver) README、不再赘述。

> 若需要 arm64 的 docker 镜像可拉取 [tangcuyu/webdav-aliyundriver](https://hub.docker.com/repository/docker/tangcuyu/webdav-aliyundriver/general)

### 挂载阿里网盘

- Windows

建议使用 [RaiDrive](https://www.raidrive.com/) 进行挂载

- Linux

1. 安装依赖 `davfs2`

```shell
# arch 系列
sudo pacman -S davfs2 
# Debian 系列
sudo apt install davfs2
```

2. 挂载阿里云盘

```shell
sudo mount.davfs http://127.0.0.1:8080 ./google_photos/ -o rw,uid=1000
```

> 地址和端口自己进行更改、UID需改为当前用户的uid数值、否则会引起权限问题

### 转移上传文件

转移文件时用的是 `rsync` 能够显示进度、源路径与目的路径自行修改

```shell
rsync -rauL --progress /data/google_photos/Takeout/ .
```

> ```
> cannot create regular file './takeout-20210718T040659Z-001.tgz': Input/output error
> ```
>
> 当遇到上述问题时，需要修改 davfs2 的配置文件
>
> ```shell
> vim /etc/davfs2/davfs2.conf 
> # 将下面的值修改为 0
> # use_locks 1
> to
> use_locks 0
> ```

- 运行展示

![image.png](https://oss.expoli.tech/img/DX2_image.png)

# 参考资料

https://wouterjanson.nl/2017/04/05/webdav-mount/

https://github.com/zxbu/webdav-aliyundriver

https://www.theoutpost.org/7-on-the-move/owncloud-webdav-cp-cannot-create-regular-file-mntshareddocumentsfile-txt-invalid-argument/
