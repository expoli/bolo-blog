title: 树莓派软路由 （OpenWrt、AP有小坑）
date: '2020-01-17 21:55:59'
updated: '2020-02-16 19:59:22'
tags: [坑, Linux, Openwrt]
permalink: /articles/2020/01/17/1579269359732.html
---
![](https://img.hacpai.com/bing/20180523.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 树莓派软路由 （OpenWrt、AP 有小坑）

## 0 题外话

在考完试后因毕设老师有监考任务，于是返家时间延后了大约一周左右，在和指导老师见面的时候老师给出了题目的选择范围，在进行题目选择的时候那真是有点僧多肉少的意思，最后经过一番的咨询和考虑，选择了一个自我感觉还算良好的毕设题目 `给予嵌入式实现的火焰识别系统` 目前根据自己的了解、这个涉及到了计算机视觉一方面的东西，也算是自己在 **开天辟地** 地学习了，嵌入式平台使用树莓派作为实现平台。

后来在浏览文章时看到树莓派可以运行 OpenWrt 作为软路由使用，于是抱着尝试一下的想法进行了实验，中间也遇到了几处小坑，在这里记录一下。

## 1 制作固件镜像

### 1.1 查询官方支持

要想给树莓派安装上 OpenWrt，我们首先要做的就是查询官方的支持情况，即[https://openwrt.org/start](https://openwrt.org/start)，点击箭头处查询硬件支持。

![1.png](https://img.hacpai.com/file/2020/01/1-a9a6c4f2.png)

然后祭出我们的大杀器 `Ctrl+F` 然后输入 `Raspberry pi` 特快直达目的地：

![1.png](https://img.hacpai.com/file/2020/01/1-692fe69d.png)

点击最右边的[View/Edit data](https://openwrt.org/toh/hwdata/raspberry_pi_foundation/raspberry_pi_3_bplus "toh:hwdata:raspberry_pi_foundation:raspberry_pi_3_bplus") 我的型号是 3B+，自己选择自己对应的型号就可。然后你就可以看到你的派的详细参数了。如下图、点击相应的链接就可以找到相应的固件镜像下载地址了、例如：https://downloads.openwrt.org/releases/19.07.0/targets/brcm2708/bcm2710/

![1.png](https://img.hacpai.com/file/2020/01/1-0219e28d.png)

### 1.2 下载官方镜像

打开对应机器型号的链接（Pi3：https://downloads.openwrt.org/releases/19.07.0/targets/brcm2708/bcm2710/) 你可以看到类似的如下信息：其中文件名称中的前几个为型号即 `rpi-3` ；后面紧跟的为根目录所使用的文件系统（rootfs）如 `ext4` ，再后面是安装方式即你是全新安装（factory）还是进行系统升级（sysupgrade）。

在这里因为我们是全新安装、所以选择 `factory` ，下载完成之后别忘进行 `sha256sum` 校验，保证系统的完整性。

|Image for your Device|sha256sum|File Size|Date|
|---|---|---|---|
|[rpi-3-ext4-factory.img.gz](https://downloads.openwrt.org/releases/19.07.0/targets/brcm2708/bcm2710/openwrt-19.07.0-brcm2708-bcm2710-rpi-3-ext4-factory.img.gz)|4c3e09b177b2be97c5ec5b374b3aea6fed460e89743c65c02069ba8f2a57e74d|12359.7 KB|Tue Jan 7 21:37:08 2020|
|[rpi-3-ext4-sysupgrade.img.gz](https://downloads.openwrt.org/releases/19.07.0/targets/brcm2708/bcm2710/openwrt-19.07.0-brcm2708-bcm2710-rpi-3-ext4-sysupgrade.img.gz)|c0fc1b7f9896f1c09d969656bd7092720a22a4b2b60ea3f681c39b264df4fed3|12360.1 KB|Tue Jan 7 21:37:08 2020|
|[rpi-3-squashfs-factory.img.gz](https://downloads.openwrt.org/releases/19.07.0/targets/brcm2708/bcm2710/openwrt-19.07.0-brcm2708-bcm2710-rpi-3-squashfs-factory.img.gz)|36d24ef3a70be375f019270ae1343e82ca080e0723d67d00b2ed1f0a20add695|11194.4 KB|Tue Jan 7 21:37:05 2020|
|[rpi-3-squashfs-sysupgrade.img.gz](https://downloads.openwrt.org/releases/19.07.0/targets/brcm2708/bcm2710/openwrt-19.07.0-brcm2708-bcm2710-rpi-3-squashfs-sysupgrade.img.gz)|3aac6652f88ffae28a754d884a2df386de2725678389ade70fbd0287ba6e27cf|11194.8 KB|Tue Jan 7 21:37:06 2020|

### 1.3 镜像烧录

在这里推荐一款烧录软件 `etcher` 全平台通用，烧录速度客观，而且烧录后会自动进行校验，值得使用。

### 1.4 自主定制镜像

如果我没记错的话、官方提供的镜像默认是没有安装 `luci` 的，如果你像我一样想直接把自己需要的软件直接打包到安装镜像里，那么你可以尝试下面的方案：

1. 第一步，依旧还是我们下载镜像的网址
2. 第二步，下载相应的 `image-builder` 即 `openwrt-imagebuilder-19.07.0-brcm2708-bcm2710.Linux-x86_64.tar.xz`
3. 第三步 解压

```shell
xz -d openwrt-sdk-19.07.0-brcm2708-bcm2710_gcc-7.5.0_musl.Linux-x86_64.tar.xz
tar xf openwrt-sdk-19.07.0-brcm2708-bcm2710_gcc-7.5.0_musl.Linux-x86_64.tar
```

4. 第四步 查看默认构建参数

```shell
$ cd openwrt-sdk-19.07.0-brcm2708-bcm2710_gcc-7.5.0_musl.Linux-x86_64
$ make info

Current Target: "brcm2708/bcm2710"
Current Revision: "r10860-a3ffeb413b"
Default Packages: base-files libc libgcc busybox dropbear mtd uci opkg netifd fstools uclient-fetch logd urandom-seed urngd brcm2708-gpu-fw kmod-usb-hid kmod-sound-core kmod-sound-arm-bcm2835 kmod-fs-vfat kmod-nls-cp437 kmod-nls-iso8859-1 partx-utils mkf2fs e2fsprogs dnsmasq iptables ip6tables ppp ppp-mod-pppoe firewall odhcpd-ipv6only odhcp6c kmod-ipt-offload
Available Profiles:

rpi-3:
    Raspberry Pi 3B/3B+
    Packages: brcmfmac-firmware-43430-sdio brcmfmac-board-rpi2 brcmfmac-firmware-43455-sdio brcmfmac-board-rpi3 kmod-brcmfmac wpad-basic iwinfo
    hasImageMetadata: 1
    SupportedDevices: rpi-3-b rpi-3-b-plus raspberrypi,3-model-b raspberrypi,3-model-b-plus raspberrypi,3-compute-module raspberrypi,compute-module-3
```

5. 第五步 从上面可以看出默认安装的软件包并不是很多，所以可以像下面这条命令一样，在 `PACKAGES=` 参数中添加自己喜欢的软件包即可 **（注意！要确保包名确实存在哟！）**

```shell
make image PROFILE=rpi-3 PACKAGES="brcmfmac-firmware-43430-sdio brcmfmac-board-rpi2 brcmfmac-firmware-43455-sdio brcmfmac-board-rpi3 kmod-brcmfmac wpad-basic iwinfo luci luci-proto-ipv6 luci-i18n-shadowsocks-libev-zh-cn luci-app-shadowsocks-libev"

tree bin 
bin
└── targets
    └── brcm2708
        └── bcm2710
            ├── openwrt-19.07.0-brcm2708-bcm2710-device-rpi-3.manifest
            ├── openwrt-19.07.0-brcm2708-bcm2710-rpi-3-ext4-factory.img.gz
            ├── openwrt-19.07.0-brcm2708-bcm2710-rpi-3-ext4-sysupgrade.img.gz
            ├── openwrt-19.07.0-brcm2708-bcm2710-rpi-3-squashfs-factory.img.gz
            ├── openwrt-19.07.0-brcm2708-bcm2710-rpi-3-squashfs-sysupgrade.img.gz
            └── sha256sums

3 directories, 6 files
```

|Filename|sha256sum|File Size|Date|
|---|---|---|---|
|[packages/](https://downloads.openwrt.org/releases/19.07.0/targets/brcm2708/bcm2710/packages/)||-|Tue Jan 7 21:47:01 2020|
|[openwrt-imagebuilder-19.07.0-brcm2708-bcm2710.Linux-x86_64.tar.xz](https://downloads.openwrt.org/releases/19.07.0/targets/brcm2708/bcm2710/openwrt-imagebuilder-19.07.0-brcm2708-bcm2710.Linux-x86_64.tar.xz)|b4fc9fcd2152d9c77e123cbc628292298327fb36984d53f2b878da20e9827ba2|28314.5 KB|Tue Jan 7 21:39:05 2020|
|[openwrt-sdk-19.07.0-brcm2708-bcm2710_gcc-7.5.0_musl.Linux-x86_64.tar.xz](https://downloads.openwrt.org/releases/19.07.0/targets/brcm2708/bcm2710/openwrt-sdk-19.07.0-brcm2708-bcm2710_gcc-7.5.0_musl.Linux-x86_64.tar.xz)|b76dab7befeb9a1a5a5ba3abc12a92c488fb4c3a28c83c97ae27e2cda8b3aee2|76271.2 KB|Tue Jan 7 21:45:38 2020|


## 2 配置树莓派

因为树莓派 3B+ 只有一个有线网卡，虽然网卡是千兆的，但是因为是使用的 USB2.0 总线，所以速率只有 300Mbps，但是一般还是够用的。

虽然说可以将树莓派配置为类似于普通路由的无线桥接模式，但是我觉得应该没几个人会这样做吧（拿一根网线插在树莓派的有线网口上，进行上网，想想都很奇怪的样子）。

### 2.1 连接树莓派，进入 luci Web 配置界面

因为默认情况下、刚开始安装的时候，镜像默认将树莓派的有线网卡设置为 `br-lan` 模式，所以如果你想将树莓派作为 AP 的话，需要将树莓派连接到电脑上(相应网卡为 DHCP 获取 IP 地址），然后访问 `http://192.168.1.1` ,然后配置 root 密码。

### 2.2 开启无线 AP

**注意！**
在这里有个小坑，默认 3B+ 直接点击 `enable` 开启无线 AP 时，是 5g 频段，而我的笔记本无线网卡是 2.4g 频段的，所以就尴尬了好长时间，在尝试开启 2.4g 频段的时候，发现如果你讲信道设置为 `auto` 时，树莓派 AP 无法正常工作，对应网卡的 `master` 模式，会主动变为 `client` ，而且系统日志也显示 `wlan0` 启动失败。最后灵机一动，看到 `scan` 其它网络的时候有着对应的信道，于是就在 2.4g 频段上锁定到了 `1` 信道，终于没有什么幺蛾子了。（擦了一把汗）

具体设置如下图、保存应用之后，手机连接到相应的网络，开始将有线网卡设置为 `DHCP client` 。

![1.png](https://img.hacpai.com/file/2020/01/1-48a1afb1.png)

![2.png](https://img.hacpai.com/file/2020/01/1-789e6925.png)

### 2.3 修改 lan 设备

在 Network -> interfaces 里面可以看到现在只有一个 lan 设备。配置 lan 设备为下图模式。取消有线设备 `eth0` 的 lan 划分，因为后续我们需要将其作为 wan 口使用。

![1.png](https://img.hacpai.com/file/2020/01/1-4fe29c3d.png)

### 2.4 添加 wan 设备

点击 add new interface

根据自己的需要选择相应的协议，这里我选择 DHCP-client

![1.png](https://img.hacpai.com/file/2020/01/1-f3cb7175.png)

接口使用有线网卡 eth0

![1.png](https://img.hacpai.com/file/2020/01/1-b1a63c38.png)

防火墙设置选择 wan zone

![1.png](https://img.hacpai.com/file/2020/01/1-ed89ebf7.png)

保存更改后，插线上电进行测试。

## 3 测试完成，备份设置

测试完成之后，别忘了将自己辛苦配置完成的配置文件进行备份，openwrt 提供了很方面的备份。每次动动手，少走好多弯路哟！

祝你折腾愉快！～

（我的 openwrt 的 ssr 订阅啊 ～ ～ ～还没整好，难受(╯﹏╰)）
