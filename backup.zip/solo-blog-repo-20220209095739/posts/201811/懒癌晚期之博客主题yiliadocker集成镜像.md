title: 懒癌晚期之博客主题 yilia docker 集成镜像
date: '2018-11-17 22:18:08'
updated: '2018-11-17 22:18:08'
tags: [Docker, Hexo]
permalink: /articles/2018/11/17/1564656234922.html
---
![image2a6d0bfb4fee6c98.png](./18-11-17-docker-images-hexo-yilia-all-in-one/image2a6d0bfb4fee6c98.png)

## 方案构想

<!-- more -->

刚开始的构想是将所有的功能都集成到一个镜像里面，后来考虑了一下，感觉这种操作可重用性太低，于是采取了另外一种方案：即将其分成本地构建端和 `web` 服务端，两者通过 `git` 来进行交互实现博客的更新。

## 方案实施

原来在使用博客的时候以为想偷懒的，于是就专门从头建立了一个  `hexo-yilia` 主题的一个离线工作环境。传送门 --> [https://github.com/zzutcy/hexo-theme-yilia-all-in-one](https://github.com/zzutcy/hexo-theme-yilia-all-in-one)

有需求的童鞋欢迎围观、 **star** （嘿嘿）**开箱即用呦～** **欢迎大家来支持哈**

## docker 构建方案

按照构思 docker 构建分为2步，第一步构建 server 端

### hexo_yilia_serverv

大家可以使用我已经构建好的镜像，运行命令

```bash
$ sudo docker pull tangcuyu/hexo_yilia_server
$ docker run -d -it --name=hexo_yilia_client -p 80:80 -p 2222:22 --restart=alwsys  tangcuyu/hexo_yilia_client /bin/bash
```

**如果你想自己构建你可以参考下面的介绍**

* ### 首先是构建Dockerfile
    * 这些东西你都可以在这里找到    [https://github.com/zzutcy/Dockerfile-hexo-theme-yilia-all-in-one](https://github.com/zzutcy/Dockerfile-hexo-theme-yilia-all-in-one)

* 要想构建 docker 镜像、第一步就是制作 Dockerfile 文件、下面就是本次所使用的 Dockerfile

### 注意⚠️  ！！！
**下面代码块中的注释纯属说明使用，在使用时请前往 [https://github.com/zzutcy/Dockerfile-hexo-theme-yilia-all-in-one](https://github.com/zzutcy/Dockerfile-hexo-theme-yilia-all-in-one) 获取完整代码**

```bash
FROM centos     # 基础镜像
MAINTAINER zzutcy "zzutcy@gmail.com"    # 制作者信息
ENV REFRESHED_AT 2018-11-16     # 制作时间
# 所执行的命令
RUN mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.bak
# 添加仓库源
ADD CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo
ADD nginx-release-centos-7-0.el7.ngx.noarch.rpm /root/
ADD nginx.conf /etc/nginx/nginx.conf    # 添加配置文件
ADD default.conf /etc/nginx/conf.d/

RUN rpm -ivh /root/nginx-release-centos-7-0.el7.ngx.noarch.rpm    \
    && yum makecache   \
    && yum update -y   \
    && yum install wget git nginx vim openssh-server net-tools -y   \
    && useradd git  \
    && mkdir -p /var/www/hexo  \
    && chown -R git.git /var/www/hexo \
    && su git  \
    && git init --bare hexo.git
# 添加 git 钩子
ADD post-receive /home/git/hexo.git/hooks/
RUN chmod +x /home/git/hexo.git/hooks/post-receive  \
    && chown -R git.git /home/git 
# 镜像所需端口
EXPOSE 80 22
CMD ["/usr/sbin/nginx -s reload"]
```

### 执行构建命令

在准备好所需文件后在拥有 Dockerfile 的文件夹执行

```bash
$ sudo docker build -t yourname/yourimagesname .
# sudo docker build -t tangcuyu/hexo_yilia_server .
```
然后慢慢等待直到构建完成

### 从镜像运行容器

```bash
$ docker run -d -it --name=hexo_yilia_client -p 80:80 -p 2222:22 tangcuyu/hexo_yilia_server /bin/bash
```
可访问80端口检测是否成功

### hexo_yilia_client

大家可以使用我已经构建好的镜像，运行命令

```bash
$ sudo docker pull tangcuyu/hexo_yilia_client
$ docker run -d -it --name=hexo_yilia_client -p 4000:4000 --restart=alwsys tangcuyu/hexo_yilia_client /bin/bash
```

如果你想要自己构建可以参考下面的介绍

### 注意⚠️  ！！！
**下面代码块中的注释纯属说明使用，在使用时请前往 [https://github.com/zzutcy/Dockerfile-hexo-theme-yilia-all-in-one](https://github.com/zzutcy/Dockerfile-hexo-theme-yilia-all-in-one) 获取完整代码**

```bash
FROM centos # 基础镜像
MAINTAINER zzutcy "zzutcy@gmail.com"    # 作者信息
ENV REFRESHED_AT 2018-11-15 # 构建日期
RUN mv /etc/yum.repos.d/CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo.bak
# 田间文件
ADD CentOS-Base.repo /etc/yum.repos.d/CentOS-Base.repo
# 执行命令
RUN yum update -y   \
    && yum install wget git vim -y     \
    && wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo   \
    && yum update -y   \
    && yum install nodejs -y   \
    && npm config set registry http://registry.npm.taobao.org/  \
    && npm install -g hexo-cli  \   
    && cd /root    \
    && git clone https://github.com/zzutcy/hexo-theme-yilia-all-in-one.git     \
    && cd hexo-theme-yilia-all-in-one/     \
    && hexo clean
# 端口做调试使用
EXPOSE 4000
```

### 执行构建命令

在准备好所需文件后在拥有 Dockerfile 的文件夹执行

```bash
$ sudo docker build -t yourname/yourimagesname .
# sudo docker build -t tangcuyu/hexo_yilia_client .
```
然后慢慢等待直到构建完成

### 从镜像运行容器

```bash
$ sudo docker run -d -it --name=hexo_yilia_client -p 4000:4000 tangcuyu/hexo_yilia_client /bin/bash
$ docker exec -i -t test_client /bin/bash
# cd hexo-theme-yilia-all-in-one
# hexo clean && hexo g
# hexo s --debug
```

可访问  `4000` 端口检测是否成功