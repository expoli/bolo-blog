title: 使用 Docker compose 启动一个 CHEVERETO 图床
date: '2019-07-27 14:46:08'
updated: '2019-07-27 14:46:08'
tags: [Chevereto, Docker, docker-compose]
permalink: /articles/2019/07/27/1564656216037.html
---
# 使用 `Docker compose` 启动一个 `CHEVERETO` 图床

## 1. 基础 web 服务

### 1. 创建一个网络

```bash
docker network create sz_web_net
```

### 2. 创建一个 `docker-compose.yaml` 文件

```yaml
version: '3'

services:
  nginx:
    image: nginx:latest
    # ports
    ports:
      - "80:80"
      - "443:443"
    # depends
    depends_on:
      - "mysql"
    restart: always
    links:
      - "chevereto:chevereto"
      - "mysql:chevereto-db"
    # data volumes
    volumes:
      # ying she zhu ji wang zhan mu lu
      - ./nginx/conf.d:/etc/nginx/conf.d:ro
      # - ./nginx/conf/nginx.conf:/etc/nginx/nginx.conf:ro

    container_name: "web_nginx"

  mysql:
    image: mariadb
    volumes:
      - ./mysql_files:/var/lib/mysql:rw
    restart: always
    environment:
      MYSQL_ROOT_PASSWORD: chevereto_root
      MYSQL_DATABASE: chevereto
      MYSQL_USER: chevereto
      MYSQL_PASSWORD: chevereto
    container_name: "chevereto-db"

  chevereto:
    image: nmtan/chevereto
    depends_on:
      - mysql
    # ports:
    #   - 8080:80
    restart: always

    environment:
      CHEVERETO_DB_HOST: chevereto-db
      CHEVERETO_DB_USERNAME: chevereto
      CHEVERETO_DB_PASSWORD: chevereto
      CHEVERETO_DB_NAME: chevereto
      CHEVERETO_DB_PREFIX: chv_
    volumes:
      - ./chevereto_files:/var/www/html/images:rw
      # 获取真实IP
      - ./apache/remoteip.load:/etc/apache2/mods-enabled/remoteip.load:ro
      - ./apache/remoteip.conf:/etc/apache2/mods-enabled/remoteip.conf:ro
      # 修改最大上传大小
      - ./upload.ini:/usr/local/etc/php/conf.d/upload.ini:ro
    container_name: "chevereto-web"

networks: 
  default:
    external:
      name:  your_network_name
```

### 3. nginx 配置模板文件

在在对应目录 `./nginx/conf` 下面 新建 `nginx.conf` 文件

```bash
user  www-data www-data;
worker_processes auto;
error_log  /www/wwwlogs/nginx_error.log  error;
pid        /var/run/nginx.pid;
worker_rlimit_nofile 51200;

events
{
    use epoll;
    worker_connections 51200;
    multi_accept on;
}

http
{
    server_tokens off;

    include       mime.types;
    default_type  application/octet-stream;

    server_names_hash_bucket_size 512;
    client_header_buffer_size 32k;
    large_client_header_buffers 4 32k;
    client_max_body_size 1000m;

    sendfile   on;
    tcp_nopush on;

    keepalive_timeout 600;

    tcp_nodelay on;

    gzip off;
    gzip_min_length  1k;
    gzip_buffers     4 16k;
    gzip_http_version 1.1;
    gzip_comp_level 2;
    gzip_types     text/plain application/javascript application/x-javascript text/javascript text/css application/xml;
    gzip_vary on;
    gzip_proxied   expired no-cache no-store private auth;
    gzip_disable   "MSIE [1-6]\.";

    limit_conn_zone $binary_remote_addr zone=perip:10m;
    limit_conn_zone $server_name zone=perserver:10m;

    # set user real ip to remote addr
    set_real_ip_from   192.168.0.0/16;
    set_real_ip_from   172.0.0.0/8;
    real_ip_header     X-Forwarded-For;
    real_ip_recursive on;

    #log_format combined_realip;
    
    log_format  compression '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    access_log on;
    access_log /www/wwwlogs/nginx_access.log compression;

    include /etc/nginx/conf.d/*.conf;
}

```

### 4. 创建虚拟服务器配置文件

在对应目录 `./nginx/conf.d` 下面 新建 `new_server.conf` 文件

```bash
server {
    listen 80;
    server_name expoli.tech;

    location / {
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Real-Port $remote_port;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header HTTP_X_FORWARDED_FOR $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header Host $host;
        proxy_set_header X-NginX-Proxy true;

        proxy_pass http://chevereto;
        proxy_redirect default;

        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
    access_log on;
    access_log /www/wwwlogs/tc.shuangzu.top_access.log compression;
    error_log /www/wwwlogs/tc.shuangzu.top_error.log;
}
```

## 2. 添加 ini 文件修改最大上传文件大小

### 1. 新建 upload.ini 文件

```php
post_max_size = 100M
upload_max_filesize = 100M
```

### 2. 将 upload.ini 挂载至容器内部

```yaml
version: '3'
services:
  chevereto:
  ......
  ......
  volumes:
    - ./upload.ini:/usr/local/etc/php/conf.d/upload.ini:ro
  ......
```

## 3. 添加 apache 模块文件获取用户真实IP

### 1. 在宿主机上创建相应文件

- remoteip.load 
```conf
# cat remoteip.load 
LoadModule remoteip_module /usr/lib/apache2/modules/mod_remoteip.so
```

- remoteip.conf
```conf
# remoteip.conf
RemoteIPHeader X-Forwarded-For
RemoteIPProxiesHeader X-Forwarded-By
```

### 2. 挂载至容器内部

```yaml
# remoteip.load
- ./apache/remoteip.load:/etc/apache2/mods-enabled/remoteip.load:ro
# remoteip.conf
- ./apache/remoteip.conf:/etc/apache2/mods-enabled/remoteip.conf:ro
```

## 4. 启动测试

### 1. 使用 `docker-compose` 命令启动

```bash
# 可以查看相关日志输出
docker-compose up
# 在后台运行
# docker-compose up -d
```

## 5. 相关文档

[修改 docker php 镜像增加可上传文件大小](https://expoli.tech/2019/07/30/%e4%bf%ae%e6%94%b9-docker-php-%e9%95%9c%e5%83%8f%e5%a2%9e%e5%8a%a0%e5%8f%af%e4%b8%8a%e4%bc%a0%e6%96%87%e4%bb%b6%e5%a4%a7%e5%b0%8f/)
[nginx+wordpress-docker镜像获取真实IP](https://expoli.tech/2019/07/27/nginxwordpress-docker%e9%95%9c%e5%83%8f%e8%8e%b7%e5%8f%96%e7%9c%9f%e5%ae%9eip/)