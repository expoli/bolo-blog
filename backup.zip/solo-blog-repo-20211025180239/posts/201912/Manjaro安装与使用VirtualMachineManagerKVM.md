title: Manjaro 安装与使用Virtual Machine Manager (KVM)
date: '2019-12-27 12:23:03'
updated: '2019-12-27 12:23:03'
tags: [Arch, Manjaro, KVM]
permalink: /articles/2019/12/27/1577420582968.html
---
![](https://img.hacpai.com/bing/20171219.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Manjaro 安装与使用 Virtual Machine Manager (KVM)

在安装 KVM 之前你需要检查自己的电脑在硬件上是否支持虚拟化，KVM 需要 Intel 的 VT-x 和 AMD 的 AMD-V 支持。

## 1 检查硬件支持

`LC_ALL=C lscpu | grep Virtualization`

```shell
LC_ALL=C lscpu | grep Virtualization
Virtualization:                  VT-x
```

如果你运行了上述命令但是并没有任何输出，那么你的电脑就有着很大的可能没办法运行虚拟机，不过你可以进入自己的 BIOS 查看一下是不是自己的 BIOS 里面的虚拟化支持没有开启。

## 2 查看内核支持

在确认了自己的硬件支持开启虚拟化之后、要进行的就是查看软件方面的检查、看自己的内核是否支持 KVM。
运行下面的命令：

```text
zgrep CONFIG_KVM /proc/config.gz
```

查看输出，关注 `CONFIG_KVM_INTEL 或 CONFIG_KVM_AMD 的值是不是 ‘m’ 或 ‘y’.`下面的是我自己本子的输出：

```shell
CONFIG_KVM_GUEST=y
# CONFIG_KVM_DEBUG_FS is not set
CONFIG_KVM_MMIO=y
CONFIG_KVM_ASYNC_PF=y
CONFIG_KVM_VFIO=y
CONFIG_KVM_GENERIC_DIRTYLOG_READ_PROTECT=y
CONFIG_KVM_COMPAT=y
CONFIG_KVM=m
CONFIG_KVM_INTEL=m
CONFIG_KVM_AMD=m
CONFIG_KVM_AMD_SEV=y
CONFIG_KVM_MMU_AUDIT=y
```

## 3 开始安装 KVM (Virtual Machine Manager)

如果上述两项都已经满足了，那么我们就可以开始今天的重头戏了，那就是安装KVM (Virtual Machine Manager)

- STEP 1: 安装需要的包

```shell
sudo pacman -S virt-manager qemu vde2 ebtables dnsmasq bridge-utils openbsd-netcat
```

- STEP 2: 接下来的两个步骤非常重要，许多用户经常忽略它们。确保完成其他操作，安装完成后运行虚拟机管理器时，将出现错误“ adduser：组`libvirtd'不存在”！

设置开机启动 libvirtd 服务
```
sudo systemctl enable libvirtd.service
```

- STEP 3: 启动 libvirtd 服务

```
sudo systemctl start libvirtd.service
```

## 4 安装完成启动 Virtual Machine Manager

安装完成后、就可以在软件中心中启动虚拟机管理器了。下面是启动画面。

![QQ图片20191227122219.png](https://img.hacpai.com/file/2019/12/QQ图片20191227122219-d66dac0a.png)

