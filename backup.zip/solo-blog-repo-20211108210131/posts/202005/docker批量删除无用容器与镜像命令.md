title: docker 批量删除无用容器与镜像命令
date: '2020-05-11 15:57:16'
updated: '2020-05-11 15:58:42'
tags: [Docker]
permalink: /articles/2020/05/11/1589183836851.html
---
![](https://img.hacpai.com/bing/20190113.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Docker 批量删除无用容器与镜像命令

在进行容器的构建测试的时候，很多时候因为各种原因会遗留下来这样那样的中间容器，后续在删除的时候着实是一件很让人头疼的事情，在这里分享一下总结的批量处理命令。

## 批量删除已经停止的容器

注意：本命令会直接删除所有退出停止的容器，在执行之前，确保你确实想进行批量删除。

```
docker rm $(docker ps -a | grep Exited | awk '{print $1}') 
```

### 命令解析

1. 我们执行 `docker ps -a ` 时已经退出的容器状态会显示为 `Exited` 

![image.png](https://oss.expoli.tech/img/zoqxeEbw9r)

2. 使用 grep 过滤出已经停止的容器 

![image.png](https://oss.expoli.tech/img/Iquo3pR7VI)

3. 使用 `awk` 提取容器ID

![image.png](https://oss.expoli.tech/img/CPKn4wnQMR)

4. 将提取的容器ID作为参数传递给 `docker rm` 语句

docker rm $(docker ps -a | grep Exited | awk '{print $1}') 

## 批量清理无用镜像

注意：使用此命令会清楚构建缓存，运行前请确认是否真的想清除镜像。

```
docker rmi $(docker images | grep none | awk '{print $3}')
```

命令解析如上

### 运行结果

![image.png](https://oss.expoli.tech/img/Fo9Qr9HSTg)

