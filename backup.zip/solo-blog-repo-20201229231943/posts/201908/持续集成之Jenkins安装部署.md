title: 持续集成之Jenkins安装部署
date: '2019-08-18 14:41:05'
updated: '2019-09-08 13:30:47'
tags: [运维, Jenkins]
permalink: /articles/2019/08/18/1566110465770.html
---
![](https://img.hacpai.com/bing/20190726.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 持续集成之Jenkins安装部署

## 1 Jekins的安装
### 1.1 安装JDK     

Jenkins是Java编写的，所以需要先安装JDK，这里采用yum安装，如果对版本有需求，可以直接在Oracle官网下载JDK。

``` bash
[root@linux-node1 ~]# yum install -y java-1.8.0
```

### 1.2 安装Jekins

```bash
# cd /etc/yum.repos.d/
# wget http://pkg.jenkins.io/redhat/jenkins.repo
# rpm --import http://pkg.jenkins.io/redhat/jenkins.io.key
# yum install -y jenkins
# systemctl start jenkins
```

### 1.3 查看安装状态

```bash
# systemctl status jenkins
● jenkins.service - LSB: Jenkins Automation Server
   Loaded: loaded (/etc/rc.d/init.d/jenkins; bad; vendor preset: disabled)
   Active: active (running) since Sat 2019-08-17 20:10:38 CST; 5s ago
     Docs: man:systemd-sysv-generator(8)
  Process: 7995 ExecStart=/etc/rc.d/init.d/jenkins start (code=exited, status=0/SUCCESS)
   CGroup: /system.slice/jenkins.service
           └─8016 /etc/alternatives/java -Dcom.sun.akuma.Daemon=daemonized -Djava.awt.headless=true -DJENKINS_HOME=/var/lib/jenkin...

Aug 17 20:10:37 linux-node-1 systemd[1]: Starting LSB: Jenkins Automation Server...
Aug 17 20:10:37 linux-node-1 runuser[8000]: pam_unix(runuser:session): session opened for user jenkins by (uid=0)
Aug 17 20:10:38 linux-node-1 jenkins[7995]: Starting Jenkins [  OK  ]
Aug 17 20:10:38 linux-node-1 systemd[1]: Started LSB: Jenkins Automation Server.

# yum install net-tools -y
# netstat -ntl
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address           Foreign Address         State       PID/Program name    
tcp        0      0 127.0.0.1:25            0.0.0.0:*               LISTEN      1272/master         
tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      1056/sshd           
tcp6       0      0 ::1:25                  :::*                    LISTEN      1272/master         
tcp6       0      0 :::8080                 :::*                    LISTEN      8016/java           
tcp6       0      0 :::22                   :::*                    LISTEN      1056/sshd
```

### 1.4 访问并解锁Jenkins


```bash
cat /var/lib/jenkins/secrets/initialAdminPassword
```

![Jenkins0.png](http://tc.expoli.tech/images/2019/08/18/Jenkins0.png)

### 1.5 初始化 Jenkins

建议的插件就可以

![Jenkins1.png](http://tc.expoli.tech/images/2019/08/18/Jenkins1.png)

![Jenkins2.png](http://tc.expoli.tech/images/2019/08/18/Jenkins2.png)

## 2. 新建 gitlab 任务

### 2.1 安装 gitlab 以及 gitlab hook 插件

### 2.2 设置 gitlab 项目的 Deploy Keys

填入 jenkins 的ssh公钥

### 2.3 git clone 测试、确保权限正确、可以正常clone

```bash
# git clone 
```

### 2.4 配置 Jenkins 的密钥认证

### 2.5 配置构建任务

### 2.6 立即构建

### 2.7 从控制台查看构建输入

