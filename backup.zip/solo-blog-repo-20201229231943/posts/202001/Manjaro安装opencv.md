title: Manjaro 安装 opencv
date: '2020-01-12 16:14:26'
updated: '2020-03-14 21:02:30'
tags: [坑, Manjaro, OpenCV]
permalink: /articles/2020/01/12/1578816866429.html
---
![](https://img.hacpai.com/bing/20190909.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Manjaro 安装 opencv

## 安装相应的包

### 首先查询源是否有自己需要的包

![1.png](https://img.hacpai.com/file/2020/01/1-051c6eb7.png)

```shell
# 安装基础构建工具组和自己需要的安装包
sudo pacman -Syu base-devel opencv opencv-samples opencv-docs hdf5 vtk~~~~
```

### 查询数据库检查例程安装路径

```shell
sudo pacman -Ql opencv-samples

.....
opencv-samples /usr/share/opencv/samples/
```

### 编译测试

```shell
cd /usr/share/opencv/samples/cpp

g++ -ggdb `pkg-config --cflags --libs opencv4 ` opencv_version.cpp -o /tmp/opencv_version && /tmp/opencv_version

# 输出结果：
/tmp/opencv_version        
Welcome to OpenCV 4.2.0
```
