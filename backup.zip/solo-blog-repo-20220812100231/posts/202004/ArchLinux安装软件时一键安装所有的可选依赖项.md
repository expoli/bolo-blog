title: Arch Linux 安装软件时一键安装所有的可选依赖项
date: '2020-04-01 15:26:58'
updated: '2020-04-04 11:25:24'
tags: [Note, Arch]
permalink: /articles/2020/04/01/1585726018255.html
---
![](https://img.hacpai.com/bing/20200301.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Arch Linux 安装软件时一键安装所有的可选依赖项

我想大家在使用 Arch 的时候、都会遇到这种情况：安装一个软件包之后、发现他有着很多的可选依赖项；而且这些可选依赖项在你安装主软件包的时候，pacman 默认是没有一键安装所有的可选依赖项的参数的。所以很多的时候，只能很难受的一个一个把包名复制好之后全部安装。

比如下图：

![](https://oss.expoli.tech/img/20200401152327.png)

---

那么如何在所有基于 Arch 的发行版（例如 Arch，Manjaro，ArcoLinux 等）上安装具有可选依赖项的软件包的所有的可选依赖呢？

如果您使用的是 Manjaro 那么您完全可以从发行版的（通常基于 GUI 的）程序包助手中进行此操作（例如 Manjaro 的 pamac-manager），但是那毕竟不是我们的菜。

下面介绍如何使用标准的 `pacman` 包管理器，如何使用命令行进行此操作。

## 1. 首先安装主软件包

如上所述，我们需要先安装主软件包。让我们以 `wine` 为例（选择 wine 的原因是因为它有很多可选的依赖项）。

照常安装主 wine ：

```pacman
sudo pacman -S wine
```

## 2. 安装 expac 工具

```pacman
sudo pacman -S expac
```

![expac](https://oss.expoli.tech/img/20200404112329.png)

## 2. 查询所有的依赖项（使用 expac）

```pacman
sudo pacman -S expac
expac -S '%o' wine-staging  
```

## 3. 安装所有可选的依赖项（作为依赖项 –asdeps）

```pacman
sudo pacman -S --asdeps $(expac -S '%o' wine)
```

重要的是要注意，我们应该在此处使用 --asdeps 参数将这些软件包的安装原因标记为“依赖”（否则，这些软件包将被标记为“明确”安装）。这意味着，如果您卸载主软件包，则这些可选的依赖项将被孤立-不过您也可以通过一个命令安全地卸载它们（您可以经常运行该命令来清理任何孤立的孤儿包）：

```pacman
sudo pacman -Rns $(pacman -Qtdq)
```

# 参考资料

[Install a package with all optional dependencies in Arch based distros](https://confluence.jaytaala.com/display/TKB/Install+a+package+with+all+optional+dependencies+in+Arch+based+distros)

[Manjaro Linux CN Tg group]
