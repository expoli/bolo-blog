title: Linux Swap 性能优化
date: '2020-04-26 18:06:42'
updated: '2020-04-26 18:06:42'
tags: [Linux, Arch]
permalink: /articles/2020/04/26/1587897523840.html
---
# Linux Swap 性能优化

Arch wiki [https://wiki.archlinux.org/index.php/Swap_(简体中文)](https://wiki.archlinux.org/index.php/Swap_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87))

## Swappiness

*swappiness* [sysctl](https://wiki.archlinux.org/index.php/Sysctl "Sysctl") 参数代表了内核对于交换空间的喜好(或厌恶)程度。Swappiness 可以有 0 到 100 的值。设置这个参数为较低的值会减少内存的交换，从而提升一些系统上的响应度。

`swappiness` 值推荐设置为 1,设置为 0 的话，有些内核会认为是不使用 swap。

```
/etc/sysctl.d/90-swappiness.conf

vm.swappiness=1
vm.vfs_cache_pressure=50
```

## 优先级

如果你有多于一个交换文件或交换分区，你可以给它们各自分配一个优先级值(0 到 32767)。系统会在使用较低优先级的交换区域前优先使用较高优先级的交换区域。例如，如果你有一个较快的磁盘 (`/dev/sda`) 和一个较慢的磁盘 (`/dev/sdb`)，给较快的设备分配一个更高的优先级。优先级可以在 fstab 中通过 `pri` 参数指定：

```
/dev/sda1 none swap defaults,pri=100 0 0
/dev/sdb2 none swap defaults,pri=10  0 0

```

或者通过 swapon 的 `−p` (或者 `−−priority`) 参数：

```
# swapon -p 100 /dev/sda1
```

如果两个或更多的区域有同样的优先级，并且它们都是可用的最高优先级，页面会按照循环的方式在它们之间分配。
