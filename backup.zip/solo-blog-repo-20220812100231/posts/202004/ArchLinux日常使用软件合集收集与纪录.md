title: Arch Linux 日常使用软件合集（收集与纪录）
date: '2020-04-04 13:18:19'
updated: '2020-04-04 16:15:08'
tags: [Arch]
permalink: /articles/2020/04/04/1585977499044.html
---
![](https://img.hacpai.com/bing/20171204.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Arch Linux 日常使用软件合集（收集与纪录）

如果本文帮到您了，或者您有更好的软件推荐、分享、欢迎在评论区留言。🥰🥰

## 1. Visual Studio Code

<details>
<summary>点击安装</summary>


1. 查询 code 包版本

```pacman
# sudo pacman -Ss code | grep community/code

community/code 1.43.2-2
```

2. 查询软件包详细信息

```pacman
sudo pacman -Si code
```

![sudo pacman -Si code](https://oss.expoli.tech/img/20200404110607.png)

3. 安装核心包

安装核心包时会自动安装所需依赖，但是并不会自动安装此包的可选依赖。

```pacman
sudo pacman -S code
```

4. 安装可选依赖（可选）

从上面可以看出 code 的可选依赖还都是很有用的。

在这里一键安装所有的可选依赖项。（命令具体详细信息请参阅 [Arch Linux 安装软件时一键安装所有的可选依赖项](https://expoli.tech/articles/2020/04/01/1585726018255.html)）

```pacman
sudo pacman -S --asdeps $(expac -S '%o' code)
```

</details>

## 2. iease-music（第三方网易云）

<details>
<summary>点击安装</summary>

### 简介

虽然Arch Linux 上 archlinuxcn 与 aur 上都有着 netease-cloud-music 这一基于 官方 deb 包构建的，但是经过使用发现不知什么原因这个包会引起 kernel 死掉，无法开启tty 只能强制关机，所以经过 Manjaro Linux CN 群大佬的介绍认识了 `iease-music` 是一颜值与稳定性都过关的第三方客户端，用了很长时间了，目前表现良好。

- netease-cloud-music

```pacman
 archlinuxcn/netease-cloud-music 1.2.1-1
    Netease Cloud Music, converted from .deb package
```

- iease-music
```pacman
archlinuxcn/iease-music 1.3.4-1
    Elegant neteaseMusic desktop app, Rock with NeteaseMusic.
```

> 注意这两款软件需要启用 archlinuxcn 或者 aur 才可安装。
> archlinuxcn 的启用请参考之前的 [Arch Linux 启用 archlinuxcn 源](https://expoli.tech/articles/2020/02/12/1581513647899.html)一文。

### 安装

<details>
<summary>点击开始安装</summary>

![https://oss.expoli.tech/img/20200404114459.png](https://oss.expoli.tech/img/20200404114459.png)
我们看到该包没有任何可选依赖项。
1. 安装`iease-music`

```pacman
sudo pacman -S iease-music
```
</details>

### 界面展示

<details>
<summary>点击查看界面展示</summary>

- 主界面

![主界面](https://oss.expoli.tech/img/20200404115040.png)

- 我喜欢的音乐界面

![我喜欢的音乐界面](https://oss.expoli.tech/img/20200404120048.png)

- 评论

![评论](https://oss.expoli.tech/img/20200404120531.png)

- 歌词界面

目前歌词在我KDE上显示为Nothing、不知是我自己的问题还是怎么了。

![歌词界面](https://oss.expoli.tech/img/20200404121930.png)

- 菜单界面

![菜单](https://oss.expoli.tech/img/20200404120318.png)

</details>
</details>

## 3. Tim/QQ

<details>
<summary>点击安装</summary>

### Tim

```pacman
sudo pacman -Si deepin.com.qq.office && sudo pacman -S deepin.com.qq.office
```

### QQ

```pacman
sudo pacman -Si deepin.com.qq.im && sudo pacman -S deepin.com.qq.im
```

### 不显示头像与图片的解决办法

经过查询资料发现这是由于 ipv6 引起的（猜测可能是QQ/Tim尝试使用IPv6连接服务器，结果因为本机无ipv6网络，所以导致的？），所以有两个解决办法，一是关闭内核的ipv6，二是为Tim/QQ设置本地代理，在这建议使用第二种方法。

更多信息请参阅下方引用链接，包含了多数发行版的解决方案

> 官方 Issues：https://github.com/wszqkzqk/deepin-wine-ubuntu/issues/222

KDE上那个下拉框出不来可以用键盘上下左右键来选择之后再进行保存。如下图：

![QQ本地代理](https://oss.expoli.tech/img/20200404123306.png)

</details>

## 4. Flameshot（火焰截图）

<details>
<summary>点击安装</summary>

### 简介

目前 Linux 平台下发现的最好用的截图工具、没有之一。

官网地址：https://flameshot.js.org/#/

### 安装

```pacman
sudo pacman -Si flameshot && sudo pacman -S flameshot 
```
![Flameshot](https://oss.expoli.tech/img/20200404124834.png)

</details>

## 5. 日志分享(用于求助)

<details>
<summary>点击学习</summary>

### 1. 使用命令（curl -F "c=@-" "http://fars.ee/"）

示例：下面的命令就是将本次的启动日志通过管道转给curl传送给 `"http://fars.ee/"`，然后服务器返回给你一系列状态，你只需要将返回的短链接分享给支持人员即可。

```pacman
journalctl -b -1 | curl -F "c=@-" "http://fars.ee/"
```
示范：
![](https://oss.expoli.tech/img/20200404130508.png)

### 2. 使用 `Paste Ubuntu` 网站

链接：https://paste.ubuntu.com/

使用方式：将你的代码或者日志贴进去然后提交之后，将最终的网址分享给你的远程支持者即可。

</details>

## 6. fcitx-sogoupinyin（搜狗输入法）

<details>
<summary>点击安装</summary>

### 安装

在这里使用的是 archlinuxcn 源中的搜狗输入法，当然你也可以使用 aur 里的。

```pacman
sudo pacman -Si fcitx-sogoupinyin && sudo pacman -S fcitx-sogoupinyin
```

```pacman
archlinuxcn/fcitx-sogoupinyin 2.3.1.0112-1 
    Sogou Pinyin for Linux
```
</details>

## 7. onedrive-abraunegg(OneDrive Free Client)

<details>
<summary>点击安装</summary>

### 安装

```pacman
sudo pacman -Si onedrive-abraunegg && sudo pacman -S onedrive-abraunegg
```

![](https://oss.expoli.tech/img/20200404142325.png)

```pacman
archlinuxcn/onedrive-abraunegg 2.4.0-1
    Free OneDrive client written in D - abraunegg's fork. Follows the releases on
    https://github.com/abraunegg/onedrive/releases
```

### 使用方法

请参阅官方指导文档：https://github.com/abraunegg/onedrive/blob/master/docs/USAGE.md

</details>

## 未完待续。。。（欢迎留言🥰）


