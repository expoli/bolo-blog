title: Arch Linux 并行包管理器 Powerpill
date: '2020-04-26 11:35:50'
updated: '2020-04-26 11:35:50'
tags: [Arch]
permalink: /articles/2020/04/26/1587881440541.html
---
# Arch Linux 并行包管理器 Powerpill

Arch wiki 地址 [https://wiki.archlinux.org/index.php/Powerpill](https://wiki.archlinux.org/index.php/Powerpill)

Powerpill 是一个 pacman 包装器，它使用并行和分段下载来尝试加快 Pacman 的下载速度。使用 Aria2 和 Reflector 来实现。

示例：一个人想要更新并发出 pacman -Syu，它返回 20 个软件包的列表，这些软件包可用于更新总计 200 兆。如果用户通过 pacman 下载它们，它们将根据 mirrorlist 的顺序选择镜像站进行下载。

如果用户通过 powerpill 下载它们，则它们在许多情况下会同时从多个镜像源下载，速度要快几倍（取决于一个人的连接速度，服务器上软件包的可用性以及来自服务器/负载等）。

## 安装



## 配置

为了防止出现以下情况，(这是因为该存储库缺少签名文件),我们需要修改一下 pacman 配置文件。

```
   b5d7d7|ERR |       0B/s|/var/lib/pacman/sync/extra.db.sig
   899e91|ERR |       0B/s|/var/lib/pacman/sync/multilib.db.sig
   8fcc32|ERR |       0B/s|/var/lib/pacman/sync/core.db.sig
   85eb3d|ERR |       0B/s|/var/lib/pacman/sync/community.db.sig
```

修改 `/etc/pacman.conf`，仅进行包的签名验证。

```
SigLevel = PackageRequired
```

## 使用

使用方式与 pacman 相同

```
# powerpill -Syu
```


