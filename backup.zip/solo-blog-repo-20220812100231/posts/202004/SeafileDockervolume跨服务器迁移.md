title: Seafile Docker volume 跨服务器迁移
date: '2020-04-02 17:42:16'
updated: '2020-04-02 17:42:16'
tags: [Seafile, Docker, docker-compose]
permalink: /articles/2020/04/02/1585820536124.html
---
# Seafile Docker volume 跨服务器迁移

## 前言

最近发现一个服务器上同时跑 Seafile 与 bolo 太吃力、然后碰巧也在群里看到有群友推荐 Docker 面板 Portainer，于是就想着顺手也将 Seafile 做一个迁移，因为是跨服务器进行迁移，所以也是在经过了一番资料的查询之后才动的手。期间看到了一篇很好的文章。在这里将链接放出来。😄

[Docker volume 跨服务器迁移](https://www.pbeta.me/docker-volume-migrate/)，我也只是根据文章的步骤进行了一下手动实现，所以在这里记录下来，原理我也就不怎么讲了，可以直接戳上方链接进行学习。

## 具体实现流程

要对容器 volume 进行迁移，主要流程如下：

* 打包现有 volume 内容为 tar 文件
* 将 tar 文件传输至新服务器
* 在新服务器中创建中间容器
* 解压 tar 文件至 volume 对应目录
* 清理中间容器等

### 1. 打包现有 volume 内容为 tar 文件包

```bash
docker run --rm --volumes-from CONTAINER  -v $(pwd):/backup  busybox tar cvf /backup/backup_file_name.tar -C /DIR_TO_BAKUP ./
```

### 将 tar 文件传输至新服务器

既可以通过 scp 命令，也可以使用 rsync 工具进行传输。

```bash
# scp
scp backup.tar root@新服务器IP:/root/
# rsync
rsync -av --progress backup.tar root@新服务器IP:/root/
```

### 2. 在新服务器创建中间容器

使用 `docker create` 命令创造一个仅用于迁移的容器：

```
docker create -v TARGET_VOLUME_NAME:/data --name temp busybox true

```

### 3. 解压 tar 文件至 volume

```
docker run --rm --volumes-from temp -v $(pwd):/backup busybox tar xvf /backup/backup.tar -C data/
```

### 4. Seafile 的转移

Seafile 如果使用 Docker 方式启动的话，最重要的，也是唯二需要关注备份的也就是，MySQL 数据库数据以及 Seafile 文件储存。

如果你是使用的官方的 docker-compose.yaml 进行部署的话，那么直接使用下面的命令修改对应的容器名称位置及的就可实现 volume 数据的备份，如果你自行修改了，那么也请自行修改。

#### 第一步：停止对应容器

```bash
cd /path/to/seafile/docker-compose.yaml
docker-compose down
```

#### 第二步：备份数据库

```bash
# 容器名称为 seafile-mysql 
docker run --rm --volumes-from seafile-mysql -v $(pwd):/backup busybox tar cvf /backup/backup_mysql.tar -C /var/lib/mysql ./
```

#### 第三步：备份 seafile 文件数据

```bash
# 容器名称为 seafile
docker run --rm --volumes-from seafile -v $(pwd):/backup busybox tar cvf /backup/backup_seafile.tar -C /shared ./
```

#### 第四步：传输 tar 包至新服务器

```bash
scp backup_mysql.tar root@新服务器IP:/root
scp backup_seafile.tar root@新服务器IP:/root
```

#### 第五步：恢复数据

1. 创建 MySQL 临时容器

```bash
docker create -v seafile-db-data:/data --name db_temp busybox true
```

2. 恢复 MySQL 数据库

```bash
docker run --rm --volumes-from db_temp -v $(pwd):/backup busybox tar xvf /backup/backup_mysql.tar -C data/
```

3. 创建 seafile 临时容器

```bash
docker create -v seafile-file-data:/data --name seafire_temp busybox true
```

4. 恢复 seafile 数据

```bash
docker run --rm --volumes-from seafire_temp -v $(pwd):/backup busybox tar xvf /backup/backup_seafile.tar -C data/
```

#### 第六步：`docker-compose.yaml` 中使用该 volume

如果你想在 `docker-compose.yaml` 中使用该 volume，那么就需要进行相应的配置，例如下面的修改后的文件。

```yaml
version: '2.0'
services:
  db:
    image: mariadb:10.1
    container_name: seafile-mysql
    restart: always
    environment:
      - MYSQL_ROOT_PASSWORD=db_dev  # Requested, set the root's password of MySQL service.
      - MYSQL_LOG_CONSOLE=true
    volumes:
      # 修改这里
      - mysql-db-data:/var/lib/mysql  # Requested, specifies the path to MySQL data persistent store.
    networks:
      - seafile-net

  memcached:
    image: memcached:1.5.6
    container_name: seafile-memcached
    restart: always
    entrypoint: memcached -m 256
    networks:
      - seafile-net
  seafile:
    image: seafileltd/seafile-mc:latest
    container_name: seafile
    restart: always
    # expose:
    #  - 80
    ports:
      - "8090:80"
#     - "443:443"  # If https is enabled, cancel the comment.
    volumes:
      # 修改这里
      - seafile-core-data:/shared   # Requested, specifies the path to Seafile data persistent store.
    environment:
      - DB_HOST=db
      - DB_ROOT_PASSWD=db_dev  # Requested, the value shuold be root's password of MySQL service.
      - TIME_ZONE=Etc/UTC  # Optional, default is UTC. Should be uncomment and set to your local time zone.
      - SEAFILE_ADMIN_EMAIL=me@expoli.tech # Specifies Seafile admin user, default is 'me@example.com'.
      - SEAFILE_ADMIN_PASSWORD=1234567890     # Specifies Seafile admin password, default is 'asecret'.
      - SEAFILE_SERVER_LETSENCRYPT=false   # Whether to use https or not.
      - SEAFILE_SERVER_HOSTNAME=expoli.tech # Specifies your host name if https is enabled.
    depends_on:
      - db
      - memcached
    networks:
      - seafile-net

networks:
  seafile-net:
volumes:
  mysql-db-data:
    external: # 表示使用已经存在的 volume
      name: seafile-db-data # 如果不需要可以直接注释掉着两行
  seafile-core-data:
    external: # 表示使用已经存在的 volume
      name: seafile-file-data # 如果不需要可以直接注释掉着两行
```

### 6. 参考

[](https://www.pbeta.me/docker-volume-migrate/ "Docker volume 跨服务器迁移")
