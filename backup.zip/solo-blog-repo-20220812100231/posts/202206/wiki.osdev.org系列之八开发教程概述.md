title: wiki.osdev.org 系列之（八）- 开发教程概述
date: '2022-06-11 12:16:09'
updated: '2022-06-11 21:39:58'
tags: [OS, osdev]
permalink: /articles/2022/06/11/1654920969652.html
---
![](https://b3logfile.com/bing/20200906.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

这个 wiki 上有几个与操作系统开发相关的教程。此页面是周围教程的概述，按主题领域和难度排序。

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) - 非常基础或易于理解的教程。先试试这些。

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) - 一些比较难的主题的教程，但是仍然很好做。先做一些简单的事情可能是个好主意。

[![Difficulty 3.png](https://wiki.osdev.org/images/c/c1/Difficulty_3.png)](https://wiki.osdev.org/File:Difficulty_3.png) - 高级主题教程。不建议初学者使用。

[![Difficulty 4.png](https://wiki.osdev.org/images/a/a3/Difficulty_4.png)](https://wiki.osdev.org/File:Difficulty_4.png) - 关于非常困难的主题的教程。大师班。祝你好运！

## Kernel Basics

### Bare Bones

这些是“基本”教程，将为您提供一个基本内核，它足够安全，可以作为您自己的起点。

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Bare Bones](https://wiki.osdev.org/Bare_Bones "Bare Bones") - Write a basic 32-bit kernel in C for x86

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [User:Zesterer/Bare Bones](https://wiki.osdev.org/User:Zesterer/Bare_Bones "User:Zesterer/Bare Bones") - Write a basic 32-bit kernel in C for x86 (improved tutorial by zesterer)

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Stivale Bare Bones](https://wiki.osdev.org/Stivale_Bare_Bones "Stivale Bare Bones") - Write a simple 64-bit [higher half kernel](https://wiki.osdev.org/Higher_Half_Kernel "Higher Half Kernel") using the [Limine](https://wiki.osdev.org/Limine "Limine") bootloader.

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Meaty Skeleton](https://wiki.osdev.org/Meaty_Skeleton "Meaty Skeleton") - Template operating system

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Higher Half x86 Bare Bones](https://wiki.osdev.org/Higher_Half_x86_Bare_Bones "Higher Half x86 Bare Bones") - A tutorial that shows how to write a [higher half kernel](https://wiki.osdev.org/Higher_Half_Kernel "Higher Half Kernel")

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Setting Up Long Mode](https://wiki.osdev.org/Setting_Up_Long_Mode "Setting Up Long Mode") - Switching to long mode

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Creating a 64-bit kernel](https://wiki.osdev.org/Creating_a_64-bit_kernel "Creating a 64-bit kernel") - An introduction to 64-bit kernels

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Real mode assembly bare bones](https://wiki.osdev.org/Real_mode_assembly_bare_bones "Real mode assembly bare bones") - A tutorial series on writing a basic assembly language kernel

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Pascal Bare Bones](https://wiki.osdev.org/Pascal_Bare_Bones "Pascal Bare Bones") - A basic kernel in Pascal

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Ada Bare bones](https://wiki.osdev.org/Ada_Bare_bones "Ada Bare bones") - A tutorial on writing a basic kernel in Ada

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [FreeBasic Bare Bones](https://wiki.osdev.org/FreeBasic_Bare_Bones "FreeBasic Bare Bones") - A basic kernel in FreeBasic

We also have bare bones for other platforms

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [GameBoy Advance Barebones](https://wiki.osdev.org/GameBoy_Advance_Barebones "GameBoy Advance Barebones") - A tutorial on writing a basic GBA kernel

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Sparc Barebones](https://wiki.osdev.org/Sparc_Barebones "Sparc Barebones") - A basic kernel for SparcStations

### Babysteps

如何在汇编中创建基本内核

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Babystep1](https://wiki.osdev.org/Babystep1 "Babystep1") - Your first boot sector.

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Babystep2](https://wiki.osdev.org/Babystep2 "Babystep2") - Writing a message using the BIOS.

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Babystep3](https://wiki.osdev.org/Babystep3 "Babystep3") - A look at machine code

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Babystep4](https://wiki.osdev.org/Babystep4 "Babystep4") - Printing to the screen without the BIOS

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Babystep5](https://wiki.osdev.org/Babystep5 "Babystep5") - Interrupts

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Babystep6](https://wiki.osdev.org/Babystep6 "Babystep6") - Entering protected mode

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Babystep7](https://wiki.osdev.org/Babystep7 "Babystep7") - Unreal Mode

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Babystep8](https://wiki.osdev.org/Babystep8 "Babystep8") - 32-bit printing

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Appendix A](https://wiki.osdev.org/Real_mode_assembly_appendix_A "Real mode assembly appendix A") - Additional information

### Other kernels

这些教程涵盖了可选的内核设计。这些主要是针对使用其他地方没有涉及的语言的开发人员，或者设计方法与Babysteps和Bare Bones教程中给出的方法有很大不同的开发人员。

[![Difficulty 3.png](https://wiki.osdev.org/images/c/c1/Difficulty_3.png)](https://wiki.osdev.org/File:Difficulty_3.png) A [Java Primer](https://wiki.osdev.org/Java_Primer "Java Primer") on dealing with languages in general and Java in particular that would normally be unsuitable for OS development.

处理一般语言和特别是 Java 的 Java Primer，这些语言通常不适合 OS 开发。

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) A [C# Bare Bones](https://wiki.osdev.org/C_Sharp_Bare_Bones "C Sharp Bare Bones") tutorial, using a language not typically used in OS development.

#### Third Party Tutorials （第三方教程）

本节涵盖与 wiki 和论坛无关的教程。鉴于周围的教程数量众多，没有办法列出它们的完整列表，因此这仅限于讨论中最常出现的那些。之所以在此处列出它们，是因为其中大多数主要关注操作系统开发的早期步骤。

此外，它们的质量存在惊人的差异，并且由于这些不是 wiki 本身的一部分，因此 wiki 没有办法确保错误得到修复或更新。

虽然这些是出于参考目的，但由于它们经常被提及，因此建议任何关注 wiki 教程的人将第三方教程作为补充而不是建议。

[![Difficulty 0.png](https://wiki.osdev.org/images/5/59/Difficulty_0.png)](https://wiki.osdev.org/File:Difficulty_0.png) [James A. Molloy&#39;s Kernel Tutorials](http://jamesmolloy.co.uk/tutorial_html/) - one of the more popular tutorials in the past, it has a number of [known issues](https://wiki.osdev.org/James_Molloy%27s_Tutorial_Known_Bugs "James Molloy's Tutorial Known Bugs"), and does not seem to be actively updating.

过去比较流行的教程之一，它有一些已知问题，并且似乎没有在积极更新。

[![Difficulty 0.png](https://wiki.osdev.org/images/5/59/Difficulty_0.png)](https://wiki.osdev.org/File:Difficulty_0.png) [BrokenThorn Operating System Development Series](http://www.brokenthorn.com/Resources/OSDevIndex.html) - Like the James Molloy series, this is a very well-known tutorial series, but one which is very dated and has a large number of [known flaws](https://wiki.osdev.org/Brokenthorn%27s_Known_Bugs "Brokenthorn's Known Bugs") that have not been corrected.

BrokenThorn 操作系统开发系列 - 与 James Molloy 系列一样，这是一个非常有名的教程系列，但它非常过时并且有大量已知缺陷尚未纠正。

[![Difficulty 0.png](https://wiki.osdev.org/images/5/59/Difficulty_0.png)](https://wiki.osdev.org/File:Difficulty_0.png) [Bran&#39;s Kernel Tutorial](http://www.osdever.net/tutorials/view/brans-kernel-development-tutorial) - a very dated, but still often referenced, tutorial from the now-moribund "Bona Fide OS Development" site. Like JAM and BrokenThorn, the code examples have many [known problems](https://wiki.osdev.org/Bran%27s_Known_Bugs "Bran's Known Bugs"), and much of the material is long out of date.

Bran's Kernel Tutorial - 一个非常过时但仍然经常被引用的教程，来自现在垂死的“Bona Fide OS Development”站点。与 JAM 和 BrokenThorn 一样，这些代码示例存在许多已知问题，而且大部分材料早已过时。

[![Difficulty 0.png](https://wiki.osdev.org/images/5/59/Difficulty_0.png)](https://wiki.osdev.org/File:Difficulty_0.png) [How to write a simple operating system](http://mikeos.sourceforge.net/write-your-own-os.html) by Mike Saunders - this is the starting point for those following the MikeOS project, an x86 real-mode system written in assembly language. and focuses on the aspects needed to get going with developing for MikeOS.

如何编写一个简单的操作系统(Mike Saunders)——这是那些关注MikeOS项目的人的起点，Mike OS是一个用汇编语言编写的x86实模式系统。并重点介绍了为MikeOS进行开发所需的方面。

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [FlingOS Getting Started video series](https://www.youtube.com/playlist?list=PLKbvCgwMcH7BX6Z8Bk1EuFwDa0WGkMnrz) - A third party series of video tutorials giving a practical start to writing your first OS (aimed at x86, full examples available in each of ASM, C and C#)

FlingOS Getting Started video series - 第三方视频教程系列，为编写您的第一个操作系统提供了一个实际的开始（针对 x86，在 ASM、C 和 C# 中都有完整的示例）

[![Difficulty 0.png](https://wiki.osdev.org/images/5/59/Difficulty_0.png)](https://wiki.osdev.org/File:Difficulty_0.png) [The Little OS Book](https://github.com/littleosbook/littleosbook) - a third-party OS demonstrator hosted on GitHub. Goes through periods of updating, and known bugs which haven't yet been fixed are listed in the repo.

GitHub上托管的第三方操作系统演示程序。经过一段时间的更新，尚未修复的已知错误会列在报告中。

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Writing a Simple Operating System — From Scratch](https://www.cs.bham.ac.uk/~exr/lectures/opsys/10_11/lectures/os-dev.pdf) (PDF) - A 2010 tutorial based on course material from a class on operating systems at the University of Birmingham, UK, written by Dr. Nicholas Blundell, the original course instructor. The tutorial was written as supplemental material for students to review before the course, and according Blundell,  *"is not intended as a replacement but rather as a stepping stone to excellent work such as the Minix project"* .

编写一个简单的操作系统——从零开始(PDF)——这是一个2010年的教程，基于英国伯明翰大学操作系统课程的教材，作者是最初的课程讲师Nicholas Blundell博士。该教程是作为学生在课程开始前复习的补充材料编写的，根据Blundell的说法，“不是为了取代，而是为了成为优秀工作的垫脚石，如Minix项目”。

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [So, You Want to Write an Operating System](https://www.osnews.com/story.php/1482/So_You_Want_to_Write_an_Operating_System) and [Climbing the Kernel Mountain](https://www.osnews.com/story/1532/) - a now-ancient series of articles from the OS News website, begun in 2002, these were many older developers' introductions to OS dev. They are well-written, but have only cursory coverage of the details, and are primarily of only historical interest today. This is included solely because they are referenced in many older posts in the forum. Note that the author later wrote a [follow-up](https://www.osnews.com/story/8162) in which he argued against developing a new kernel at all.

So, You Want to Write an Operating System and Climbing the Kernel Mountain - 来自 OS News 网站的古老系列文章，始于 2002 年，这些是许多老开发人员对 OS dev 的介绍。它们写得很好，但只是粗略地介绍了细节，而且主要是今天的历史意义。这仅是因为它们在论坛中的许多旧帖子中被引用。请注意，作者后来写了一篇后续文章，他反对开发一个新内核。

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Xv6](https://wiki.osdev.org/Xv6 "Xv6") unlike most tutorials in this list, this is a fully functional, yet simple OS. Xv6 is a modernized version of the classic Dennis Richie's and Ken Thompson's UNIX V6, written in ANSI C for the x86 protected mode, keeping the original UNIX philosophy of simplicity.

Xv6 与此列表中的大多数教程不同，这是一个功能齐全但简单的操作系统。 Xv6 是经典的 Dennis Richie 和 Ken Thompson 的 UNIX V6 的现代化版本，以 ANSI C 编写，用于 x86 保护模式，保持了原始 UNIX 的简单理念。

## Basics

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [GDT Tutorial](https://wiki.osdev.org/GDT_Tutorial "GDT Tutorial") - A guide about the [GDT](https://wiki.osdev.org/GDT "GDT")

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Interrupts tutorial](https://wiki.osdev.org/Interrupts_tutorial "Interrupts tutorial") - How set interrupts from C

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Creating A Shell](https://wiki.osdev.org/Creating_A_Shell "Creating A Shell") - A tutorial on how to write a [shell](https://wiki.osdev.org/Shell "Shell")

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Going Further on x86](https://wiki.osdev.org/Going_Further_on_x86 "Going Further on x86") - A guide that shall cover the basics of kernel internals

[![Difficulty 3.png](https://wiki.osdev.org/images/c/c1/Difficulty_3.png)](https://wiki.osdev.org/File:Difficulty_3.png) [DEMO](https://wiki.osdev.org/User:Johnburger/Demo "User:Johnburger/Demo") - A tutorial, in code and prose, on some fundamentals of the '386 (and above) and the PC platform, as an assembly language [DEMO](https://wiki.osdev.org/User:Johnburger/Demo "User:Johnburger/Demo")

## Memory Management

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Setting Up Paging](https://wiki.osdev.org/Setting_Up_Paging "Setting Up Paging") - A tutorial that deals with setting up and maintaining a system with paging enabled

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Setting Up Paging With PAE](https://wiki.osdev.org/Setting_Up_Paging_With_PAE "Setting Up Paging With PAE") - As above, but with PAE enabled

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Brendan&#39;s Memory Management Guide](https://wiki.osdev.org/Brendan%27s_Memory_Management_Guide "Brendan's Memory Management Guide") - A memory management guide to explain basic concepts

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Writing a memory manager](https://wiki.osdev.org/Writing_a_memory_manager "Writing a memory manager") - A tutorial on how to handle the RAM in a computer.

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Writing A Page Frame Allocator](https://wiki.osdev.org/Writing_A_Page_Frame_Allocator "Writing A Page Frame Allocator") - How to write a simple page frame allocator

## Processes and Threads

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Brendan&#39;s Multi-tasking Tutorial](https://wiki.osdev.org/Brendan%27s_Multi-tasking_Tutorial "Brendan's Multi-tasking Tutorial") - A kernel-space multitasking tutorial.

[![Difficulty 3.png](https://wiki.osdev.org/images/c/c1/Difficulty_3.png)](https://wiki.osdev.org/File:Difficulty_3.png) [Cooperative Multitasking](https://wiki.osdev.org/Cooperative_Multitasking "Cooperative Multitasking") - How to create a kernel-space multitasking system.

[![Difficulty 3.png](https://wiki.osdev.org/images/c/c1/Difficulty_3.png)](https://wiki.osdev.org/File:Difficulty_3.png) [Getting to User Mode](https://web.archive.org/web/20160326162854/http://xarnze.com/article/Entering%20User%20Mode)- How to context switch into user mode.

## Graphics & Video

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Drawing In Protected Mode](https://wiki.osdev.org/Drawing_In_Protected_Mode "Drawing In Protected Mode") - The basics, how to plot a pixel.

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Double Buffering](https://wiki.osdev.org/Double_Buffering "Double Buffering") - A handy way to prevent artifacts.

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [PC Screen Font](https://wiki.osdev.org/PC_Screen_Font "PC Screen Font") - Displaying text with bitmap fonts.

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Scalable Screen Font](https://wiki.osdev.org/Scalable_Screen_Font "Scalable Screen Font") - Displaying text with vector fonts.

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Loading Icons](https://wiki.osdev.org/Loading_Icons "Loading Icons") - Decoding image files to display icons.

## Booting

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Bootable Disk](https://wiki.osdev.org/Bootable_Disk "Bootable Disk") - A tutorial that explains how to create a bootable disk (USB stick) image

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Bootable CD](https://wiki.osdev.org/Bootable_CD "Bootable CD") - A tutorial that explains how to create a bootable CD

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Bootable El-Torito CD with GRUB Legacy](https://wiki.osdev.org/Bootable_El-Torito_CD_with_GRUB_Legacy "Bootable El-Torito CD with GRUB Legacy") - A tutorial that explains how to create a bootable GRUB CD

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Rolling Your Own Bootloader](https://wiki.osdev.org/Rolling_Your_Own_Bootloader "Rolling Your Own Bootloader") - Describes what steps to take when writing a bootloader.

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Writing a bootloader](https://wiki.osdev.org/Babystep1 "Babystep1") - A basic tutorial on creating a bootloader

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Writing a bootloader for UEFI](https://wiki.osdev.org/Uefi.inc "Uefi.inc") - A basic tutorial on creating a bootloader utilising UEFI

[![Difficulty 3.png](https://wiki.osdev.org/images/c/c1/Difficulty_3.png)](https://wiki.osdev.org/File:Difficulty_3.png) [Writing GRUB Modules](https://wiki.osdev.org/Writing_GRUB_Modules "Writing GRUB Modules") - A tutorial on writing modules that add custom functionality to GRUB.

## Building

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [Makefile](https://wiki.osdev.org/Makefile "Makefile") - A guided demonstration of how Makefiles can be used

[![Difficulty 3.png](https://wiki.osdev.org/images/c/c1/Difficulty_3.png)](https://wiki.osdev.org/File:Difficulty_3.png) [OS Specific Toolchain](https://wiki.osdev.org/OS_Specific_Toolchain "OS Specific Toolchain") - A guide on adapting GCC and Binutils to a platform

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [CMake Build System](https://wiki.osdev.org/CMake_Build_System "CMake Build System") - A guide demonstrating adapting KitWare's CMake Build System for building an operating system.

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [VSCode for Debugging](https://wiki.osdev.org/User:TheCool1Kevin/VSCode_Debug "User:TheCool1Kevin/VSCode Debug") - Setting up VSCode for debugging your kernel.

## Compilers

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [GCC Cross-Compiler](https://wiki.osdev.org/GCC_Cross-Compiler "GCC Cross-Compiler") - A guide that helps build GCC targeting a different platform

[![Difficulty 1.png](https://wiki.osdev.org/images/d/d3/Difficulty_1.png)](https://wiki.osdev.org/File:Difficulty_1.png) [GDC Cross-Compiler](https://wiki.osdev.org/GDC_Cross-Compiler "GDC Cross-Compiler") - Same as the previous, but this time for the D programming language.

## Executable File Formats

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [ELF Tutorial](https://wiki.osdev.org/ELF_Tutorial "ELF Tutorial") - A guide that details the process of loading ELF executables.

[![Difficulty 3.png](https://wiki.osdev.org/images/c/c1/Difficulty_3.png)](https://wiki.osdev.org/File:Difficulty_3.png) [Manually Creating an ELF Executable](https://web.archive.org/web/20140130143820/http://robinhoksbergen.com/papers/howto_elf.html) - A guide that demonstrates how ELF binaries work, and how to build one from scratch using only a hex editor.

## Porting Software

[![Difficulty 2.png](https://wiki.osdev.org/images/a/a1/Difficulty_2.png)](https://wiki.osdev.org/File:Difficulty_2.png) [Porting Newlib](https://wiki.osdev.org/Porting_Newlib "Porting Newlib") - A guide on porting a common C library to another operating system

[![Difficulty 0.png](https://wiki.osdev.org/images/5/59/Difficulty_0.png)](https://wiki.osdev.org/File:Difficulty_0.png) [Using Libsupc++](https://wiki.osdev.org/Libsupcxx "Libsupcxx") - A guide on porting libsupc++ to get more out of the features of C++

[![Difficulty 4.png](https://wiki.osdev.org/images/a/a3/Difficulty_4.png)](https://wiki.osdev.org/File:Difficulty_4.png) [Porting Python](https://wiki.osdev.org/Porting_Python "Porting Python") - A guide on porting python to another operating system
