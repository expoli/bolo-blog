title: ROT13（回转13位，英语：rotate by 13 places，有时也记为ROT-13）原理与实现
date: '2021-07-14 16:29:55'
updated: '2021-07-14 16:30:15'
tags: [CTF]
permalink: /articles/2021/07/14/1626251395121.html
---
![1200pxROT13tablewithexample.svg.png](https://oss.expoli.tech/img/JiU_1200px-ROT13_table_with_example.svg.png)

**ROT13** （**回转13位** ，英语：rotate by 13 places，有时也记为**ROT-13** ）是一种简易的[替换式密码](https://zh.wikipedia.org/wiki/%E6%9B%BF%E6%8D%A2%E5%BC%8F%E5%AF%86%E7%A0%81)。经常在CTF题目中会出现，具体的原理是将26个字母表的前13字母与后13的字母顺序进行调换，实现加解密。

闲来无事手动实现了一下。具体代码如下：

- 源代码

```python
string = "synt{5pq1004q-86n5-46q8-o720-oro5on0417r1}"

print(ord('s') - ord('f'))
i = 0

print(ord('z'))
print(ord('A'))

result = ''

for i in string:
    if ord(i) >= 65 and ord(i) <= 122:
        result += (chr(ord(i) - 13))
    else:
        result += i
print(result)

```

- 执行结果

```log
13
122
65
flag{5cd1004d-86a5-46d8-b720-beb5ba0417e1}
```
