title: CTFHub 协议流量分析题目解答
date: '2021-07-10 12:01:02'
updated: '2021-07-10 12:01:02'
tags: [CTF]
permalink: /articles/2021/07/10/1625889662126.html
---
![v228fa4dd5533c3f7112e9de2877f76168b.png](https://oss.expoli.tech/img/mav_v2-28fa4dd5533c3f7112e9de2877f76168_b.png)

1. Data

```python
import pyshark

# 打开存储的捕获文件
caps = pyshark.FileCapture('icmp_data.pcap', display_filter="icmp")

result = ''

for cap in caps:
    if(cap.ip.addr == '30.0.250.11'):
        hex_string = str(cap.icmp.data)[16:18]
        bytes_object = bytes.fromhex(hex_string) 
        ascii_String = bytes_object.decode("ASCII") 
        result+=ascii_String

print(result)
```

2. Length

```python
import pyshark

# 打开存储的捕获文件
caps = pyshark.FileCapture('icmp_len.pcap', display_filter="icmp")

result = ''

for cap in caps:
    if(cap.ip.addr == '30.0.250.11'):
        result+=chr(int(cap.icmp.data_len))

print(result)

```

3. LengthBinary

```python
import pyshark
import binascii

# 打开存储的捕获文件
caps = pyshark.FileCapture('icmp_len_binary.pcap',
                           display_filter="icmp && icmp.type == 8")

result = ''

for cap in caps:
    if(cap.icmp.data_len == '32'):
        result += '0'
    else:
        result += '1'

binary_string = result
result = binascii.unhexlify('%x' % int(binary_string, 2))

print(result)

```
