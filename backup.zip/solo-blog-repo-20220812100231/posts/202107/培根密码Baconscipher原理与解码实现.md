title: 培根密码（Bacon's cipher）原理与解码实现
date: '2021-07-14 17:10:02'
updated: '2021-07-14 17:10:02'
tags: [CTF]
permalink: /articles/2021/07/14/1626253802274.html
---
![Bacon's cipher](https://oss.expoli.tech/img/ais_https___images.ctfassets.net_jigso8mmhmq2_2j8z7lGme1cwOiGeJZ7gu1_19f7683b83cc2449139aa68ecc8d36ad_bacon_hero_1.jpeg)

# 培根密码（Bacon's cipher）

1、培根密码（Bacon's cipher），本质上是一种替换密码，根据对应转换规则进行加密解密，通过不明显的特征来隐藏明文信息；
2、培根密码加密规则，将明文中的每个字母，转换成一组五个英文字母，即可得到密文，转换规则表如下：
a   AAAAA    g      AABBA     n     ABBAA     t       BAABA
b   AAAAB    h      AABBB     o     ABBAB     u-v    BAABB
c   AAABA    i-j     ABAAA     p     ABBBA     w      BABAA
d   AAABB    k      ABAAB     q     ABBBB      x       BABAB![httpsimages.ctfassets.netjigso8mmhmq22j8z7lGme1cwOiGeJZ7gu119f7683b83cc2449139aa68ecc8d36adbaconhero1.jpeg](https://oss.expoli.tech/img/EFM_https___images.ctfassets.net_jigso8mmhmq2_2j8z7lGme1cwOiGeJZ7gu1_19f7683b83cc2449139aa68ecc8d36ad_bacon_hero_1.jpeg)

e   AABAA    l       ABABA     r      BAAAA     y       BABBA
f    AABAB    m     ABABB     s      BAAAB     z       BABBB
3、培根密码解密时，将密文进行5个字符分组，替换成对应的明文即可。
4、培根密码，通常有两种不同的转换规则，一种为即I与J、U与V使用相同的编码，一种为I与J、U与V都使用不同编码。

# 解码实现

```python
# bacon.py
ciphertext = "bacoN is one of aMerICa'S sWEethEartS. it's A dARlinG, SuCCulEnt fOoD tHAt PaIRs FlawLE"
bacon = ""
count = 0
lis = []

for i in ciphertext:
	if (ord(i)>=65 and ord(i)<=90):
		count+=1
		bacon+='B'
	elif (ord(i)>=97 and ord(i)<=122):
		count+=1
		bacon+='A'
	else:
		pass
	if (count % 5 == 0):
		if len(bacon) == 5:
			lis.append(bacon)
		bacon = ''

text = ""

for i in lis:
	if i=='AAAAA':
		text+='a'
	elif i=='AAAAB':
		text+='b'
	elif i=='AAABA':
		text+='c'
	elif i=='AAABB':
		text+='d'
	elif i=='AABAA':
		text+='e'
	elif i=='AABAB':
		text+='f'
	elif i=='AABBA':
		text+='g'
	elif i=='AABBB':
		text+='h'
	elif i=='ABAAA':
		text+='i'
	elif i=='ABAAB':
		text+='k'
	elif i=='ABABA':
		text+='l'
	elif i=='ABABB':
		text+='m'
	elif i=='ABBAA':
		text+='n'
	elif i=='ABBAB':
		text+='o'
	elif i=='ABBBA':
		text+='p'
	elif i=='ABBBB':
		text+='q'
	elif i=='BAAAA':
		text+='r'
	elif i=='BAAAB':
		text+='s'
	elif i=='BAABA':
		text+='t'
	elif i=='BAABB':
		text+='u'
	elif i=='BABAA':
		text+='w'
	elif i=='BABAB':
		text+='x'
	elif i=='BABBA':
		text+='y'
	elif i=='BABBB':
		text+='z'
	else:
		pass

for i in text:
	if(i=='x'):
		print(' ', end="")
	else:
		print(i, end="")

```
