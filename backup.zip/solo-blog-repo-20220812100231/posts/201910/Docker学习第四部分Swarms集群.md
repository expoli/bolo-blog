title: 'Docker 学习第四部分——Swarms（集群） '
date: '2019-10-08 21:37:39'
updated: '2019-10-09 10:13:16'
tags: [Note, Docker]
permalink: /articles/2019/10/08/1570541859251.html
---
![](https://oss.expoli.tech/img/bad_20190907634906629073139998.jpg) 

# Get Started, Part 4: Swarms

## 0 Prerequisites

* 安装Docker 1.13或更高版本。
    
* 如第3部分先决条件中所述获得Docker Compose。
    
* 获取Docker Machine，在适用于Mac和Windows的Docker桌面上，它已经预先安装了，因此您可以直接使用。在Linux系统上，您需要手动安装它。在没有Hyper-V功能的Windows 10的系统上，您可以使用Docker Toolbox。

* 阅读第1部分中的 orientation。
    
* 在第 2 部分中了解如何创建容器。
    
* 确保通过将 `friendlyhello` 映像推送到注册表来发布您创建的映像。我们在这里使用共享镜像。
    
* 确保映像用作已部署的容器。运行此命令，在信息中键入用户名、回购和标记：`docker run -p 80:80 username/repo:tag`，然后访问`http://localhost/`。

* 准备好第3部分中的docker-compose.yml副本。

## 1 Introduction

在第3部分中，您采用了在第2部分中编写的应用程序，并通过将其转变为服务并在此过程中将其放大5倍来定义了该应用程序应如何在生产环境中运行。

在第4部分中，您将该应用程序部署到群集上，并在多台计算机上运行。通过将多台计算机加入称为 “Dockerized”的一个  **swarm**，可以实现多容器，多计算机应用程序。

## 2 Understanding Swarm clusters

swarm 是一组运行Docker并加入集群的机器。在此之后，您将继续运行您惯用的Docker命令，但是现在它们由集群管理器在集群上执行。群集中的计算机可以是物理的也可以是虚拟的。加入群体后，它们称为节点。

群管理器可以使用多种策略来运行容器，例如“最空节点”-用容器填充利用率最低的机器。或“全局”，它可以确保每台机器恰好获得指定容器的一个实例。您可以指示群管理器在Compose文件中使用这些策略，就像您已经在使用的策略一样。

群集管理器是群集中唯一可以执行命令或授权其他计算机作为工作人员加入群集的计算机。工人只是在那里提供能力，而无权告诉其他任何计算机它可以做什么和不能做什么。

到目前为止，您一直在本地计算机上以单主机模式使用Docker。但是Docker也可以切换到集群模式，这就是启用集群的原因。立即启用群集模式会使当前计算机成为群集管理器。从那时起，Docker便在您管理的群组中运行您执行的命令，而不仅仅是在当前机器上运行。

## 3 Set up your swarm

群由多个节点组成，这些节点可以是物理机也可以是虚拟机。基本概念非常简单：运行 `docker swarm init` 以启用swarm模式并使当前计算机成为swarm管理器，然后在其他计算机上运行docker swarm join以使其作为工作程序加入swarm。在下面选择一个标签，查看在各种情况下如何播放。我们使用虚拟机来快速创建一个两机集群，并将其变成一个集群。

### 3.1 Create a cluster

#### 3.1.1 VMS ON YOUR LOCAL MACHINE (MAC, LINUX, WINDOWS 7 AND 8)

您需要一个可以创建虚拟机（VM）的管理程序，因此请为您的计算机的操作系统安装Oracle VirtualBox。

> 注意：如果您使用的是装有Hyper-V的Windows系统（例如Windows 10），则无需安装VirtualBox，而应使用Hyper-V。通过单击上方的Hyper-V选项卡，查看有关Hyper-V系统的说明。如果您使用的是Docker Toolbox，则应已将VirtualBox作为其一部分安装，因此一切顺利。

####3.1.2 VMS ON YOUR LOCAL MACHINE (WINDOWS 10)

首先，快速创建一个虚拟交换机供您的虚拟机（VM）共享，以便它们可以相互连接。

1. Launch Hyper-V Manager
2. Click **Virtual Switch Manager** in the right-hand menu
3. Click **Create Virtual Switch** of type **External**
4. Give it the name `myswitch`, and check the box to share your host machine’s active network adapter

现在，使用我们的节点管理工具docker-machine创建几个VM：

> 注意：您需要以管理员身份运行以下命令，否则您无权创建hyperv VM！

```
docker-machine create -d hyperv --hyperv-virtual-switch "myswitch" myvm1
docker-machine create -d hyperv --hyperv-virtual-switch "myswitch" myvm2
```

#### 3.1.3 LIST THE VMS AND GET THEIR IP ADDRESSES

现在，您已经创建了两个VM，分别名为myvm1和myvm2。  
  
使用此命令列出计算机并获取其IP地址。

> 注意：您需要以管理员身份运行以下命令，否则您将无法获得任何合理的输出（只有“未知”）。

```
docker-machine ls
```

这是此命令的示例输出。

```
$ docker-machine ls
NAME    ACTIVE   DRIVER       STATE     URL                         SWARM   DOCKER        ERRORS
myvm1   -        virtualbox   Running   tcp://192.168.99.100:2376           v17.06.2-ce
myvm2   -        virtualbox   Running   tcp://192.168.99.101:2376           v17.06.2-ce
```

#### 3.1.4 INITIALIZE THE SWARM AND ADD NODES

第一台计算机充当管理器，它执行管理命令并验证工作人员加入该群，第二台计算机是工作人员。

您可以使用docker-machine ssh将命令发送到您的VM。指示myvm1成为具有docker swarm init的swarm管理器，并查找如下输出：
```
$ docker-machine ssh myvm1 "docker swarm init --advertise-addr <myvm1 ip>"
Swarm initialized: current node <node ID> is now a manager.

To add a worker to this swarm, run the following command:

  docker swarm join \
  --token <token> \
  <myvm ip>:<port>

To add a manager to this swarm, run 'docker swarm join-token manager' and follow the instructions.
```

> Ports 2377 and 2376
> 在运行docker swarm init和docker swarm join命令时始终带有端口2377（群集管理端口）或根本不使用端口运行，使其默认。  
> 
> Docker-machine ls返回的机器IP地址包括端口2376，这是Docker守护程序端口。不要使用此端口，否则您可能会遇到错误。

> Having trouble using SSH? Try the --native-ssh flag
> 如果由于某种原因无法将命令发送到Swarm管理器，则Docker Machine可以让您使用自己系统的SSH。只需在调用ssh命令时指定--native-ssh标志：
```
docker-machine --native-ssh ssh myvm1 ...
```

如您所见，对docker swarm init的响应包含一个预配置的docker swarm join命令，供您在要添加的任何节点上运行。复制此命令，然后通过docker-machine ssh将其发送到myvm2，以使myvm2作为工作人员加入新的集群：

```
$ docker-machine ssh myvm2 "docker swarm join \
--token <token> \
<ip>:2377"

This node joined a swarm as a worker.
```

恭喜，您已经创建了第一批！  
  
在管理器上运行docker node ls以查看该群集中的节点：
```
$ docker-machine ssh myvm1 "docker node ls"
ID                            HOSTNAME            STATUS              AVAILABILITY        MANAGER STATUS
brtu9urxwfd5j0zrmkubhpkbd     myvm2               Ready               Active
rihwohkh3ph38fhillhhb84sk *   myvm1               Ready               Active              Leader
```

> 退出集群
> 如果要重新开始，则可以从每个节点运行 `docker swarm leave`。

## 4 Deploy your app on the swarm cluster

困难的部分结束了。现在，您只需重复第3部分中用于部署在新集群上的过程即可。只需记住，只有像myvm1这样的集群管理器才能执行Docker命令。工人只是打工的劳动力。

### 4.1 Configure a `docker-machine` shell to the swarm manager

到目前为止，您已经将Docker命令包装在docker-machine ssh中以与VM进行通信。另一个选项是运行docker-machine env  <machine>以获取并运行命令，该命令将您当前的shell配置为与VM上的Docker守护程序对话。此方法可更好地用于下一步，因为它允许您使用本地docker-compose.yml文件“远程”部署应用程序，而无需将其复制到其他地方。

键入docker-machine env myvm1，然后复制粘贴并运行作为输出的最后一行提供的命令，以配置您的shell与swarm管理器myvm1对话。

根据您是Mac，Linux还是Windows，配置 shell 程序的命令会有所不同，因此每个示例都显示在下面的选项卡上。

#### 4.1.1 DOCKER MACHINE SHELL ENVIRONMENT ON MAC OR LINUX

运行docker-machine env myvm1以获取命令以配置您的Shell与myvm1对话。

```
$ docker-machine env myvm1
export DOCKER_TLS_VERIFY="1"
export DOCKER_HOST="tcp://192.168.99.100:2376"
export DOCKER_CERT_PATH="/Users/sam/.docker/machine/machines/myvm1"
export DOCKER_MACHINE_NAME="myvm1"
# Run this command to configure your shell:
# eval $(docker-machine env myvm1)
```

运行给定命令以配置您的 shell 程序与myvm1对话。

```
eval $(docker-machine env myvm1)
```

运行docker-machine ls来验证myvm1现在是活动的计算机，如旁边的星号所示。

```
$ docker-machine ls
NAME    ACTIVE   DRIVER       STATE     URL                         SWARM   DOCKER        ERRORS
myvm1   *        virtualbox   Running   tcp://192.168.99.100:2376           v17.06.2-ce
myvm2   -        virtualbox   Running   tcp://192.168.99.101:2376           v17.06.2-ce
```

#### 4.1.2 DOCKER MACHINE SHELL ENVIRONMENT ON WINDOWS

运行docker-machine env myvm1以获取命令以配置您的Shell与myvm1对话。

```
PS C:\Users\sam\sandbox\get-started> docker-machine env myvm1
$Env:DOCKER_TLS_VERIFY = "1"
$Env:DOCKER_HOST = "tcp://192.168.203.207:2376"
$Env:DOCKER_CERT_PATH = "C:\Users\sam\.docker\machine\machines\myvm1"
$Env:DOCKER_MACHINE_NAME = "myvm1"
$Env:COMPOSE_CONVERT_WINDOWS_PATHS = "true"
# Run this command to configure your shell:
# & "C:\Program Files\Docker\Docker\Resources\bin\docker-machine.exe" env myvm1 | Invoke-Expression
```

运行给定命令以配置您的外壳程序与myvm1对话。

```
& "C:\Program Files\Docker\Docker\Resources\bin\docker-machine.exe" env myvm1 | Invoke-Expression
```

运行docker-machine ls以验证myvm1是活动计算机，如旁边的星号所示。

```
PS C:PATH> docker-machine ls
NAME    ACTIVE   DRIVER   STATE     URL                          SWARM   DOCKER        ERRORS
myvm1   *        hyperv   Running   tcp://192.168.203.207:2376           v17.06.2-ce
myvm2   -        hyperv   Running   tcp://192.168.200.181:2376           v17.06.2-ce
```

### 4.2 Deploy the app on the swarm manager

现在您有了myvm1，您可以通过使用在第3部分中对myvm1使用的同一 `docker stack deploy` 命令以及您的`docker-compose.yml` 本地副本，使用其作为群集管理器的功能来部署应用程序。此命令可能需要几秒钟才能完成，并且部署需要一些时间才能使用。在集群管理器上使用 `docker service ps service_name` 命令来验证是否已重新部署所有服务。

您已通过docker-machine shell配置连接到myvm1，并且仍然可以访问本地主机上的文件。确保您与以前在同一目录中，其中包括您在第3部分中创建的docker-compose.yml文件。

与之前一样，运行以下命令将应用程序部署在myvm1上。

```
docker stack deploy -c docker-compose.yml getstartedlab
```

就是这样，该应用程序已部署在 swarm 集群中！

> 注意：如果您的映像存储在私有注册表而非Docker Hub上，则需要使用docker login your-registry登录，然后需要在上述命令中添加--with-registry-auth标志。例如：
> ```
> docker login registry.example.com
> 
> docker stack deploy --with-registry-auth -c docker-compose.yml getstartedlab
> ```
> 这将使用加密的WAL日志将登录令牌从您的本地客户端传递到部署服务的swarm节点。有了这些信息，节点便能够登录到注册表并提取映像。

现在，您可以使用在第3部分中使用的相同docker命令。仅这次，请注意，服务（及关联的容器）已在myvm1和myvm2之间分发。
```
$ docker stack ps getstartedlab

ID            NAME                  IMAGE                   NODE   DESIRED STATE
jq2g3qp8nzwx  getstartedlab_web.1   gordon/get-started:part2  myvm1  Running
88wgshobzoxl  getstartedlab_web.2   gordon/get-started:part2  myvm2  Running
vbb1qbkb0o2z  getstartedlab_web.3   gordon/get-started:part2  myvm2  Running
ghii74p9budx  getstartedlab_web.4   gordon/get-started:part2  myvm1  Running
0prmarhavs87  getstartedlab_web.5   gordon/get-started:part2  myvm2  Running
```
> 使用docker-machine env和docker-machine ssh连接到VM
> - 要将您的外壳设置为与诸如myvm2之类的其他计算机通信，只需在相同或不同的外壳中重新运行docker-machine env，然后运行给定命令以指向myvm2。这总是特定于当前的shell。如果更改为未配置的外壳程序或打开新的外壳程序，则需要重新运行命令。使用docker-machine ls列出机器，查看它们所处的状态，获取IP地址，并找出您连接的机器（如果有）。要了解更多信息，请参阅Docker Machine入门主题。
> - 另外，您也可以将Docker命令包装为docker-machine ssh machine“ command”形式，该命令可以直接登录到VM，但不能立即访问本地主机上的文件。
> - 在Mac和Linux上，您可以使用 `docker-machine scp <file> <machine>:~` 跨机器复制文件，但是Windows用户需要像Git Bash这样的Linux终端模拟器才能工作。
> 
> 本教程演示了docker-machine ssh和docker-machine env，因为它们可通过docker-machine CLI在所有平台上使用。

### 4.3 Accessing your cluster

您可以从myvm1或myvm2的IP地址访问您的应用程序。

您创建的网络在它们和负载平衡之间共享。运行docker-machine ls来获取您的VM的IP地址，并在端口4000上的浏览器中访问它们中的任何一个，以进行刷新（或只是 `curl` 它们）。

![Hello World in browser](https://docs.docker.com/get-started/images/app-in-browser-swarm.png)

有五个可能的容器ID都通过随机循环显示，证明了负载平衡。

两个IP地址都起作用的原因是，群集中的节点参与了入口路由网格。这样可以确保在群集中某个端口上部署的服务始终将端口保留给自己使用，而不管容器实际运行在哪个节点上。这是一个在三节点集群上的端口8080上发布的名为my-web的服务的路由网格的外观图：

![routing mesh diagram](https://docs.docker.com/engine/swarm/images/ingress-routing-mesh.png)

> Having connectivity trouble?
> 请记住，要在群集中使用入口网络，在启用群集模式之前，需要在群集节点之间打开以下端口：
> * Port 7946 TCP/UDP for container network discovery.
> * Port 4789 UDP for the container ingress network.
> 仔细检查网络服务下“端口”部分中的内容，并确保在浏览器或curl中输入的IP地址能够反映出

## 5 Iterating and scaling your app

从这里您可以完成在第2部分和第3部分中学到的所有内容。  
  
通过更改docker-compose.yml文件来扩展应用程序。  
  
通过编辑代码来更改应用程序的行为，然后重新生成并推送新图像。 （为此，请按照之前构建应用程序并发布图像的相同步骤进行操作）。

无论哪种情况，只需再次运行docker stack deploy即可部署这些更改。  
  
您可以使用在myvm2上使用的同一docker swarm join命令将任何物理或虚拟机加入该群集，然后将容量添加到群集。稍后再运行docker stack deploy，您的应用程序就可以利用新资源。

## 6 Cleanup and reboot
### 6.1 Stacks and swarms

您可以使用docker stack rm拆除堆栈。例如：
```
docker stack rm getstartedlab
```
> Keep the swarm or remove it?
> 在以后的某个时刻，如果要在工作进程上使用docker-machine ssh myvm2“ docker swarm l”，在管理器上使用docker-machine ssh myvm1“ docker swarm离开--force”，则可以删除此集群。聚集到第5部分，因此暂时保留它。

### 6.2 Unsetting docker-machine shell variable settings

您可以使用给定命令在当前shell中取消设置docker-machine环境变量。

On **Mac or Linux** the command is:

```
  eval $(docker-machine env -u)
```

On **Windows** the command is:

```
  & "C:\Program Files\Docker\Docker\Resources\bin\docker-machine.exe" env -u | Invoke-Expression
```

这会断开外壳与docker-machine创建的虚拟机的连接，并允许您现在使用本机docker命令（例如，在Mac的Docker Desktop或Windows的Docker Desktop上）在同一 shell 中继续工作。要了解更多信息，请参阅关于设置环境变量的计算机主题。

### 6.3 Restarting Docker machines

如果关闭本地主机，则Docker计算机将停止运行。您可以通过运行docker-machine ls来检查机器的状态。


```
$ docker-machine ls
NAME    ACTIVE   DRIVER       STATE     URL   SWARM   DOCKER    ERRORS
myvm1   -        virtualbox   Stopped                 Unknown
myvm2   -        virtualbox   Stopped                 Unknown
```
要重新启动已停止的计算机，请运行：

```
docker-machine start <machine-name>
```

For example:

```
$ docker-machine start myvm1
Starting "myvm1"...
(myvm1) Check network to re-create if needed...
(myvm1) Waiting for an IP...
Machine "myvm1" was started.
Waiting for SSH to be available...
Detecting the provisioner...
Started machines may have new IP addresses. You may need to re-run the `docker-machine env` command.

$ docker-machine start myvm2
Starting "myvm2"...
(myvm2) Check network to re-create if needed...
(myvm2) Waiting for an IP...
Machine "myvm2" was started.
Waiting for SSH to be available...
Detecting the provisioner...
Started machines may have new IP addresses. You may need to re-run the `docker-machine env` command.
```

[On to Part 5 >>](https://docs.docker.com/get-started/part5/)

## 7 Recap and cheat sheet (optional)

Here’s [a terminal recording of what was covered on this page](https://asciinema.org/a/113837):

在第4部分中，您了解了群是什么，群中的节点如何成为管理者或工作者，如何创建群并在其上部署应用程序。您已经看到Docker的核心命令在第3部分中没有变化，只需要针对它们即可在群集主服务器上运行。您还看到了Docker联网的强大功能，即使在不同的计算机上运行这些容器，也可以在各个容器之间保持负载平衡请求。最后，您学习了如何在集群上迭代和扩展应用程序。

您可能需要运行以下命令来与群集和VM进行一些交互：

```bash
docker-machine create --driver virtualbox myvm1 # Create a VM (Mac, Win7, Linux)
docker-machine create -d hyperv --hyperv-virtual-switch "myswitch" myvm1 # Win10
docker-machine env myvm1                # View basic information about your node
docker-machine ssh myvm1 "docker node ls"         # List the nodes in your swarm
docker-machine ssh myvm1 "docker node inspect <node ID>"        # Inspect a node
docker-machine ssh myvm1 "docker swarm join-token -q worker"   # View join token
docker-machine ssh myvm1   # Open an SSH session with the VM; type "exit" to end
docker node ls                # View nodes in swarm (while logged on to manager)
docker-machine ssh myvm2 "docker swarm leave"  # Make the worker leave the swarm
docker-machine ssh myvm1 "docker swarm leave -f" # Make master leave, kill swarm
docker-machine ls # list VMs, asterisk shows which VM this shell is talking to
docker-machine start myvm1            # Start a VM that is currently not running
docker-machine env myvm1      # show environment variables and command for myvm1
eval $(docker-machine env myvm1)         # Mac command to connect shell to myvm1
& "C:\Program Files\Docker\Docker\Resources\bin\docker-machine.exe" env myvm1 | Invoke-Expression   # Windows command to connect shell to myvm1
docker stack deploy -c <file> <app>  # Deploy an app; command shell must be set to talk to manager (myvm1), uses local Compose file
docker-machine scp docker-compose.yml myvm1:~ # Copy file to node's home dir (only required if you use ssh to connect to manager and deploy the app)
docker-machine ssh myvm1 "docker stack deploy -c <file> <app>"   # Deploy an app using ssh (you must have first copied the Compose file to myvm1)
eval $(docker-machine env -u)     # Disconnect shell from VMs, use native docker
docker-machine stop $(docker-machine ls -q)               # Stop all running VMs
docker-machine rm $(docker-machine ls -q) # Delete all VMs and their disk images
```
