title: 配置ssh登录docker centos
date: '2018-11-17 15:18:08'
updated: '2018-11-17 15:18:08'
tags: [Docker]
permalink: /articles/2018/11/17/1564656235228.html
---
![image253c8cc990eb60be.png](./18-11-17-docker-sshd-in-centos/image253c8cc990eb60be.png)

## 配置ssh登录docker-centos
<!-- more -->
### 安装 openssh-server

```bash
$ yum install openssh-server openssh-clients
$ whereis sshd  # /usr/sbin/sshd
```

这个时候如果执行 `/usr/sbin/sshd` 会报错、需要手动生成key

```bash
$ ssh-keygen -f /etc/ssh/ssh_host_rsa_key
$ ssh-keygen -t dsa -f /etc/ssh/ssh_host_dsa_key
############
# 缺少什么 key 就生成什么 key
$ ssh-keygen -t ecdsa -f /etc/ssh/ssh_host_ecdsa_key
$ ssh-keygen -t ed25519 -f /etc/ssh/ssh_host_ed25519_key
```

这个时候再运行 `/usr/sbin/sshd` 就可以了

参考：[http://www.winseliu.com/blog/2014/09/30/docker-ssh-on-centos/](http://www.winseliu.com/blog/2014/09/30/docker-ssh-on-centos/)