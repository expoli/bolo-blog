title: 为Nginx配置 SSL 证书 + 开启 HTTPS网站
date: '2018-10-26 13:15:08'
updated: '2018-10-26 13:15:08'
tags: [Git]
permalink: /articles/2018/10/26/1564656232712.html
---
![image.png](./18-10-26-add-ssl-on-nginx/image.png)

### 1. SSL背景介绍

<!-- more -->

谷歌从 2017 年起，Chrome 浏览器将也会把采用 HTTP 协议的网站标记为「不安全」网站；苹果从 2017 年 iOS App 将强制使用 HTTPS；在国内热火朝天的小程序也要求必须使用 HTTPS 请求。

### 2. SSL证书类型
通常来说，SSL 证书分为三大类，他们的安全性是递增的，当然价格和安全系数成正比。

```bash
DV （Domain Validation Certificate） 
DV 证书适合个人网站使用，申请证书时，CA 只验证域名信息。几分钟之内就能签发。

OV （ Organization Validation Certificate） 
OV 证书需要认证公司的信息。1-2天签发。

EV （ Extended Validation Certificate）
EV 证书的认证最为严格，一般会要求提供纸质材料。签发时间也较久。
```
### 申请方法
* 在这里提供几个免费SSL申请渠道
    * 七牛提供申请免费SSL的渠道
    * 阿里云域名服务提供的免费SSL证书
        * 完成后将证书和key内容复制出来！
        * 然后(如果文件、目录不存在要自行创建)：
        * 将第一部分内容复制到 `/var/cert/yourserver name.crt`文件中！
        * 将第二部分内容复制到`/var/cert/yourservername.key`文件中！

### 为了确保更强的安全性，我们可以采取 `迪菲－赫尔曼密钥交换`
进入 `/var/cert/`目录并生成一个 `yourservername.pem`

```bash
cd /var/cert/
openssl dhparam -out yunfeng365.pem 2048 
# 如果你的机器性能足够强大，可以用 4096 位加密
```

### 文件准备完毕后，进行Nginx 配置！

* 在你网站nginx配置文件目录中（eg: /etc/nginx/nginx.conf )

*  配置80端口301跳转

```bash
server {                                                                        
        listen 80 default_server;                                               
                                                                                
        # Make site accessible from http://localhost/                           
        server_name zzutcy.top;                                                 
        server_name www.zzutcy.top;                                             
        return 301 https://zzutcy.top$request_uri;                              
}                                                                               
                                                                                
    server {                                                                    
        listen       80;                                                        
        server_name  localhost;                                                 
                                                                                
        #charset koi8-r;                                                        
                                                                                
        #access_log  logs/host.access.log  main;                                
                                                                                
        location / {
            root   /var/www/hexo;                                               
            index  index.html index.htm;                                        
        }                                                    
```

### ssl配置

```bash
        server {                                                                
                listen 443;                                                     
                server_name zzutcy.top;                                         
                server_name www.zzutcy.top;                                     
                                                                                
        # ssl设置                                                              
        ssl on;                                                                 
        ssl_certificate /var/cert/zzutcy.crt;                                   
        ssl_dhparam /var/cert/zzutcy.pem;                                       
        ssl_certificate_key /var/cert/zzutcy.key;                               
                                                                                
        ssl_session_timeout 5m;                                                 
                                                                                
        ssl_protocols SSLv3 TLSv1 TLSv1.1 TLSv1.2;                              
        ssl_ciphers "HIGH:!aNULL:!MD5 or HIGH:!aNULL:!MD5:!3DES";               
        ssl_prefer_server_ciphers on;     

                                      
         // 你的站点配置                                                                     
         location / {                                                           
            root   /var/www/hexo;                                               
            index  index.html index.htm;                                        
        }
}
```

### 重启Nginx使配置生效！

```bash
$ sudo systemctl restart nginx
```

[参考链接🔗->简书：霄峰](https://www.jianshu.com/p/e7c7b23a92b4)