title: 自建 Git server
date: '2018-10-26 12:35:08'
updated: '2018-10-26 12:35:08'
tags: [Git]
permalink: /articles/2018/10/26/1564656233812.html
---
![image80bf17d0f7b49f6e.png](./18-10-26-how-to-buid-a-git-server/image80bf17d0f7b49f6e.png)

## 什么是 GitHub

<!-- more -->

GitHub就是一个免费托管开源代码的远程仓库。但是对于某些视源代码如生命的商业公司来说，既不想公开源代码，又舍不得给GitHub交保护费，那就只能自己搭建一台Git服务器作为私有仓库使用。

## 前期准备
* 准备一台运行Linux的机器。
    * 假设你已经有sudo权限的用户账号，下面，正式开始安装。

## 开始安装
### 第一步，安装git：

```bash
$ sudo apt-get install git
```

### 第二步，创建一个git用户，用来运行git服务：

```bash
$ sudo adduser git
```
### 第三步，创建证书登录：

* 收集所有需要登录的用户的公钥，就是他们自己的`id_rsa.pub` 文件，把所有公钥导入到 `/home/git/.ssh/authorized_keys` 文件里，**一行一个**。

### 第四步，初始化Git仓库：

* 先选定一个目录作为Git仓库，假定是`/home/git/sample.git`，在 `/home/git` 目录下输入命令：

```bash
$ sudo git init --bare sample.git
```
Git就会创建一个裸仓库，裸仓库没有工作区，因为服务器上的Git仓库纯粹是为了共享，所以不让用户直接登录到服务器上去改工作区，并且服务器上的Git仓库通常都以.git结尾

* 然后，把owner改为git：

```bash
$ sudo chown -R git:git sample.git
```
### 第五步，禁用shell登录：

出于安全考虑，第二步创建的git用户不允许登录shell，这可以通过编辑 `/etc/passwd` 文件完成。找到类似下面的一行：

```bash
git:x:1001:1001:,,,:/home/git:/bin/bash
```
改为：
```bash
git:x:1001:1001:,,,:/home/git:/usr/bin/git-shell
```

这样，git用户可以正常通过ssh使用git，但无法登录shell，因为我们为git用户指定的git-shell每次一登录就自动退出。

### 第六步，克隆远程仓库：

现在，可以通过git clone命令克隆远程仓库了，在各自的电脑上运行：

```bash
$ git clone git@server:/srv/sample.git
# Cloning into 'sample'...
# warning: You appear to have cloned an empty repository.
```
剩下的推送就简单了。

### 管理公钥

* 如果团队很小，把每个人的公钥收集起来放到服务器的/home/git/.ssh/authorized_keys文件里就是可行的。如果团队有几百号人，就没法这么玩了，这时，可以用 `Gitosis`来管理公钥。

### 管理权限

有很多不但视源代码如生命，而且视员工为窃贼的公司，会在版本控制系统里设置一套完善的权限控制，每个人是否有读写权限会精确到每个分支甚至每个目录下。因为Git是为Linux源代码托管而开发的，所以Git也继承了开源社区的精神，不支持权限控制。不过，因为Git支持钩子（hook），所以，可以在服务器端编写一系列脚本来控制提交等操作，达到权限控制的目的。Gitolite就是这个工具。

这里也不介绍Gitolite了，不要把有限的生命浪费到权限斗争中。

[参考链接🔗->廖雪峰的网站](https://www.liaoxuefeng.com/wiki/0013739516305929606dd18361248578c67b8067c8c017b000/00137583770360579bc4b458f044ce7afed3df579123eca000)