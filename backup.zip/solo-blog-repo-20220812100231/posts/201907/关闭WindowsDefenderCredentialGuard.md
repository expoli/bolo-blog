title: 关闭 Windows Defender Credential Guard
date: '2019-07-29 21:47:08'
updated: '2019-08-19 19:51:20'
tags: [Windows]
permalink: /articles/2019/07/29/1564656219981.html
---
# 关闭 Windows Defender Credential Guard

## 系统环境

- Windows 10 专业工作站版
- VirtualBox 6.0.10 for Windows
- VMware Workstation Pro 15.1.0 for Windows
- Hyper-V 已关闭
- 虚拟化已开启

## 问题现象

新装的系统、一开始使用的是 `VirtualBox 6.0.10 for Windows` 在配置好镜像什么了之后、启动失败，错误代码已经忘记了、在确认了 `Hyper-V 已关闭` `虚拟化已开启` `VMware Workstation Pro 15.1.0 for Windows` 也无法正常启动虚拟机之后，经搜索发现、关闭 `Windows Defender Credential Guard` 可以解决这个问题。

## 如何关闭 Windows Defender Credential Guard

### 使用组策略禁用 Windows Defender Credential Guard

1. 在组策略管理控制台上，转到计算机配置 -> 管理模板 -> 系统 -> Device Guard。

2. 双击打开基于虚拟化的安全，然后单击禁用选项。

![2019-07-29-window10Windows-Defender-Credential-Guard.png](http://tc.expoli.tech/images/2019/07/29/2019-07-29-window10Windows-Defender-Credential-Guard.png)

3. 确定配置并重启电脑。

4. 打开虚拟机进行启动测试

微软官方指导文档：[https://docs.microsoft.com/zh-cn/windows/security/identity-protection/credential-guard/credential-guard-manage#%E7%A6%81%E7%94%A8-windows-defender-credential-guard](https://docs.microsoft.com/zh-cn/windows/security/identity-protection/credential-guard/credential-guard-manage#%E7%A6%81%E7%94%A8-windows-defender-credential-guard)