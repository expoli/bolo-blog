title: Windows docker Errror mkdir /host_mnt/ file exists
date: '2019-07-27 14:46:08'
updated: '2019-07-27 14:46:08'
tags: [Docker, 坑]
permalink: /articles/2019/07/27/1564656215566.html
---
# 总结之——Windows docker Errror mkdir /host_mnt/c: file exists 

## 原来遇到过这个问题、但是时间比较长、问题没办法复现了、在这里贴一个解决方案

github Issues:[https://github.com/docker/for-win/issues/1560](https://github.com/docker/for-win/issues/1560)


### 问题详细信息

```bash
Expected behavior
Container should start normally

Actual behavior
C:\Users\einom>docker start f96263b10996
Error response from daemon: error while creating mount source path '/host_mnt/c/Users/einom/Documents/projects/cap/src': mkdir /host_mnt/c: file exists
Error: failed to start containers: f96263b10996

Information
Docker version: 17.12.0-ce-win47 (15139)

Windows 10 Pro
Version: 1709
Build: 16299.192

Whole C drive is shared with docker VM

Steps to reproduce the behavior
start container with command similar than me in my home dir
docker run -d --name sonarqube -p 9000:9000 -p 9092:9092 -v c:/Users/einom/Documents/projects/cap/src:/src:rw sonarqube
use container and enjoy that directory in container /src is mounted OK
docker stop this container
docker start container ... and you got error ... mkdir /host_mnt/c file exist.
Of cource it exists because if I understand correctly this /host_mnt/c should point to my whole C: drive ?
```

### 解决方案

通过点击 Windows docker 上的 `Rest credentials` 即可、如下图：

![Rest credentials](https://user-images.githubusercontent.com/33459309/38609289-96062c54-3d75-11e8-936d-ae59ff07811c.png)