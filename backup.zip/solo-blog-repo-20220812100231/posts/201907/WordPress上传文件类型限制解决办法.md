title: WordPress上传文件类型限制解决办法
date: '2019-07-30 17:47:08'
updated: '2019-08-19 19:48:17'
tags: [WordPress]
permalink: /articles/2019/07/30/1564656221047.html
---
# WordPress上传文件类型限制解决办法

## 0. 问题出现的原因

自从博客迁移到 wordpress 以后，除了图片以外、就还没有上传过其他类型的文件，然后今天想上传一个 *.sh 文件，结果提示：`上传类型限制，暂不支持的类型`。。

？？？？？？？

说实话、我还不知道 wordpress 还有这个保护机制、长见识了；能感觉到默认打开这个限制是出于好心、但是确实很不方便、因为限制确实有点多了，毕竟一般上传的文件，作用肯定是自己知道的，一般肯定不会有人给自己站上传恶意脚本的吧（hhhhh）。

## 1. 解决办法

这种错误是由于WordPress中做了文件上传格式的限制，这种限制可以在WordPress 根目录中的 `wp-include/functions.php的get_allowed_mime_types` 函数中找到，函数如下：

![2019-07-30-WordPress.png](http://tc.expoli.tech/images/2019/07/30/2019-07-30-WordPress.png)

以上传入 `apply_filters` 函数中的 Array，即使允许上传的类型列表，可以修改这个地方，以禁止或允许可以上传的文件类型。

例如我们想要允许rar文件上传，只需添加一行格式说明即可：

```php
'rar' => 'application/rar',
```

除了直接修改这个Array外，还有另外一种方法，可以修改根路径下的 `wp-config.php` 文件，在其中增加一行语句：

```php
define('ALLOW_UNFILTERED_UPLOADS', true);
```

强制刷新一下、然后再次尝试上传文件一下即可