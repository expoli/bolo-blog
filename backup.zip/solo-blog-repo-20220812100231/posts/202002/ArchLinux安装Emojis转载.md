title: Arch Linux 安装 Emojis（转载）
date: '2020-02-07 19:17:20'
updated: '2020-03-14 21:01:59'
tags: [Arch, Emojis]
permalink: /articles/2020/02/07/1581074240634.html
---
# Arch Linux 安装 Emojis（转载）

原文链接：https://www.reddit.com/r/archlinux/comments/9q8dlj/how_to_better_enable_color_emojis/

今天电脑突然死机，鼠标键盘无用，tty也打不开，只能强制关机，在群里问了一下，好像是网易云的问题，原来使用的是Arch Linux cn 源内的网易云，后经大佬推荐发现了一个网易云的第三方版本`iease-music`，安装之后感觉画面还是很不错的，很漂亮，于是果断卸载了网易云。
![image.png](https://img.hacpai.com/file/2020/02/image-9abc1d83.png)

唯一每中不足的便是菜单中的emojis表情显示不全。后续了解到虽然系统中的`Fontconfig`附带了一些配置文件，但是这些配置文件根本不足以全局启用Emojis表情符号（`45-generic.conf`和`60-generic.conf`），仅安装`Noto Color Emoji`字体也不会在所有网站或某些应用程序上启用彩色表情符号。

但大多数情况下（并不是所有情况下）可以通过创建`fontconfig`配置文件，将`Noto Color Emoji`字体设置为默认表情符号字体来轻松解决这个问题。

## 1. 安装字体

```
sudo pacman -S noto-fonts-emoji
```

## 2. 在`/etc/fonts/conf.avail/`中创建`75-noto-color-emoji.conf`文件

文件内容如下

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE fontconfig SYSTEM "fonts.dtd">
<fontconfig>

    <!-- Add generic family. -->
    <match target="pattern">
        <test qual="any" name="family"><string>emoji</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <!-- This adds Noto Color Emoji as a final fallback font for the default font families. -->
    <match target="pattern">
        <test name="family"><string>sans</string></test>
        <edit name="family" mode="append"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test name="family"><string>serif</string></test>
        <edit name="family" mode="append"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test name="family"><string>sans-serif</string></test>
        <edit name="family" mode="append"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test name="family"><string>monospace</string></test>
        <edit name="family" mode="append"><string>Noto Color Emoji</string></edit>
    </match>

    <!-- Block Symbola from the list of fallback fonts. -->
    <selectfont>
        <rejectfont>
            <pattern>
                <patelt name="family">
                    <string>Symbola</string>
                </patelt>
            </pattern>
        </rejectfont>
    </selectfont>

    <!-- Use Noto Color Emoji when other popular fonts are being specifically requested. -->
    <match target="pattern">
        <test qual="any" name="family"><string>Apple Color Emoji</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>Segoe UI Emoji</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>Segoe UI Symbol</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>Android Emoji</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>Twitter Color Emoji</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>Twemoji</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>Twemoji Mozilla</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>TwemojiMozilla</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>EmojiTwo</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>Emoji Two</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>EmojiSymbols</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

    <match target="pattern">
        <test qual="any" name="family"><string>Symbola</string></test>
        <edit name="family" mode="assign" binding="same"><string>Noto Color Emoji</string></edit>
    </match>

</fontconfig>
```

## 3.  现在，通过发出以下命令启用以上功能

`sudo ln -sf /etc/fonts/conf.avail/75-noto-color-emoji.conf /etc/fonts/conf.d/`

## 4. 截图展示

![wl7tsnzskmt11.png](https://img.hacpai.com/file/2020/02/wl7tsnzskmt11-d438a5dd.png)

![bylh8dzskmt11.png](https://img.hacpai.com/file/2020/02/bylh8dzskmt11-3e500dfd.png)

