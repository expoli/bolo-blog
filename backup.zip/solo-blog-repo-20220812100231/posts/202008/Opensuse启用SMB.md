title: Opensuse 启用SMB
date: '2020-08-28 22:21:56'
updated: '2020-08-28 22:21:56'
tags: [SMB, Linux]
permalink: /articles/2020/08/28/1598624516448.html
---
![image.png](https://oss.expoli.tech/img/9le_image.png)


最近 使用了 Opensue Arm版本的系统，在树莓派上启用了SMB、总体感觉良好。在这里记录一下相应的步骤、防止遗忘。

## 1 启用 samba

### 1.1 修改 samba 配置文件

```conf
[global]
        workgroup = 你局域网的工作组名字
        passdb backend = tdbsam
        security =user
```

2. 添加路径共享

```conf
[pi_data]
        comment = pi_data
        guest ok = No
        inherit acls = Yes
        path = /data
        read only = No
        createmask = 0664
        directorymask = 0775
        validusers = nisuser01,nisuser02,nisuser03,smbuser1
        write list = nisuser02,smbuser1
[yysmb02]
        comment =yynfs02
        path =/mnt/hyyfs/nfs02
        writeable= yes
        public =yes
        guest ok =yes
```

3. 添加用户（如果你上一步允许的用户不存在的话）

```shell
useradd -d /home/smbuser1 -m smbuser1
```

4. 将用户添加至SMB系统中

```shell
$ smbpasswd -a smbuser1
New SMB password:
Retype new SMB password:
Added user smbuser1.
```

5. 检查配置参数

```
# testparm -v
Load smb config files from /etc/samba/smb.conf
rlimit_max: increasing rlimit_max (1024) to minimumWindows limit (16384)
Loaded services file OK.
Server role: ROLE_STANDALONE
Press enter to see a dump of your servicedefinitions
```

6. mount 硬盘时指定 uid gid

```
mount -o uid=1000,gid=1000 /dev/sda2 /data/nfs/HDD1T/
```

## 2. 开启防火墙

1. 添加放行服务

终端输入 `yast2` 开启管理员配置面板，将你所需要的服务与协议打勾加到允许列表中。

![image.png](https://oss.expoli.tech/img/g3f_image.png)

2. 对相应的网络接口启用配置域

![image.png](https://oss.expoli.tech/img/TZJ_image.png)

## 4. 连接测试


