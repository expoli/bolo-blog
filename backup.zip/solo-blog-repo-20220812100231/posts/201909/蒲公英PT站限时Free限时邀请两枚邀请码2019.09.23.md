title: 蒲公英PT站限时Free、限时邀请两枚邀请码 2019.09.23
date: '2019-09-22 09:40:53'
updated: '2019-09-24 23:01:36'
tags: [蒲公英PT, 宣传]
permalink: /articles/2019/09/22/1569116453457.html
---
# [![Show/Hide](https://npupt.com/pic/trans.gif)喜迎新中国70周年大庆全站限时Free和限时邀请送沙粒活动 2019.09.23])

全站Free开始时间 **2019年09月23日 20:00**  
全站Free结束时间 **2019年10月08日 00:00**  
无人机及以上用户每人有限时邀请两枚，不限制邮箱哦~  
限时邀请失效时间  **2019年09月26日 00:00**  
PS: 不要注册小号，否则根据蒲公英站规，大号、小号均会被封禁~  

（需要邀请码的哥哥姐姐们可以给我发送访问 [https://test-ipv6.com](https://test-ipv6.com) 成功的截图、具体示例可以看评论区，邮箱 ❤️ **me@@expoli.com(保留一个@）**❤️ 

❤️ 存货售空。❤️ 

---

## 蒲公英开放注册&站务招募&发邀送沙粒 2019.07.02（IP v6）

（内附站长本人的推荐链接）[https://npupt.com/promotionlink.php?key=ccbade09cc9ca4192a9a4ce60f9b5f3a](https://npupt.com/promotionlink.php?key=ccbade09cc9ca4192a9a4ce60f9b5f3a)

<a href="https://npupt.com/promotionlink.php?key=ccbade09cc9ca4192a9a4ce60f9b5f3a"><img src="https://npupt.com/pic/prolink.png" alt="蒲公英PT站" title="蒲公英PT站 - One for All, All for One"></a>

欢迎大家向朋友们推荐蒲公英，PT需要的入门知识站内都有，无需大家仔细介绍，只需将网站链接发送给好友即可 。
选择自助邀请的同学可以在登录页面点击“注册”，按照提示输入edu邮箱(@*.edu.cn)或ac邮箱(@*.ac.cn)即可自行注册，邀请他人时邮箱不限域名。  
**西北工业大学的同学**无需使用邮箱，可以点击登录页面的 **注册 - 绿色通道，直接创建账号。**  
**[点击这里学习注册常见edu邮箱](https://npupt.com/edumail.php)**（没有账号也可以打开该链接）  
  
若长时间无法收到邮件，请在 **其它文件夹/垃圾邮件** 处仔细查看。  
邀请已发送但未收到注册邮件的请加答疑群（149401812）解决。  
  
[**蒲公英开放注册&站务招募&发邀送沙粒（点我）**](https://npupt.com/forums.php?action=viewtopic&topicid=7728&page=p69011#pid69011)![[em38]](https://npupt.com/pic/smilies/ani/38.gif)

[![https://npupt.com/promotionlink.php?key=ccbade09cc9ca4192a9a4ce60f9b5f3a](https://npupt.com/mybar.php?userid=77447.png)](https://npupt.com/promotionlink.php?key=ccbade09cc9ca4192a9a4ce60f9b5f3a)


