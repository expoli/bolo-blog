title: Centos7 更新内核版本
date: '2022-05-04 16:29:11'
updated: '2022-05-04 17:08:17'
tags: [Linux, Centos7]
permalink: /articles/2022/05/04/1651652951905.html
---
![howtoupgradekernelincentos7.png](https://oss.expoli.tech/img/8BL_how-to-upgrade-kernel-in-centos-7.png)

# 1. 检查自己的内核版本

```shell
uname -msr
```

```shell
Linux 3.10.0-1160.el7.x86_64 x86_64
```

# 2. 更新所有软件到最新版本

```shell
yum update
```

# 3. 开启 ELRepo

```shell
sudo rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
sudo rpm -Uvh https://www.elrepo.org/elrepo-release-7.0-3.el7.elrepo.noarch.rpm
```

# 4. 查看可用的内核版本

```shell
yum list available --disablerepo='*' --enablerepo=elrepo-kernel
```

# 5. 安装新版本的内核

```shell
sudo yum --enablerepo=elrepo-kernel install kernel-ml
```

其中 `ml` 代表主线，`lt` 代表长期支持版本。

# 6. 设置 grub 默认启动项

## 6.1 查看默认的 grub 配置

可以看到默认的 grub 配置中的 `GRUB_DEFAULT=saved` 此项配置的功能是使用上次你选择的 grub 启动项，如果你想让它重启就使用默认的最新启动项，你只需要将此项的值设置为 `0` 即可。

```shell
cat /etc/default/grub 
GRUB_TIMEOUT=5
GRUB_DISTRIBUTOR="$(sed 's, release .*$,,g' /etc/system-release)"
GRUB_DEFAULT=saved
GRUB_DISABLE_SUBMENU=true
GRUB_TERMINAL_OUTPUT="console"
GRUB_CMDLINE_LINUX="crashkernel=auto rd.lvm.lv=centos/root rd.lvm.lv=centos/swap rhgb quiet"
GRUB_DISABLE_RECOVERY="true"
```

```shell
sed "s/saved/0/g" /etc/default/grub 
GRUB_TIMEOUT=5
GRUB_DISTRIBUTOR="$(sed 's, release .*$,,g' /etc/system-release)"
GRUB_DEFAULT=0
GRUB_DISABLE_SUBMENU=true
GRUB_TERMINAL_OUTPUT="console"
GRUB_CMDLINE_LINUX="crashkernel=auto rd.lvm.lv=centos/root rd.lvm.lv=centos/swap rhgb quiet"
GRUB_DISABLE_RECOVERY="true"
```

# 7. 懒人版本

```shell
yum update -y
sudo rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
sudo rpm -Uvh https://www.elrepo.org/elrepo-release-7.0-3.el7.elrepo.noarch.rpm
yum list available --disablerepo='*' --enablerepo=elrepo-kernel
sudo yum --enablerepo=elrepo-kernel install  kernel-lt kernel-lt-headers -y
sed -i "s/saved/0/g" /etc/default/grub 
sudo grub2-mkconfig -o /boot/grub2/grub.cfg
sudo reboot now
```
