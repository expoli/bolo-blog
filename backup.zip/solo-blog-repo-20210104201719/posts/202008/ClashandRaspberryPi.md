title: Clash and Raspberry Pi
date: '2020-08-30 12:02:41'
updated: '2020-09-03 10:27:25'
tags: [clash, Linux]
permalink: /articles/2020/08/30/1598760161095.html
---
![image.png](https://oss.expoli.tech/img/gR2_image.png)

# 树莓派与 `Clash`

今天把Clash更换到了树莓派上面，也算是让树莓派承担应有的任务、给他增加点负载、要不然空耗电多“浪费”。这里做一下记录。

## 安装 `clash`

1. 下载clash

Clash GitHub地址为：https://github.com/Dreamacro/clash/releases。

我的设备是 3B+，选择的v7，根据需要自己选择就行。

![image.png](https://oss.expoli.tech/img/26L_image.png)

2. 解压到自己喜欢的目录
3. 进行启动测试
4. 修改配置文件
   
   配置文件默认地址为：`$(username)/.config/clash/config.yaml`,根据自己的需要进行更换或修改。
5. 防火墙放行所需要的端口
   
   ```bash
   vim /etc/firewalld/services/clash.xml
   ```
   
   ```xml
   <?xml version="1.0" encoding="utf-8"?>
   <service>
     <description>This a clash client service!</description>
     <port port="7890" protocol="tcp"/>
     <port port="7891" protocol="tcp"/>
     <port port="9090" protocol="tcp"/>
   </service>
   ```
   
   ```bash
   firewall-cmd --permanent --add-service=clash --zone=
   firewall-cmd --reload
   firewall-cmd --list-all --zone=
   ```
6. 连接测试
   配置需代理设备，进行连接测试，确保能够正常工作。
7. 建立systemd 服务，设置开机自启。
   在 `/usr/lib/systemd/system/`目录下创建 `clash@.service` 文件

```bash
sudo vim /usr/lib/systemd/system/clash@.service
```

```
[Unit]
Description=A rule based proxy in Go for %i.
After=network.target

[Service]
Type=simple
User=%i
Restart=on-abort
ExecStart=clash二进制文件路径

[Install]
WantedBy=multi-user.target
```

## 为用户帐户运行 clash 系统实例

#### 重新加载 `systemd` 模块

```shell
systemctl daemon-reload
```

#### 启动 `clash` 服务

> `user` 表示的是当前用户名

```shell
systemctl start clash@user
```

例如：

```shell
systemctl start clash@expoli
```

#### 设置开机自启

```shell
systemctl enable clash@user
```

## clash Dashboard

因Clash运行在树莓派上、一般都不会直接给树莓派连接鼠标键盘和显示器，我是用Clash Dashboard实现对Clash的控制，项目地址：https://github.com/haishanh/yacd。

可直接下载文件解压后打开 `index.html`本地运行，设置好服务端地址即可连接、保存书签后能够安全快捷的进行面板的访问。

![image.png](https://oss.expoli.tech/img/XSb_image.png)

## 透明 proxy

使用 `firewall-cmd` 实现、先行测试、如果失败了直接`sudo firewall-cmd --reload`进行恢复，测试完成后，再进行持久化处理，`proxy_port`自行替换设置。

1. 非持久化

```bash
sudo firewall-cmd --direct --add-chain ipv4 nat clash
sudo firewall-cmd --direct --add-rule ipv4 nat clash 1 -d 0.0.0.0/8 -j RETURN
sudo firewall-cmd --direct --add-rule ipv4 nat clash 1 -d 10.0.0.0/8 -j RETURN
sudo firewall-cmd --direct --add-rule ipv4 nat clash 1 -d 127.0.0.0/8 -j RETURN
sudo firewall-cmd --direct --add-rule ipv4 nat clash 1 -d 169.254.0.0/16 -j RETURN
sudo firewall-cmd --direct --add-rule ipv4 nat clash 1 -d 172.16.0.0/12 -j RETURN
sudo firewall-cmd --direct --add-rule ipv4 nat clash 1 -d 192.168.0.0/16 -j RETURN
sudo firewall-cmd --direct --add-rule ipv4 nat clash 1 -d 224.0.0.0/4 -j RETURN
sudo firewall-cmd --direct --add-rule ipv4 nat clash 1 -d 240.0.0.0/4 -j RETURN
sudo firewall-cmd --direct --add-rule ipv4 nat clash 2 -p tcp -j REDIRECT --to-ports "$proxy_port"
sudo firewall-cmd --direct --add-rule ipv4 nat PREROUTING 0 -p tcp -j clash
```

2. 持久化

```bash
sudo firewall-cmd --permanent --direct --add-chain ipv4 nat clash
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat clash 1 -d 0.0.0.0/8 -j RETURN
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat clash 1 -d 10.0.0.0/8 -j RETURN
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat clash 1 -d 127.0.0.0/8 -j RETURN
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat clash 1 -d 169.254.0.0/16 -j RETURN
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat clash 1 -d 172.16.0.0/12 -j RETURN
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat clash 1 -d 192.168.0.0/16 -j RETURN
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat clash 1 -d 224.0.0.0/4 -j RETURN
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat clash 1 -d 240.0.0.0/4 -j RETURN
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat clash 2 -p tcp -j REDIRECT --to-ports "$proxy_port"
sudo firewall-cmd --permanent --direct --add-rule ipv4 nat PREROUTING 0 -p tcp -j clash
sudo firewall-cmd --reload
```

