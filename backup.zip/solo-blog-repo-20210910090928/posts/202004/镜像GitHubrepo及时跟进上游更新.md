title: 镜像 GitHub repo 及时跟进上游更新
date: '2020-04-01 17:38:25'
updated: '2021-02-28 08:44:38'
tags: [bolo, Github]
permalink: /articles/2020/04/01/1585733905842.html
---
![v22848ff3c46e0e5c77e2537de003d345ar.jpg](https://oss.expoli.tech/img/GOi_v2-2848ff3c46e0e5c77e2537de003d345a_r.jpg)

# 镜像 GitHub repo 及时跟进上游更新

今天说一下如何镜像一个 GitHub repo，相信大家有时候会用到类似于 GitLab 的 repo mirror 功能（定期拉取上游 repo 至本地，同步上游更新）。

但是 GitHub 上并没有相似的功能，今天就介绍一下如何在 GitHub 上实现类似的功能、（如果你 fork 了一个 repo，然后你想让自己的 repo 跟进上游的开发之类的）不过这需要你有一个能联网的服务器（能够定时运行git push）就行。

## 1. fork 原仓库

这个大家肯定都知道，点击一下这个按钮然后等待网页完成跳转就可以了。😄

![](https://oss.expoli.tech/img/20200401170958.png)

## 2. 添加部署密钥

1. 在自己的项目页里面找到fork的仓库。

![](https://oss.expoli.tech/img/20200401171406.png)

2. 点击项目的设置、添加该主机的 SSH 部署密钥，并且保证此部署密钥拥有对此项目的读写权限。配置方法如下图：

![](https://oss.expoli.tech/img/20200401171631.png)

## 3. 克隆上游项目克隆至部署机器

```bash
git clone https://github.com/adlered/bolo-solo.git
```

## 4. 添加远程地址（自己的）

以 bolo 项目为例，先手动测试一下、如果没发现问题的话、那就可以放心的写定时任务了：

```bash
cd bolo-solo
git remote add mirror git@github.com:expoli/bolo-solo.git
git pull origin
git push mirror --mirror
```

## 5. 编写定时任务

```bash
# vim /var/spool/cron/$(你的用户名)
# 例如
vim /var/spool/cron/root
```

我的项目路径在 /opt/github-mirror/bolo-solo/ 根据自己的需要进行更改

```
# .---------------- minute (0 - 59) 
# |  .------------- hour (0 - 23)
# |  |  .---------- day of month (1 - 31)
# |  |  |  .------- month (1 - 12) OR jan,feb,mar,apr ... 
# |  |  |  |  .---- day of week (0 - 6) (Sunday=0 or 7)  OR
#sun,mon,tue,wed,thu,fri,sat 
# |  |  |  |  |
# *  *  *  *  *  command to be executed
# 每两个小时
  0 */2 *  *  *  cd /opt/github-mirror/bolo-solo/ && git pull origin && git push expoli --mirror
```

## 6. 适用场景

我是因为想偷懒，不想自己手动构建bolo镜像，于是想出来了这个办法，使用docker hub 进行自动构建，我只需要坐享其成就可👀 👀 👀 。
