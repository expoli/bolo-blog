title: Linux 下 zip 文件解压乱码的解决方案
date: '2020-01-10 16:21:18'
updated: '2020-01-10 16:21:18'
tags: [坑, Linux]
permalink: /articles/2020/01/10/1578644478113.html
---
# Linux 下 zip 文件解压乱码的解决方案

由于 zip 格式中并没有指定编码格式，Windows 下生成的 zip 文件中的编码是 GBK/GB2312 等，因此，导致这些 zip 文件在 Linux 下解压时出现乱码问题，因为 Linux 下的默认编码是 UTF8。所以经常会导致解压出来的文件名乱码导致没有办法很好的使用。

## 解决方案

使用包管理器安装 `p7zip`  和  `convmv` 这两个包。

安装完之后，就可以用 7za 和 convmv 两个命令完成解压缩任务。

```shell
LANG=C 7za x your-zip-file.zip
convmv -f GBK -t utf8 --notest -r .
```

第一条命令用于解压缩，而 LANG=C 表示以 US-ASCII 这样的编码输出文件名，如果没有这个语言设置，它同样会输出乱码，只不过是 UTF8 格式的乱码(convmv 会忽略这样的乱码)。

第二条命令是将 GBK 编码的文件名转化为 UTF8 编码，-r 表示递归访问目录，即对当前目录中所有文件进行转换。最终可以得到正常的文件夹与文件名。
