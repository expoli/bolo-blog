title: Visual studio code 远程开发环境配置
date: '2021-06-22 19:57:26'
updated: '2021-06-23 08:56:20'
tags: [待分类]
permalink: /articles/2021/06/22/1624363046533.html
---
![VSCode.png](https://oss.expoli.tech/img/Wec_VSCode.png)

# Visual studio code 远程开发环境配置

## 1. 远程连接所需插件

- [Remote Development - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=ms-vscode-remote.vscode-remote-extensionpack)

这是一个软件包组合

## 2. Git 相关插件

- [Git Graph - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=mhutchie.git-graph)
- [GitLens — Git supercharged - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=eamodio.gitlens)
- [GitHub Pull Requests and Issues - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=GitHub.vscode-pull-request-github)

## 3. Markdown 相关

- [Markdown All in One - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=yzhang.markdown-all-in-one)
- [Markdown PDF - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=yzane.markdown-pdf)]

## 4. latex 相关

- [LaTeX Workshop - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=James-Yu.latex-workshop)
- [LaTeX language support - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=torn4dom4n.latex-support)

## 5. bash 开发环境

- [BASH Extension Pack - Visual Studio Marketplace](https://marketplace.visualstudio.com/items?itemName=lizebang.bash-extension-pack)

这是一个软件包组合
