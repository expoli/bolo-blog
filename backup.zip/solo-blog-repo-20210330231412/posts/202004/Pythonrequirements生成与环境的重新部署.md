title: Python requirements 生成与环境的重新部署
date: '2020-04-26 15:06:42'
updated: '2020-05-07 23:12:15'
tags: [Python]
permalink: /articles/2020/04/26/1587884802206.html
---
# Python requirements 生成与环境的重新部署

最近在做毕业设计的时候，有很多同学让帮忙做环境配置。所以把自己的开发环境分享给其他人，保证双方开发环境的一致性，保证代码的可用性。

而在分享的时候发现使用 `pip` 直接安装的与使用 `anaconda` 安装的包，还不一致，无法通用。

## 使用 pip 直接安装

### 使用 requirements.txt 分享

生成 requirements.txt

```
pip freeze > requirements.txt
```

### 恢复原环境

```
pip install -r requirements.txt
```

## 使用 anaconda 生成的虚拟环境

使用 anaconda 进行虚拟环境配置时，anaconda 中的软件版本与 Pypi 官方库中的版本并不一致。官网推荐了分享环境的配置。

### 生成 environment.yml

[https://docs.conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html#sharing-an-environment](https://docs.conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html#sharing-an-environment)

```
conda env export > environment.yml
```

### 使用 environment.yml 恢复虚拟环境

```
conda env create -f environment.yml
```
