title: Arch Linux 跨时段更新指南
date: '2022-01-04 15:46:52'
updated: '2022-01-04 15:48:37'
tags: [Arch]
permalink: /articles/2022/01/04/1641282412282.html
---
![escwk.jpg](https://oss.expoli.tech/img/XyD_escwk.jpg)

众所周知，Arch 是一个使用滚动更新机制的发行版，在你经常使用 Arch 的时候，你可能会每天都记得每日更新技能：

```bash
sudo pacman -Syyu
```

那么问题来了：我要是好久没用 `Arch` 了，那么我应该如何避免大家喜闻乐见的 `滚挂` 的情况呢？下面就 Arch 的跨时段更新问题，提供一个实践性指南（经过我本人测试过得、能够正常运行的方案）。

# 首先更新 `keyring` 包

所谓的 `keyring` 包，就是官方的 `Arch Linux PGP keyring` 包，保存了 `Arch linux` 系统的打包者的公钥集合，当我们在安装包与更新系统的时候，需要验证对应包的数字签名，以保证包的安全性。

如果对应的 `keyring` 脱离上游太久，可能导致密钥失效或者缺少对应包的验证公钥，然后就会一直提示你是否信任与导入相应的公钥（脱离上游时间越久，失效密钥越多，会导致你无法顺利更新系统）。

所以我们需要首先 **部分更新** 一下 `keyring` 包、即一下两个包：

> 注意：部分更新操作在 Arch Linux 上是十分不推荐的操作，我们现在只限于修复使用。

- `archlinux-keyring`
- `archlinuxcn-keyring`

```bash
sudo pacman -Syy
sudo pacman -S archlinux-keyring archlinuxcn-keyring
```

# 然后继续进行系统更新操作

```bash
sudo pacman -Syyu
```
