title: 危险指令 pacman -Sy 的前世今生
date: '2022-01-04 15:46:52'
updated: '2022-01-04 15:46:52'
tags: [Arch, Manjaro]
permalink: /articles/2022/01/04/1641283754635.html
---
![image.png](https://oss.expoli.tech/img/jg0_image.png)

相信使用 `Arch Linux` 的同学们对，`pacman` 可能再熟悉不过了，可能也会在窥屏听大佬谈论时，听到大佬们狠狠批评的那些使用 `pacman` 部分更新操作的教程，但我相信一定还有朋友们像我一样，只知道这个命令危险，不要轻易去使用它，但是可能并不知道它具体究竟危险在哪里。同时以前使用 `-Sy` 安装软件的 `Manjaro` 系统，也广受诟病。

因原来只知其然而不知其所以然，同时碰巧看到了 `苯大佬` 的解释，在这里记录一下：

> 原始链接：https://t.me/manjarolinux_cn/191900

# 核心内容：

`-Sy` 是最不可取的， `pacman -Sy package` 是说是首先同步软件仓库，然后安装 `package`，这样做的风险是违反了Arch系不支持部分更新的原则，也就是你同步仓库以后，只安装了你要的包的最新版，却没有给系统里当前已装的其他包都升级，就会造成部分更新的效果。

`-Syu` 后面接包就是安装包并且升级系统里所有的包，就能保证整个系统都是最新，`-S` 的话不更新本地仓库数据安装，也就是要符合你系统上次同步仓库时的最新状态。

```plaintext
Astro Benzene, [1/3/22 8:47 PM]
[In reply to Sakura masiro]
我先问一句，你为什么要用-Sy来安装东西

我的意思是，-Sy这个选项组合你是从哪里看到的

Sakura masiro, [1/3/22 8:51 PM]

似乎很多地方都是-Sy

Astro Benzene, [1/3/22 8:51 PM]
我的妈呀

Astro Benzene, [1/3/22 8:51 PM]
很多地方？

Sakura masiro, [1/3/22 8:51 PM]
嗯

Sakura masiro, [1/3/22 8:52 PM]
用-S很少

Astro Benzene, [1/3/22 8:52 PM]
这种ArchWiki上明确指出的危险操作到底是怎么传开的……

Astro Benzene, [1/3/22 8:52 PM]
最正确的操作是-Syu

Astro Benzene, [1/3/22 8:52 PM]
-S尚可

Astro Benzene, [1/3/22 8:52 PM]
-Sy是最不可取的

Astro Benzene, [1/3/22 8:53 PM]
pacman -Sy package 是说是首先同步软件仓库，然后安装package

Astro Benzene, [1/3/22 8:53 PM]
这样做的风险是违反了Arch系不支持部分更新的原则

Astro Benzene, [1/3/22 8:54 PM]
也就是你同步仓库以后，只安装了你要的包的最新版，却没有给系统里当前已装的其他包都升级，就会造成部分更新的效果

Astro Benzene, [1/3/22 8:55 PM]

-Syu后面接包就是安装包并且升级系统里所有的包

Astro Benzene, [1/3/22 8:56 PM]
就能保证整个系统都是最新

Astro Benzene, [1/3/22 8:57 PM]

-S的话不更新本地仓库数据安装，也就是要符合你系统上次同步仓库时的最新状态
```
