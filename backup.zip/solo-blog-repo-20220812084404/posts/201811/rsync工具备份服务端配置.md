title: rsync 工具备份服务端配置
date: '2018-11-18 19:46:08'
updated: '2018-11-18 19:46:08'
tags: [rsync, 运维]
permalink: /articles/2018/11/18/1564656235928.html
---
![image6b88b0a6195169dd.png](./18-11-18-how-to-set-rsync-server/image6b88b0a6195169dd.png)

# 在服务器端安装和配置rsync
<!-- more -->
## 1.安装rsync
* 如已默认安装，请卸载旧版本

```bash
$ sudo yum remove rsync -y
```

### RPM 安装

* ### RPM方式的好处，快速、方便、节时，具体安装如下：
```bash
$ yum -y install rsync
```

* ### rsync文件：

```bash
/etc/rsyncd.conf
/etc/sysconfig/rsyncd
/etc/xinetd.d/rsync
/usr/bin/rsync
/usr/share/doc/rsync-3.1.2/COPYING
......
```

## 2.关于rsync认证方式

rsync有2种常用的认证方式，一种是rsync-daemon，另一种是SSH。

在生产环境中，通常使用rsync-daemon认证模式。

### 认证模式说明：

* 1.rsync-daemon认证：默认监听TCP的873端口。前提是双方都需要安装rsync，客户端可不启动rsync服务，但需要简单的配置。服务器端需要启动且需在服务器端配置rsync。

* 2.SSH认证：通过系统用户认证，即在rsync上通过SSH隧道进行传输，前提是需要服务器端与客户端建立无密码登录。
    * 无需服务器与客户端配置rsync，也无需启动rsync服务，只需双方都安装rsync即可。

## 3.配置服务端

### 1.设置rsync服务端密码文件 192.168.0.2

* 使用rsync-daemon认证方式。创建访问密码，格式为用户名:密码，一行一个，明文。

**命令**

```bash
$ sudo echo "renwole:renwolecom"  >>/etc/rsync.password
$ sudo chmod 600 /etc/rsync.password                    # 注意权限必须是 600 否则会报错
```

### 2.5.配置rsync服务端配置文件 192.168.0.2

配置文件所在目录： `/etc/rsyncd.conf`

```bash
$ sudo vim /etc/rsyncd.conf
```

```bash
uid = root               # 运行RSYNC守护进程的用户
gid = root               # 运行RSYNC守护进程的组
port = 873               # 默认端口
#address = 10.28.204.65  # 服务器IP地址
# pid file = /var/run/rsyncd.pid    # 进程启动后，进程号存放路径     centos 7 若不注释会报错
lock file　=　/var/run/rsync.lock   # 设置锁文件名称
log file = /var/log/rsyncd.log      # 指定rsync的日志文件
                                    # 这两个文件在配置过后系统会自己创建
use chroot = no             # 不使用chroot
read only = yes             # 只读,不让客户端上传文件到服务器
transfer logging = yes      # 将传输操作记录到传输日志文件

hosts allow=192.168.0.3             # 允许哪些主机访问（多个以空格隔开）
hosts deny=*                        # 拒绝哪些主机访问
max connections = 3                 # 最大连接数
# motd file = /etc/rsyncd.motd      # 登陆欢迎信息（生产环境不建议)

log format = %t %a %m %f %b        # 指定日志记录的格式
syslog facility = local3           # 消息级别
timeout = 600                      # 会话超时时间。

[BackupServer]              # 模块的名称，可以自定义    后续客户端进行同步的时候会使用到
path = /xxx/xxx             # 需要同步的目录
list=yes                    # 是否允许用户列出文件,默认为true
ignore errors               # 忽略错误信息
# exclude = myrenwole/      # 不同步的目录（多个以空格隔开）
comment = BackupServer      # 注释内容，任意
auth users = backup         # 那些用户才允许连接该模块，多个以,隔开     此用户是你上一步配置密码文件所设置的用户
secrets file = /etc/rsyncs.password    # 认证时所需的密码文件
```

### 注意：全局配置中的选项对所有模块有效；模块下定义的仅对当前模块有效；另外，模块中定义选项值优先于全局配置。

## 4.设置防火墙

```bash
$ sudo firewall-cmd --add-port=873/tcp --permanent
$ sudo firewall-cmd --add-port=873/udp --permanent
$ sudo firewall-cmd --reload
```

## 5.启动并加入开机自启动

```bash
$ sudo systemctl start rsyncd       # 开启
$ sudo systemctl enable rsyncd      # 开启守护进程
$ sudo systemctl list-unit-files    # 查看系统所有服务的状态
```