title: 为 Openwrt 添加温度显示功能
date: '2019-03-22 10:46:08'
updated: '2020-05-11 22:13:03'
tags: [Openwrt]
permalink: /articles/2019/03/22/1564656238463.html
---
![](https://oss.expoli.tech/img/ZZr_201712148862868661819698837.jpg) 

# 为 Openwrt 添加温度显示功能**(不支持最新19*版本)**

## 19.* 版本推荐 `luci-app-statistics` 插件  
  
安装对应的收集信息的模块即可  
  
![QQ图片20200511220547.png](https://oss.expoli.tech/img/ZFx5Xd4e55)

使用效果
![QQ图片20200511220948.png](https://oss.expoli.tech/img/eQTuaDmQW1)

### 当然若想实现温度的收集，则需要机器有着相应的传感器支持，否则就只能像我这样为空了。

![QQ图片20200511221244.png](https://oss.expoli.tech/img/b2APjcFv0P)


## 日常开篇闲聊

原来的 Openwrt 软路由在使用一段时间后，在经过了一开始的疯狂测试（疯狂折腾）之后，软路由工作状态趋于稳定；但是平时使用的时候发现工控机的温度比较高，类似于暖宝宝那种。emmm 确实有点暖和。。

## 明确问题

既然温度有点高，那就加散热系统吧，于是将工控机放在了机柜的风扇了，但是现在问题来了：温度高但是具体高到了什么程度呢？在管理界面居然不能够查看查看当前CPU温度（啊啊啊）有点难受。

所以现在的目标就是：在管理界面显示当前CPU的温度

## 说干就干

### 带着问题寻找解决方案

既然已经明确了问题那么下一步就是寻找解决方案了。

下面就讲一下我寻找解决方案的过程吧：

1. 估计是我的思维定式吧，我第一个想到的就是 Openwrt 的插件中心，于是抱着试试的心态去 Openwrt 官方网站查看有没有类似的插件。emmmm 找了一段时间、唔，看来是没有了，于是请出万能工具：Google，Baidu（我左手谷歌右手百度斩杀BUG无数，（其实我很少写bug的，因为写的不多O(∩_∩)Ohhh

2. 在经过强大的搜索引擎搜索之后，然后找到了一个看着比较靠谱的解决方案，而且使用的人比较多：即修改 `/usr/lib/lua/luci/view/admin_status/index.htm` 文件，添加 `luci.sys.exec("你要执行的命令")` 字段，然后通过运行 `Linux` 下的相关命令达到查看 CPU 温度的目的。

### 测试并实施解决方案

在找到解决方案之后，就是测试方案是否可行了。

1. 配置软件环境
   1. 首先 ssh 登陆路由器，安装 `lm-sensors` 这个软件

   ```bash
   opkg update
   opkg install lm-sensors lm-sensors-detect 
   ```

   1. 运行 `sensors` 查看输出

   ```bash
   # 这是我的软路由输出
   coretemp-isa-0000       # 这些信息我们可以去掉
   Adapter: ISA adapter    # 这些信息我们可以去掉
   Core 0:       +39.0°C  (crit = +100.0°C)    # 这是我们需要的信息
   Core 1:       +39.0°C  (crit = +100.0°C)    # 这是我们需要的信息
   ```

   1. 通过分析输出，发现我们真正需要的其实是最后的2段话，这个时候我们可以使用 `tail` 命令取出第二条输出之后的信息,输出如下
   ```sh
   root@OpenWrt:~# sensors | tail -n +3
   Core 0:       +39.0°C  (crit = +100.0°C)
   Core 1:       +38.0°C  (crit = +100.0°C)
   ```
2. 修改管理界面进行显示
   1. 对 `/usr/lib/lua/luci/view/admin_status/index.htm` 文件进行备份与编辑
   ```bash
   # 备份
   mv /usr/lib/lua/luci/view/admin_status/index.htm ~/admin_status_index.htm
   # 编辑
   vim /usr/lib/lua/luci/view/admin_status/index.htm
   ```
   2. 找到 `Kernel Version ` 这一行
   3. 仿照上面的语法自己挑一个位置插入下面这句话
   ```html
   <div class="tr"><div class="td left" width="33%"><%:CPU Temperature%></div><div class="td left"><%=luci.sys.exec("sensors | tail -n +3") or "?"%></div></div>
   ```
   1. 刷新后台界面进行显示
   ![](http://tc.expoli.tech/images/2019/08/19/19-04-09-add-temp-overview-to-openwrt0.png)
3. 现在基本功能以及实现了，具体显示效果大家可以自己私人定制哈😄


