title: My first post
date: '2018-03-27 22:27:30'
updated: '2018-03-27 22:27:30'
tags: [Hexo]
permalink: /articles/2018/03/27/1564656222810.html
---
![four pacman](https://ws4.sinaimg.cn/large/006tNbRwly1fwbm9nsm5ej30hu09cdg8.jpg)

<center><big>大家好欢迎来到糖醋鱼的博客</big></center>
<!-- more -->

<center>这是我<big>第一篇</big>文章</center>
<center>文笔还需磨炼 语法还欠打磨 排版还需实践</center>
<center>欢迎大家给小鱼提出您宝贵的建议</center>
<center>第一次发博客，一些考虑不周到的，大家可以提出建议和批评</center>
<center>轻拍砖</center>

<center>最近在考虑将我的糖醋鱼这个名字改成小鲤鱼</center>
<center>自我感觉良好    O(∩_∩)O哈哈哈~</center>

<center>&raquo;<big>最后</big>
非常感谢<big>法海</big>小朋友他的极力支持</center>
<center>如果没有他的支持估计你们就看不到这篇文章了</center>

<center>不知道我能坚持写多久</center>

<center>尽力吧！</center>