title: Github Action 获取当前时间并给 docker 镜像打标签
date: '2021-01-05 10:21:07'
updated: '2021-01-05 10:21:53'
tags: [Github, Docker]
permalink: /articles/2021/01/05/1609813267677.html
---
![githubactionstop.png](https://oss.expoli.tech/img/XkL_github-actions-top.png)

# Github Action 获取当前时间并给 docker 镜像打标签

## 获取并格式化当前时间

只需在使用到时间变量之前定义以下步骤即可

```yaml
      - name: Get current date
        id: date
        run: echo "::set-output name=today::$(date +'%Y-%m-%d')"
```

## 给镜像打标签

`docker/build-push-action@v2` 支持多标签，只需要 `tangcuyu/nginx-proxy:${{ steps.date.outputs.today }}` 像这样填写即可给镜像打上相应的标签。

```yaml
      -
        name: Build and push
        uses: docker/build-push-action@v2
        with:
          context: .
          file: ./Dockerfile
          platforms: linux/amd64,linux/arm64/v8,linux/arm/v7,linux/arm/v6
          push: ${{ github.event_name != 'pull_request' }}
          tags: |
            tangcuyu/nginx-proxy:latest
            tangcuyu/nginx-proxy:${{ steps.date.outputs.today }}
```

## 成果展示

![image.png](https://oss.expoli.tech/img/j8K_image.png)
