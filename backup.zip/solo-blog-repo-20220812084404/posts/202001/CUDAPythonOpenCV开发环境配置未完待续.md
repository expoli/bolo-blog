title: CUDA、Python、OpenCV 开发环境配置 (未完待续。。。)
date: '2020-01-08 19:35:50'
updated: '2020-04-26 10:56:54'
tags: [Linux, Manjaro, Ubuntu, CUDA]
permalink: /articles/2020/01/08/1578483349973.html
---
![](https://img.hacpai.com/bing/20180211.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# CUDA、Python、OpenCV 开发环境配置 (未完待续。。。)

注：此文章的所有环境皆是在 Arch Linux 这一发行版上进行的安装、测试与使用，但是对于其它发行版仍具有很大的借鉴意义。

## 0 Windows 用户过渡用户的必要知识储备

对于一贯的 Windows 用户来说，可能对于使用 Linux 进行开发感觉有点不太理解，但对于一有着相应的经验的人来说，在 Windows 上进行类似于 OpenCV 与 CUDA 或者其它的一些的深度学习等，最终还是依靠于 Linux 系统平台的，Windows 来干这些事在我看来还是有着很大的力不从心（个人意见）。

1. 如果你是 Windows 用户，先安装个 `Python`。

Python 官网 🔗 https://www.python.org/

找到 `Python3` 的下载链接，先确定你所需要的 `Python` 版本，然后是根据自己系统版本选择相应的安装包（比如：Windows x86_64 选择 `Windows x86-64 executable installer` 版本下载安装）

安装时勾选 ✅将 Python 加入 PATH，以及后面的去除长度限制。

1. 如果没有接触过 Python 那么可以根据自己的计划花费相应的时间，熟悉一下 Python 语法，并编写一些自己喜欢的小程序，相应的 `IDE`，推荐 `pycharm` 和 `vs code`，毕竟 工欲善其事，必先利其器！

`pycharm` 官网链接 🔗 [https://www.jetbrains.com/pycharm/download/](https://www.jetbrains.com/pycharm/download/)

版本选择社区版就好，如果你有 `edu` 教育邮箱的话，也可以免费申请专业版使用。

根据自己的操作系统选择对应的安装包

1. `Linux` 是后期学习不可避免的需要接触的，但是非常不建议一开始就使用物理机进行 `Linux` 的学习，**强烈安装虚拟机管理器使用虚拟机进行学习**，这里推荐 `VirtualBox` 。

`VirtualBox` 的安装与虚拟机的配置参考我这篇文章 [https://expoli.tech/articles/2020/01/18/1579321643232.html](https://expoli.tech/articles/2020/01/18/1579321643232.html)

但是虚拟机还是有着很大的性能的损耗的，尤其是在配置不高的电脑上的表现更为明显，明显不是长久之计，所以加油吧骚年！争取早日掌握在物理机上使用 Linux 的能力。

## 1 CUDA  
  
如果你的显卡是 NVIDIA并且支持CUDA ,那么强烈简易安装 CUDA，因为这将大量减少你所花费的计算时间。

### 1.1 安装 NVIDIA 显卡驱动  
  
```bash
sudo pacman -S nvidia
```

### 1.2 创建 pacman 钩子

```
sudo vim  /etc/pacman.d/hooks/nvidia.hook 
```
将下面的输入进去，保证nvidia驱动更新的时候，内核能够正常加载nvidia驱动。
```
[Trigger]
Operation=Install
Operation=Upgrade
Operation=Remove
Type=Package
Target=nvidia
Target=linux
# Change the linux part above and in the Exec line if a different kernel is used

[Action]
Description=Update Nvidia module in initcpio
Depends=mkinitcpio
When=PostTransaction
NeedsTargets
Exec=/bin/sh -c 'while read -r trg; do case $trg in linux) exit 0; esac; done; /usr/bin/mkinitcpio -P'
```

## 2 进阶阶段 Linux 用户的开发环境配置

注：此文章的所有环境皆是在 Arch Linux 这一发行版上进行的安装、测试与使用，但是对于其它发行版仍具有很大的借鉴意义。

Arch Linux 现在默认的包组已经完全抛弃了 python2 的依赖，完全投向了 python3 的怀抱。所以我们不需要安装 python，你可以通过在终端中执行 `python -v` 来查看相应的信息。

### 2.1 使用 archlinuxcn 源

archlinuxcn 源里面存放着很多中国开发者打包好的一些很符合国人习惯的工具，（例如：QQ、微信、WPS office、SSR 等）和一些常用的 IDE（例如 pycharm、CLion 等）。

注：此软件源只在 Arch Linux 以及其衍生版（例如：Manajro）上可用，其它发行版用户可自行查询相应工具的安装方法。

具体配置方法限于篇幅可参考我另一篇文章：[Arch Linux 启用 archlinuxcn 源](https://expoli.tech/articles/2020/02/12/1581513647899.html)


### 2.2 python 环境

#### 2.2.1 pycharm

Arch Linux 安装 `pycharm`

```shell
# 查询pycharm包
sudo pacman -Ss pycharm

# 输出结果
community/pycharm-community-edition 2019.2.3-1
    Python IDE for Professional Developers
archlinuxcn/pycharm-professional 2019.3.3-1 [已安装]
    Python IDE for Professional Developers. Professional Edition

# 根据自己的需要选择对应的版本进行安装
sudo pacman -S 对应版本的包名
```

#### 2.2.2 anaconda

```shell
sudo pacman -S anaconda
```

#### 2.2.3 timeshift

```shell
sudo pacman -S timeshift
```

1. 安装 **timeshift** 备份软件，养成及时备份的好习惯，在自己安装之前与测试安装完成之后为系统做快照，防止出现意外，确保能够在出现问题时能做到 **及时回退**。

### 2.3 C++ 环境

#### 2.3.1 CLion

```shell
sudo pacman -S clion
```

安装可选依赖

```shell
sudo pacman -S --asdeps $(expac -S '%o' clion)
```


