title: Git 泄露的几种处理方法
date: '2021-05-21 08:47:48'
updated: '2021-05-21 08:47:48'
tags: [CTF]
permalink: /articles/2021/05/21/1621558068448.html
---
![1719b7e162ddd378.png](https://oss.expoli.tech/img/Cwv_1719b7e162ddd378.png)

# 工具介绍

下面介绍一下我使用的一些工具（功能都大同小异，可以自己挑选一个）

## WangYihang/GitHacker

### 项目地址

[https://github.com/WangYihang/GitHacker](https://github.com/WangYihang/GitHacker)

### 使用方法

1. 安装

`pip3 install GitHacker # -i pypi mirror repo url`

2. 使用

`githacker --url http://127.0.0.1/.git/ --folder result`

比较喜欢的是、这个工具可以自定义输出目录，可以使用 pip 直接安装

## BugScanTeam/GitHack

## 项目地址

https://github.com/BugScanTeam/GitHack

## 使用方法

下载源码包直接 python 运行即可，开箱即用、执行输出也较为美观

# 经验总结

随着做题的数量的增加，遇见的情况也逐渐复杂了起来，从一开始 `flag` 直接放在使用工具恢复的 `git` 目录下`（index类型）`、再到保存在 `commit`信息里， 再到保存再`历史commit`里面，需要手动回退一下`（log类型）`、再到保存在`stash`里面，需要手动将保存的文件`pop` 出来`（stach类型）`。

## index 类型

### 解题步骤

1. 恢复git目录

`githacker --url http://127.0.0.1/.git/ --folder result`

2. 查看恢复出的文件

`cd reasult & ls -al`

![QQ截图20210521084121.png](https://oss.expoli.tech/img/7KP_QQ截图20210521084121.png)

## log 类型

### 解题步骤

1. 恢复git目录

`githacker --url http://127.0.0.1/.git/ --folder result`

2. 查看恢复出的文件

`cd reasult & ls -al`

3. 查看git提交记录

![QQ截图20210521084121.png](https://oss.expoli.tech/img/j1l_QQ截图20210521084121.png)

4. 回退 `commit`

`git reset HEAD^`

5. 检查flag

## stash 类型

当你发现回退提交之后还是没有相应的flag信息，那么可以考虑查看 `stash`

通过执行 stash 命令的，list、show、pop 即可拿到目标文件

![QQ截图20210521084121.png](https://oss.expoli.tech/img/FH6_QQ截图20210521084121.png)
