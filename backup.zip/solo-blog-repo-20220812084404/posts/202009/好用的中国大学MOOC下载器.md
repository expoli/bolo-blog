title: 好用的中国大学MOOC下载器
date: '2020-09-03 11:46:06'
updated: '2020-09-03 11:46:45'
tags: [推荐]
permalink: /articles/2020/09/03/1599104766847.html
---
![image.png](https://oss.expoli.tech/img/ET1_image.png)

# 好用的中国大学MOOC下载器

因最近在家学习网络环境的波动、导致看MOOC在线资源很不流畅，所以就想着像以前用PT的时候、将慕课下载下来，但是自己以前用的MOOC下载器已经不知所踪了，而在搜索相应的工具的时候，发现CSDN上呢个排名贼靠前的下载器，还需要付费、VIP、关注公众号等巴拉巴拉那么多的问题，啊、心累啊。最后在经过一番试毒之后，找到了 一个比较好的下载器项目：[https://github.com/SigureMo/mooc-dl](https://github.com/SigureMo/mooc-dl)

Python 运行环境，安装依赖之后直接运行即可，可调整清晰度，挺好用的，而且还会自动生成Potplayer的播放列表，也可调整下载清晰度（具体方法阅读README即可）。

![image.png](https://oss.expoli.tech/img/k5Z_image.png)

使用愉快！

