title: 树莓派3B+配置 opencv 与 tensorflow（虚拟环境）
date: '2020-04-14 21:33:13'
updated: '2020-04-14 21:33:13'
tags: [Note, OpenCV, Tensorflow, RaspberryPi]
permalink: /articles/2020/04/14/1586871193115.html
---
![](https://img.hacpai.com/bing/20200125.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# 树莓派3B+配置 opencv 与 tensorflow（虚拟环境）

应毕业设计的要求需要、需要在树莓派上运行基于 `opencv` 与 `tensorflow` 的 `python` 环境，然后就搜索了一下发现大多数都是直接源码编译 `opencv` ，这着实让我感觉很奇怪，因为一直在开发时都是使用 `anaconda` 创建虚拟环境来确保主机的 `python` 运行环境的整洁。（因为吃过这方面的亏、使用pip安装的库python库破坏了系统的依赖，最终导致系统更新失败、对于我这个目前的水平来说，我选择相信包管理器，事实上也证明了我的选择的正确性😄 ）。

## 安装 tensorflow

参考链接：

1. https://microsoft.github.io/ELL/tutorials/Raspberry-Pi-setup/
2. https://www.tensorflow.org/install/pip?hl=zh_cn#package_location

### 创建虚拟环境

1. 安装依赖包

```shell
sudo apt update
sudo apt install python3-dev python3-pip
sudo apt install libatlas-base-dev        # required for numpy
sudo pip3 install -U virtualenv           # system-wide install
```

2. 创建一个新的虚拟环境，方法是选择 Python 解释器并创建一个 `./venv` 目录来存放它：
```shell
virtualenv --system-site-packages -p python3 ./venv
```
3. 使用特定于 shell 的命令激活该虚拟环境：
```shell
source ./venv/bin/activate  # sh, bash, ksh, or zsh
```
4. 当 virtualenv 处于有效状态时，shell 提示符带有 `(venv)` 前缀。
5. 在不影响主机系统设置的情况下，在虚拟环境中安装软件包。首先升级 `pip`：
```shell
pip install --upgrade pip
pip list  # show packages installed within the virtual environment
```
7. 安装 TensorFlow pip 软件包
请[从 PyPI](https://pypi.org/project/tensorflow/) 中选择以下某个 TensorFlow 软件包进行安装：

* `tensorflow`：支持 CPU 和 [GPU](https://www.tensorflow.org/install/gpu?hl=zh_cn) 的最新稳定版（适用于 Ubuntu 和 Windows）。
* `tf-nightly`：预览 build（不稳定）。Ubuntu 和 Windows 均包含 [GPU 支持](https://www.tensorflow.org/install/gpu?hl=zh_cn)。
* `tensorflow==1.15`：TensorFlow 1.x 的最终版本。
8. 安装 tensorflow
```shell
pip install --upgrade tensorflow
```
9. 验证安装效果
```shell
python -c "import tensorflow as tf;print(tf.reduce_sum(tf.random.normal([1000, 1000])))"
```
10. 之后要退出 virtualenv，请使用以下命令：
```shell
deactivate  # don't exit until you're done using TensorFlow
```

## 安装 opencv

### 激活虚拟环境

```shell
cd /path/to/your/venv
`source ./venv/bin/activate bash`
```

### 开始安装

```shell
pip install --upgrade opencv-python
```

### 安装依赖

```shell
sudo apt install libqtgui4 libqt4-test -y
pip install opencv-contrib-python==4.1.0.25
```
