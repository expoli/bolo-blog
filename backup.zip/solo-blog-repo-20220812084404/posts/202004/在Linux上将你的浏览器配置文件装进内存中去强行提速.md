title: 在 Linux 上将你的浏览器配置文件“装进内存中去”强行提速！
date: '2020-04-26 19:06:42'
updated: '2020-04-26 19:13:21'
tags: [Arch, Linux]
permalink: /articles/2020/04/26/1587899100489.html
---
![](https://img.hacpai.com/bing/20190729.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 在 Linux 上将你的浏览器配置文件“装进内存中去”强行提速！

本教程说明了如何将浏览器配置文件同步到 Tmpfs（RAM）中，以提高 Linux 中的浏览器速度。在本指南中，我们将使用一个名为 Profile-sync-daemon（简称 psd）的工具进行此操作。

Profile-sync-daemon 工具不过是一个 BASH 脚本，旨在管理 tmpfs 中的浏览器配置文件，并借助 Rsync 将其定期同步到 HDD 和/或 SSD。（Tmpfs 是驻留在内存或交换分区中的临时文件系统。）因此，移动浏览器的配置文件至 Tmpfs 将有效提高浏览器的整体性能。

## 所支持的浏览器

```
# Possible values:
#  chromium
#  chromium-dev
#  conkeror.mozdev.org
#  epiphany
#  falkon
#  firefox
#  firefox-trunk
#  google-chrome
#  google-chrome-beta
#  google-chrome-unstable
#  heftig-aurora
#  icecat
#  inox
#  luakit
#  midori
#  opera
#  opera-beta
#  opera-developer
#  opera-legacy
#  otter-browser
#  qupzilla
#  qutebrowser
#  palemoon
#  rekonq
#  seamonkey
#  surf
#  vivaldi
#  vivaldi-snapshot

```

## 安装

Arch Linux 及其衍生版

```
$ sudo pacman -S profile-sync-daemon
```

On Debian Sid/10/ 9, Ubuntu 19.10/18.04:

```
$ sudo apt install profile-sync-daemon
```

On Fedora 31/30, CentOS 8 和其它使用 DNF 包管理器的发行版。

```
$ sudo dnf copr enable szasza/Profile-sync-daemon
```

```
$ sudo dnf install profile-sync-daemon
```

## 备份浏览器配置文件

**强烈建议，在启用psd之前，将浏览器的配置文件进行备份。**

## 启用 psd

### 初始化配置文件

运行 psd 命令初始化 psd 配置文件，将在**/home/$USER/.config/psd/** 文件夹创建**psd.conf** 文件。

```
$ psd
```

### 编辑配置文件
```
$ vim ～/.config/psd/psd.conf
```
将需要加速的浏览器填入下行中，并取消注释。
```
[...]
BROWSERS="chromium firefox"
[...]
```
同时你也可以选择是否使用备份。
![](https://oss.expoli.tech/img/20200426185741.png)

### 启动 psd

```
$ systemctl --user enable psd
```
```
$ systemctl --user start psd
```

### 查看服务运行状态

```
$ systemctl --user status psd
```
输出结果如下。
```
$ systemctl --user status psd
● psd.service - Profile-sync-daemon
     Loaded: loaded (/usr/lib/systemd/user/psd.service; enabled; vendor preset: enabled)
     Active: active (exited) since Sun 2020-04-26 15:21:26 CST; 3h 38min ago
       Docs: man:psd(1)
             man:profile-sync-daemon(1)
             https://wiki.archlinux.org/index.php/Profile-sync-daemon

4月 26 15:21:26 expoli systemd[1164]: Finished Profile-sync-daemon.
```

### 查看进程运行状况

```
$ psd p

Profile-sync-daemon v6.37 on Arch Linux

 Systemd service is currently active.
 Systemd resync-timer is currently active.
 Overlayfs technology is currently inactive.

Psd will manage the following per /home/expoli/.config/psd/psd.conf:

 browser/psname:  chromium/chromium
 owner/group id:  expoli/1000
 sync target:     /home/expoli/.config/chromium
 tmpfs dir:       /run/user/1000/expoli-chromium
 profile size:    1.3G
 recovery dirs:   none
```


