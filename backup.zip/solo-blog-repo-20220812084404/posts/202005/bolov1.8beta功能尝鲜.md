title: bolo v1.8-beta 功能尝鲜
date: '2020-05-11 15:26:43'
updated: '2020-05-11 15:27:16'
tags: [bolo]
permalink: /articles/2020/05/11/1589182003632.html
---
![](https://img.hacpai.com/bing/20180107.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# bolo v1.8-beta 功能尝鲜

![image.png](https://oss.expoli.tech/img/9wQCa5qctA)

想尝鲜的童鞋，可以根据我这篇文章，然后拉取 `1.8-rc` 镜像，最新的 `latest` 依旧是 1.7 版本。

```
docker pull tangcuyu/bolo-solo:version-1.8-rc
```

![image.png](https://oss.expoli.tech/img/hEPceHolym)

## bolo 新用户？

新用户可以尝试根据下面的文章进行使用体验。

[使用 docker-compose 一键启动 bolo 博客](https://expoli.tech/articles/2020/03/22/1584849176609.html "使用 docker-compose 一键启动 bolo 博客")

## 自定义图床测试

- 1.8 版本支持了OSS对象储存自定义目录；
![image.png](https://oss.expoli.tech/img/4cb4fDeudP)

### 阿里云端查看

一切正常

![image.png](https://oss.expoli.tech/img/8P1pRYM8WZ)


## sakura 皮肤，复制版权问题

经测试已解决。

![image.png](https://oss.expoli.tech/img/PuItKJ2rx7)



