title: ISC2016训练赛——phrackCTF——easyCrackMe
date: '2021-07-15 09:35:38'
updated: '2021-07-15 09:35:38'
tags: [CTF]
permalink: /articles/2021/07/15/1626320278399.html
---
![disassembler01.png](https://oss.expoli.tech/img/KSK_disassembler01.png)

# 题目

都说逆向挺难的，但是这题挺容易，反正我不会，大家来挑战一下吧~~:)

> ichunqiu 给的题目有损坏无法使用，导致我白白看了好长时间

文件：[easycrackme.6dbc7c78c9bb25f724cd55c0e1412617](https://oss.expoli.tech/img/Ehh_easycrackme.6dbc7c78c9bb25f724cd55c0e1412617)

## IDA 反编译

可以看出算法检验的原理以及比较字符串为 `list1`

```c
int __cdecl main(int argc, const char **argv, const char **envp)
{
  char v3; // cl
  unsigned __int8 *v4; // rsi
  int v5; // edx
  int v6; // ecx
  int v7; // er8
  int v8; // er9
  unsigned __int8 *v9; // rdx
  int v10; // ecx
  unsigned int v11; // eax
  bool v12; // zf
  int v13; // ecx
  __int64 v14; // rdx
  __int64 v15; // rdi
  char v17; // [rsp+0h] [rbp-38h]
  unsigned __int8 v18; // [rsp+10h] [rbp-28h] BYREF
  _BYTE v19[39]; // [rsp+11h] [rbp-27h] BYREF

  printf((unsigned int)"Input your password:", (_DWORD)argv, (_DWORD)envp, v3);
  v4 = &v18;
  _isoc99_scanf((unsigned int)"%s", (unsigned int)&v18, v5, v6, v7, v8, 171);
  v9 = &v18;
  do
  {
    v10 = *(_DWORD *)v9;
    v9 += 4;
    v11 = ~v10 & (v10 - 16843009) & 0x80808080;
  }
  while ( !v11 );
  v12 = (~v10 & (v10 - 16843009) & 0x8080) == 0;
  if ( (~v10 & (v10 - 16843009) & 0x8080) == 0 )
    LOBYTE(v11) = (~v10 & (v10 - 16843009) & 0x80808080) >> 16;
  LOBYTE(v13) = (_BYTE)v9 + 2;
  if ( v12 )
    v9 += 2;
  v14 = &v9[-__CFADD__((_BYTE)v11, (_BYTE)v11) - 3] - &v18;
  if ( v14 == 26 )
  {
    v15 = 0LL;
    v4 = v19;
    if ( (v18 ^ 0xAB) == list1 )
    {
      while ( 1 )
      {
        LODWORD(v14) = ((int)v15 + 1) / 6;
        v13 = ((int)v15 + 1) % 6;
        if ( (v19[v15] ^ (unsigned __int8)*(&v17 + v13)) != byte_6B41D1[v15] )
          break;
        if ( ++v15 == 25 )
        {
          printf((unsigned int)"Congratulations!", (unsigned int)v19, v14, v13);
          return 0;
        }
      }
    }
  }
  printf((unsigned int)"Password Wrong!! Please try again.", (_DWORD)v4, v14, v13);
  return 0;
}
```

## list1 数据

![list.png](https://oss.expoli.tech/img/X9h_list.png)

## 算法实现

```python
pad1 = [0xab,0xdd,0x33,0x54,0x35,0xef]
pad2 = [0xfb,0x9e,0x67,0x12,0x4e,0x9d,0x98,0xab,0x00,0x06,0x46,0x8a,0xf4,0xb4,0x06,0x0b,0x43,0xdc,0xd9,0xa4,0x6c,0x31,0x74,0x9c,0xd2,0xa0]

flag = ""
flag += chr(pad2[0]^0xab)
for i in range(1,26):
    flag += chr(pad1[i%6]^pad2[i])

print(flag)
```

# 参考资料

https://wooy0ung.github.io/writeup/2017/08/06/jarvisoj-basic-writeup/#0x011-easy-crackme
