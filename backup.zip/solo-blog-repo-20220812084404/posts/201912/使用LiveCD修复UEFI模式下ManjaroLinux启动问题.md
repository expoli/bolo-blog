title: 使用 Live CD 修复 UEFI 模式下 Manjaro Linux 启动问题
date: '2019-12-27 11:57:10'
updated: '2019-12-27 11:57:10'
tags: [坑, Manjaro]
permalink: /articles/2019/12/27/1577419029998.html
---
![](https://oss.expoli.tech/img/6nG_201910206808337214242807879.jpg)

# 使用 Live CD 修复 UEFI 模式下 Manjaro Linux 启动问题

## 0. 令人糟心的 N 卡驱动

因为自己的硬盘还有着相当大小的剩余空间，于是昨天就给自己的笔记本安装了一个 Manjaro Linux（Arch Linux 优秀衍生版），因为自己的笔记本是 Asus 的，而且时间也比较早了，华硕老款机型的问题大家也知道，那就是老版本的 BIOS 根本就不支持显卡切换、刚安装完系统查看的时候发现系统内核只加载了 Intel 核心显卡，如下：

```shell
$ lspci | grep -i vga
00:02.0 VGA compatible controller: Intel Corporation HD Graphics 530 (rev 06)
```

查看目前安装的驱动程序，可以看出现在使用的是开源驱动 `nouveau`

```shell
# inxi -G

Graphics:
  Device-1: Intel HD Graphics 530 driver: i915 v: kernel 
  Device-2: NVIDIA GM107M [GeForce GTX 950M] driver: nouveau v: kernel 
  Display: x11 server: X.org 1.20.6 driver: nouveau 
  resolution: <xdpyinfo missing> 
  OpenGL: renderer: Mesa DRI Intel HD Graphics 530 (Skylake GT2) 
  v: 4.5 Mesa 19.2.7 
```

然后这个时候我就有了个大胆的想法、那就是：独显留着不用是不是很浪费、然后我就安装了 NVIDIA nofree 驱动：

```shell
sudo mhwd -a pci nonfree 0300
```

下一步就是重启系统、开开心心、极其潇洒地输入了 reboot 命令、然后正常关机、OK 表现很好、正常启动表现很好，点个赞！嗯？等一下，怎么回事，风扇怎么抽风了开启了嚎叫模式？？？TTY 进不去、黑屏、看不到启动信息、键盘无响应，好了已经可以确认了这次安装 N 卡驱动翻车了。然后开始后期的补救措施、总不能再重新安装一次系统吧、那显得多没面子，维修系统这个总是需要学会的、说不定以后什么时候就用到了、技多不压身不是？（但是我希望我以后再也用不到这门技能！多糟心啊！）

## 1. 修复前准备

### 1.1. Live CD 启动盘一个

这里推荐 `balenaEtcher` 这款烧录软件、开源、速度快、支持的镜像格式众多、而且可跨平台使用。官网链接：[https://www.balena.io/etcher/](https://www.balena.io/etcher/)

## 2. 开始 chroot 修复（最好有联网环境、后续修复的时候有可能会使用到网络连接）

首先通过liveUSB启动，在liveUSB的中我们原先的系统文件是保存在电脑的磁盘上的，默认不会被挂载，所以我们先要把除了`/home`以外的系统目录挂载到当前的任意目录，我们选择挂载在`/mnt`中：

### 2.1 使用 lsblk 查看各挂载点的设备

```shell
$ lsblk
NAME   MAJ:MIN RM   SIZE RO TYPE MOUNTPOINT
sda      8:0    0 232.9G  0 disk 
├─sda1   8:1    0    99M  0 part 
├─sda2   8:2    0   128M  0 part 
├─sda3   8:3    0  69.4G  0 part 
├─sda4   8:4    0   632M  0 part 
├─sda5   8:5    0    80G  0 part 
├─sda6   8:6    0   646M  0 part /boot/efi
├─sda7   8:7    0   3.9G  0 part [SWAP]
└─sda8   8:8    0  78.1G  0 part /
```

### 2.2 对相应的分区进行挂载

```shell
sudo mkdir /mnt/manjaro 
sudo mount /dev/sda8 /mnt/manjaro # sda8为 / 分区所在设备，可以使用lsblk查看
```

### 2.3 挂载EFI分区

随后是关键的一步，因为在UEFI下安装Manjaro Linux时我们都额外为`/boot/efi/`进行了单独的分区，所以我们这里也需要挂载它。默认挂载根目录时并不会挂载这个目录，因为它们不在同一个分区，根据lsblk中显示的efi所在的设备进行相应的挂载，否则内核无法重新安装：

```shell
sudo mount /dev/sda1 /mnt/manjaro/boot/efi
```

另外对于一些虚拟目录，例如/dev和/sys，我们也需要手动绑定，否则chroot后运行pacman会出错：

```shell
sudo mount --bind /dev /mnt/manjaro/dev
sudo mount --bind /proc /mnt/manjaro/proc
sudo mount --bind /sys /mnt/manjaro/sys
```

## 3. chroot 重新安装内核

通过原来的准备我们已经将系统文件准备完成了，现在我们在挂载目录下chroot，然后重新安装内核：

```
cd /mnt/manjaro
chroot .
pacman -S linux # 如果这一步报错，检查自己系统目录是否正确挂载，如果正确挂载则先运行pacman -S archlinux-keyring
# 内核重装完成后继续上次未完成的系统更新、或者卸载导致系统出现问题的包
pacman -Syu
pacman -R 
```

## 4. 卸载N卡闭源驱动

### 4.1 查看已安装的驱动

```shell
mhwd -li

 Installed PCI configs:
--------------------------------------------------------------------------------
                  NAME               VERSION          FREEDRIVER           TYPE
--------------------------------------------------------------------------------
           video-linux            2018.05.04                true            PCI

	NVIDIA×××××××					no-free		×××××
Warning: No installed USB configs!
```

### 4.2 卸载有问题的驱动

```shell
mhwd -f -r pci  # 上个命令所显示的驱动名称
```

### 4.3 安装开源驱动

```shell
sudo pacman -Ss nouveau

extra/manjaro-firmware 20160419-1 [已安装]
    Extra firmwares for Manjaro Linux
extra/mesa 19.2.7-1 [已安装]
    An open-source implementation of the OpenGL specification
extra/xf86-video-nouveau 1.0.16-1 (xorg-drivers) [已安装]
    Open Source 3D acceleration driver for nVidia cards
multilib/lib32-mesa 19.2.7-1 [已安装]
    An open-source implementation of the OpenGL specification (32-bit)

pacman -S xf86-video-nouveau
```

### 4.3 重新生成引导镜像

1. 查看内核
    
    ```
    ➜  X11 ls /etc/mkinitcpio.d                
    linux52.preset
    
    ```
    
2. 生成引导镜像
    
    ```
    mkinitcpio -p linux<version>
    mkinitcpio -p linux54
    ```

重启完成
```
sudo reboot
```
更新 grub

```
sudo update-grub
```


