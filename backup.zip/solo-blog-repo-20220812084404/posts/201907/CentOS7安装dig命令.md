title: CentOS 7 安装 dig 命令
date: '2019-07-27 17:46:08'
updated: '2020-02-16 20:03:02'
tags: [CentOS, dig]
permalink: /articles/2019/07/27/1564656217107.html
---
![](https://oss.expoli.tech/img/Pie_201806024704532767927412375.jpg) 

# install-dig-centos7

date: 2019-07-27

## 背景

因为最开始系统安装的是 `centos7 mini` 的 `server` 版本、所以很多工具包默认都没有安装、于是在想使用 `dig` 命令的时候、突然发现没有这个命令、所以在这里记录一下、以防自己忘记

```bash
[root@localhost ~]# yum install bind-utils -y
```

![2019-07-27-install-dig-centos7.png](http://tc.expoli.tech/images/2019/07/28/2019-07-27-install-dig-centos7.png)
