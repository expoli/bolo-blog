title: syncthing 使用
date: '2019-07-27 15:46:08'
updated: '2019-07-27 15:46:08'
tags: [Syncthing]
permalink: /articles/2019/07/27/1564656216462.html
---
# syncthing 使用

## 1. 下载

## 2. 解压

## 3. 在同级文件夹下新建一个 bat 文见

```bash
start "Syncthing" syncthing -no-console -no-browser
```
## 4. 双击

## 5. 资源管理器进入 %appdata% 文件夹

进入到上级目录、可以查看相关配置文件

- Local 
  - Syncthing

## 6. 在windows搜索中输入 task 打开任务计划程序（Schedule task）

点击左边任务计划程序库

新建基本任务、填写好名称以及相关介绍

触发器为每次我登陆时

操作为启动程序

程序或脚本路径为刚才新建的bat文件的路径` C:\syncthing\start-syncthing.bat`

起始于参数填入 `C:\syncthing\`

下一步完成

浏览器输入 http://127.0.0.1:8384/# 即可访问 web gui

当多个设备进行同步时、需要保证2个设备互相知道对面的设备ID、并且文件同步密钥也需要一致