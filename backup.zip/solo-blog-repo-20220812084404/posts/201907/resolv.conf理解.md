title: resolv.conf理解
date: '2019-07-27 19:47:08'
updated: '2019-08-19 19:54:30'
tags: [resolv.conf]
permalink: /articles/2019/07/27/1564656218143.html
---
# resolv.conf理解

date: 2019-07-27

## resolv.conf：search、domain、nameserver解释

以前只知道 `resolv.conf` 是 `linux` 管理 `dns` 的一个配置文件，但是对 配置文件里的各种配置的作用就不甚了解，今天学习了一下在这里做一下记录以防自己忘记。

### nameserver x.x.x.x

该选项用来指定 `DNS服务器` 的，可以配置多个 `nameserver` 即指定多个DNS。一行一个

```conf
nameserver 8.8.8.8
nameserver 101.6.6.6
```

### domain mydomain.com

这个用来指定本地的域名，在 `没有设置search的情况下` ，`search` 默认为 `domain的值`。

这个值可以随便配，目前看来，`domain` 除了当 `search` 的默认值外，没有其它用途。也就说一旦配置 `search` ，那 `domain` 就不起作用了。

### search *******

该选项可以用来指定多个域名，中间用空格或tab键隔开。它是当访问的域名不能被DNS解析时，`resolver` 会将该域名加上 `search` 指定的参数，重新请求 `DNS` ，直到被正确解析或试完 `search` 指定的列表为止。

如：在没有配置该选项时，执行 `ping news` 无法解析，但是当配置了以后就可以解析了。如下图

![2019-07-27-resolv.conf.png](http://tc.expoli.tech/images/2019/07/28/2019-07-27-resolv.conf.png)