title: Archlinux开启ssh服务以使用终端登录
date: '2018-04-29 08:40:29'
updated: '2018-04-29 08:40:29'
tags: [Arch]
permalink: /articles/2018/04/29/1564656227712.html
---
![Arch and ssh](https://ws3.sinaimg.cn/large/006tNbRwly1fwblvf9pcej30ci0cijrt.jpg)

### Archlinux开启ssh服务命令

<!-- more -->

```bash
$ sudo systemctl enable sshd.service     开机启动

$ sudo systemctl start sshd.service      立即启动

$ sudo systemctl restart sshd.service    立即重启
```

**之后你就可以远程操控你心爱的 linux 了 是不是很激动啊！**