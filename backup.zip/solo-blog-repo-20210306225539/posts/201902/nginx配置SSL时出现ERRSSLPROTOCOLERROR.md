title: nginx配置SSL时出现 ERR_SSL_PROTOCOL_ERROR
date: '2019-02-22 20:46:08'
updated: '2019-02-22 20:46:08'
tags: [Nginx, 运维]
permalink: /articles/2019/02/22/1564656236681.html
---
当我最开始看到这个错误的时候还是有点蒙的,因为在我记忆中貌似文件配置就是这样改的啊,怎么就会出错了呢.

怎么办,没办法,只能查看日志,看到底问题出现在哪里了,看是不是 ssl 的密钥对位置是不是填错位置了,想到这,就把 `ssl_certificate` 与 `ssl_certificate_key` 文件位置互换了一下,然后 `nginx -t` 好吧❌,那么很显然不是这个的问题了

```bash
server {
    listen 443;
    listen 80   default_server;
    server_name zzutcy.top;

    # SSL-START
    ssl_certificate         /var/www/ssl/zzutcy.top.pem;    # 这里
    ssl_certificate_key     /var/www/ssl/zzutcy.top.key;    # 这里
    ssl_protocols TLSv1 TLSv1.1 TLSv1.2;
    ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:HIGH:!aNULL:!MD5:!RC4:!DHE;
    ssl_prefer_server_ciphers on;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    error_page 497  https://$host$request_uri;
    # SSL-END
}
```
于是带着 `ERR_SSL_PROTOCOL_ERROR` 这个错误代码求助于搜索引擎,这个时候我看着搜索结果,一脸黑人问好 `?????` 我看到很多的搜索结果是让你更改Chrome或者系统的Security Settings，即使是Google也是。
然而而且这个时候我站的 HTTP 是能够访问的,只是 HTTPS 无法访问,所以肯定是我自己的锅,为什么要把问题归咎給那无辜的操作系统与浏览器呢.(此时基本确定问题出现在服务器的 SSL 配置上,我好菜啊,,一个 SSL 配置都搞不定.....

**同时提醒一下**，**不要更改安全设置**，**除非你知道你在做什么**。(问题确实挺严重的,所以语气有点严肃.)

大部分时间只是nginx的配置错误导致 **ERR_SSL_PROTOCOL_ERROR**

把原来自己作的密钥对的路径修改过来,再用下面的命令检查一下配置文件还有没有语法错误。
```bash
nginx -t
# 示例输出：
nginx: the configuration file /etc/nginx/nginx.conf syntax is ok
nginx: configuration file /etc/nginx/nginx.conf test is successful
# 执行nginx -t时需要root权限，请使用sudo或者临时su到root账户。
# 而且有语法错误的话nginx也无法正常启动，会提示配置文件错误
```

那么最后就只有一个地方了,那就是nginx SSL设置，也就是我这种情况。
大家也看到了我在server块中只设置了
```conf
server {
    listen 443;
    # 比较坑的就是这样设置语法是没有错误的，即nginx -t不会提示任何错误 ... 难受啊..
}
```

**正确的设置应该为**
```conf
server {
    listen 443 ssl; # 划重点! 划重点! 对就是因为少加了 ssl 这个参数.
}
```

然后重启nginx服务，再访问就不会出现问题了.
```bash
systemctl reload nginx
```