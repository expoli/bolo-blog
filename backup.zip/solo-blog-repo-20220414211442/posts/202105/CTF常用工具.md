title: CTF 常用工具
date: '2021-05-14 16:12:10'
updated: '2021-05-14 16:31:21'
tags: [ctf]
permalink: /articles/2021/05/14/1620979930459.html
---
![5c6eb40dd2cearticle191125trendmicroctfbodytext.jpg](https://oss.expoli.tech/img/i9n_5c6eb40dd2ce-article-191125-trend-micro-ctf-body-text.jpg)

# 1. 文件处理类

## 1.1 Stegsolve.jar

图片处理

## 1.2 cat 命令

可以进行文件的合并

```bash
cat * > test.txt
```

## 1.3 ghex

二进制编辑器

```bash
sudo apt-get install ghex
```

# 2. 工具类

## 2.1 BurpSuite pro

## 2.2 CTFCrackTools-V2

密文编解码工具集

https://github.com/Acmesec/CTFCrackTools-V2

## 2.3 GitHack

https://github.com/BugScanTeam/GitHack

## 2.4 Sqlmap

## 2.5 dirsearch

https://github.com/maurosoria/dirsearch

## 2.6 ctf-tools

https://github.com/zardus/ctf-tools

## 2.7 在线解码工具

http://ctf.ssleye.com/

## 2.8 zip密码破解

1. `使用zip2john命令算出压缩文件的hash值`

`zip2john cet.zip >cet_hash.txt`

2. `接着使用john命令进行hash计算，破解密码`

`john cet_hash.txt`
