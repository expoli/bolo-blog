title: Docker Ubuntu 容器安装 ping
date: '2019-02-22 20:46:08'
updated: '2019-02-22 20:46:08'
tags: [Docker]
permalink: /articles/2019/02/22/1564656236428.html
---
今天在用 `docker-compose` 生成容器的时候,发现在启动的时候有点问题,于是就想进到容器里面看看容器之间的通信是不是正常的.

说干就干

```bash
docker exec -it nginx /bin/bash
ping
command not found # duang duang

# emmmm  忘记了 ping 在哪个软件包了

apt-get update
apt-get install net-tools -y

ping
command not found # duang duang 
# 得,我还是求助搜索引擎去了...
```

### ping 在 iputils-ping 这个包里面

```bash
apt-get update
apt-get install iputils-ping -y
# 然后就可以尽情的 ping 了.
```