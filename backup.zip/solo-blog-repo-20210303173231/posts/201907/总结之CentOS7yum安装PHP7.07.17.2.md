title: 总结之——CentOS7 yum 安装 PHP 7.0, 7.1 & 7.2
date: '2019-07-26 13:46:08'
updated: '2019-07-26 13:46:08'
tags: [CentOS, PHP, yum]
permalink: /articles/2019/07/26/1564656215136.html
---
# 总结之——CentOS7 yum 安装 PHP 7.0, 7.1 & 7.2

## 第一步：安装 `yum-utils` 并开启 EPEL repository

### 1. 安装 `yum-utils`

```bash
[root@linux ~]# yum install epel-release yum-utils -y
```

### 2. 下载并安装 `remirepo`

```bash
# yum install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
# yum install http://rpms.remirepo.net/enterprise/remi-release-7.rpm
```

### 3. 根据需要配置相应的 `PHP 7.x` 源

- PHP 7.0

```bash
# yum-config-manager --enable remi-php70
```
- PHP 7.1

```bash
# yum-config-manager --enable remi-php71
```
- PHP 7.2

```bash
# yum-config-manager --enable remi-php72
```
- PHP 7.3

```bash
# yum-config-manager --enable remi-php73
```

### 4. 安装PHP以及相关依赖

```bash
# yum install php php-common php-opcache php-mcrypt php-cli php-gd php-curl php-mysql -y
```

---
你可以使用下面的命令查看所欲的 PHP 模块、按照需求进行添加

```bash
# yum search php | more
```

### 5. 安装完成验证一下


```bash
# php -v
PHP 7.2.7 (cli) (built: Jun 20 2018 08:21:26) ( NTS )
Copyright (c) 1997-2018 The PHP Group
Zend Engine v3.2.0, Copyright (c) 1998-2018 Zend Technologies
    with Zend OPcache v7.2.7, Copyright (c) 1999-2018, by Zend Technologies
```

### 6. 也可以通过 PHP 测试页面进行验证

1. 开启 `Apache httpd`

```bash
# systemctl start httpd
```

2. 在 `/var/www/html` 文件夹下面新建一个 `info.php` 文件、输入以下内容

```php
<?php
phpinfo();
?>
```

3. 然后进行访问查看

[http://Server-IP-Address/info.php](http://Server-IP-Address/info.php)