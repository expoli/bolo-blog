title: Arch linux 安装指导文档（图文教程）
date: '2020-01-31 22:53:00'
updated: '2020-03-14 21:02:12'
tags: [Arch]
permalink: /articles/2020/01/31/1580482380835.html
---
# Arch Linux 安装指导文档（图文教程）

以前一只使用的是 manjaro 这个 Arch 的衍生版（gnome）桌面的，但是在使用一段时间后发现，桌面会有莫名其妙的卡顿感，尤其是在 CPU 使用率过高的时候，CLion 还是 CPU 使用大户，所以能够想象打几行卡一下的酸爽，也是趁着这个机会记录一下整个安装过程，毕竟中间还是遇到了一些问题的。

## 0. 首先阅读官方安装指导文档

不管怎样说、对 Arch 了解的最多的还是其开发人员、不管其它安装教程怎么写最权威的还是 Arch WIKI、所以建议你在看以下的步骤时先将官方安装指导文档浏览一遍，做到心中有数、能够帮助你知道自己究竟在做什么。链接如下：

[Installation guide (简体中文)](https://wiki.archlinux.org/index.php/Installation_guide_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87))

[Installation_guide](https://wiki.archlinux.org/index.php/Installation_guide)

## 1. 开始安装

现假设你已经了解了官方指导文档，对每个操作都有了大致的了解，那么下面开始介绍主要的安装步骤。

### 1.1 验证启动模式

如果以在 UEFI 主板上启用 [UEFI](https://wiki.archlinux.org/index.php/UEFI "UEFI") 模式，[Archiso](https://wiki.archlinux.org/index.php/Archiso "Archiso") 将会使用 [systemd-boot](https://wiki.archlinux.org/index.php/Systemd-boot_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)) "Systemd-boot (简体中文)") 来 [启动](https://wiki.archlinux.org/index.php/Boot "Boot") Arch Linux。可以列出 [efivars](https://wiki.archlinux.org/index.php/UEFI#UEFI_variables "UEFI") 目录以验证启动模式：

```shell
# ls /sys/firmware/efi/efivars
```

如果目录不存在，系统可能以 [BIOS](https://en.wikipedia.org/wiki/BIOS "w:BIOS") 或 CSM 模式启动，详见您的主板手册。

可以看出我的系统是以 UEFI 模式引导的，**之所以在这里验证启动模式，是因为我们后续分区操作的时候需要根据启动模式的不同使用不同的分区方案！**

![lsefifirmware.png](https://img.hacpai.com/file/2020/01/lsefifirmware-eeeb7263.png)

### 1.2 连接到因特网

1. 确保系统已经启用了 [网络接口](https://wiki.archlinux.org/index.php/Network_configuration#Network_interfaces "Network configuration")，用 [ip-link(8)](https://jlk.fjfi.cvut.cz/arch/manpages/man/ip-link.8) 检查：

```
# ip link
```

2. 连接到网络，连接网线或[无线网络](https://wiki.archlinux.org/index.php/Wireless_network_configuration "Wireless network configuration").
3. 配置网络连接：

- 有线网络
  1. 动态 IP：
  2. 启动 dhcpd 从 dhcp 服务器中获取一 IP 地址
  3. 检查网络连接状态（ip a、ping 命令）
- 无线网络
  1. 键入` wifi-menu` 命令打开 wifi 连接界面
  2. 选择需要连接的网络
  3. 键入密码确认连接
  4. 保存配置文件
  5. 检查网络连接状态（ip a、ping 命令）

抱歉、因设备原因，此处只有有线网络动态 IP 的配置截图，如需静态 IP 上网可参考官方 wiki 相关介绍。

![connecttointernet.png](https://img.hacpai.com/file/2020/01/connecttointernet-67fcf99b.png)

### 1.3 更新系统时间

使用 [timedatectl(1)](https://jlk.fjfi.cvut.cz/arch/manpages/man/timedatectl.1) 确保系统时间是准确的：

```
# timedatectl set-ntp true
```

可以使用 `timedatectl status` 检查服务状态。

![setntptime.png](https://img.hacpai.com/file/2020/01/setntptime-76862ba4.png)

### 1.4 进行硬盘分区

磁盘若被系统识别到，就会被分配为一个 [块设备](https://en.wikipedia.org/wiki/zh:%E8%AE%BE%E5%A4%87%E6%96%87%E4%BB%B6%E7%B3%BB%E7%BB%9F#.E5.91.BD.E5.90.8D.E7.BA.A6.E5.AE.9A "wikipedia:zh:设备文件系统")，如 `/dev/sda` 或者 `/dev/nvme0n1`。可以使用 [lsblk](https://wiki.archlinux.org/index.php/Lsblk "Lsblk") 或者 *fdisk* 查看：

```
# fdisk -l
```

结果中以 `rom`，`loop` 或者 `airoot` 结束的可以被忽略。

对于一个选定的设备，以下的*分区*是必须要有的：

* 一个根分区（挂载在根目录）`/`；
* 如果 [UEFI](https://wiki.archlinux.org/index.php/UEFI "UEFI") 模式被启用，你还需要一个 [EFI 系统分区](https://wiki.archlinux.org/index.php/EFI_system_partition "EFI system partition")。

![fdiskl.png](https://img.hacpai.com/file/2020/01/fdiskl-6b415c4f.png)

#### 分区示例

| BIOS 和 [MBR](https://wiki.archlinux.org/index.php/Partitioning_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)#Master_Boot_Record "Partitioning (简体中文)")                |               |                                                                                                                                                             |                |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------- |
| 挂载点                                                                                                                                                                | 分区        | [分区类型](https://en.wikipedia.org/wiki/Partition_type "w:Partition type")                                                                             | 建议大小   |
| `/mnt`                                                                                                                                                                   | `/dev/sd*X*1` | Linux                                                                                                                                                       | 剩余空间   |
| [SWAP]                                                                                                                                                                   | `/dev/sd*X*2` | Linux swap (交换空间)                                                                                                                                   | 大于 512 MiB |
| UEFI with [GPT](https://wiki.archlinux.org/index.php/Partitioning_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)#GUID_%E5%88%86%E5%8C%BA%E8%A1%A8 "Partitioning (简体中文)") |               |                                                                                                                                                             |                |
| 挂载点                                                                                                                                                                | 分区        | [分区类型](https://en.wikipedia.org/wiki/GUID_Partition_Table#Partition_type_GUIDs "w:GUID Partition Table")                                            | 建议大小   |
| `/mnt/boot` or `/mnt/efi`                                                                                                                                                | `/dev/sd*X*1` | [EFI 系统分区](https://wiki.archlinux.org/index.php/EFI_system_partition_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)) "EFI system partition (简体中文)") | 260–512 MiB  |
| `/mnt`                                                                                                                                                                   | `/dev/sd*X*2` | Linux x86-64 根目录 (/)                                                                                                                                  | 剩余空间   |
| [SWAP]                                                                                                                                                                   | `/dev/sd*X*3` | Linux swap (交换空间)                                                                                                                                   | 大于 512 MiB |

因现在绝大部分BIOS都支持UEFI启动，所以下面演示一下怎么建立适用于UEFI启动的分区规划。

1. 根据 `fdisk -l` 命令显示出的信息，选择自己所需要的硬盘，比如 `/dev/sda`。
2. 使用 `fdisk /dev/sda` 打开相应硬盘的会话。
3. 因为这是一块新虚拟的空白硬盘不存在分区表，所以我们需要先输入g新建一个GPT分区表
4. 输入n新建一个分区，分区开头扇区默认直接回车就行。输入+1G，创建一个1G大小的分区作为EFI分区使用。
5. 再输入n新建`/`分区，我们使用这个硬盘剩下的所有空间，所以开始扇区与结束扇区都是默认值。
6. 输入p显示我们创建的分区、确认大小。
7. 确认无误之后输入`w`写入硬盘。

![fsikdevsda.png](https://img.hacpai.com/file/2020/02/fsikdevsda-764e5210.png)

![creatdiskpart.png](https://img.hacpai.com/file/2020/02/creatdiskpart-6363dd40.png)


### 1.5 格式化分区

EFI分区，要求的文件系统为`FAT32`,`/`分区我们还是采用现在已经很成熟的`EXT4`.

1. 格式化EFI分区
```
mkfs.fat -F32 /dev/sda1
```
2. 格式化`/`分区
```
mkfs.ext4 /dev/sda2
```
3. 交换分区，我喜欢用交换文件的方式启用。
如果您创建了交换分区（例如 /dev/*sda3*），使用 mkswap 将其初始化：
```
 # mkswap /dev/sd*X*2
 # swapon /dev/sd*X*2
```

![makefs.png](https://img.hacpai.com/file/2020/02/makefs-931a71a6.png)

### 1.6 挂载分区

```
root@archiso ~ # mount /dev/sda2 /mnt 
root@archiso ~ # mkdir /mnt/efi
root@archiso ~ # mount /dev/sda1 /mnt/efi
```

### 1.7 为livecd更换连接性好的镜像源

众所周知，默认的国外的镜像源的连接性能让人急出心脏病，所以在安装必要软件之前，我们需要更换为连接性比较好的镜像源。因为读取镜像源时是自上向下读取的，所以将下面的粘贴到`/etc/pacman.d/mirrorlist`文件前几行。
```
vim /etc/pacman.d/mirrorlist
```

```
## China
Server = http://mirrors.aliyun.com/archlinux/$repo/os/$arch
Server = http://mirror.lzu.edu.cn/archlinux/$repo/os/$arch
Server = http://mirrors.neusoft.edu.cn/archlinux/$repo/os/$arch
Server = https://mirrors.neusoft.edu.cn/archlinux/$repo/os/$arch
Server = http://mirrors.tuna.tsinghua.edu.cn/archlinux/$repo/os/$arch
Server = https://mirrors.tuna.tsinghua.edu.cn/archlinux/$repo/os/$arch
Server = http://mirrors.ustc.edu.cn/archlinux/$repo/os/$arch
Server = https://mirrors.ustc.edu.cn/archlinux/$repo/os/$arch
Server = https://mirrors.xjtu.edu.cn/archlinux/$repo/os/$arch
Server = http://mirrors.zju.edu.cn/archlinux/$repo/os/$arch

```
最后效果如下。

![addchinamirrorslist.png](https://img.hacpai.com/file/2020/02/addchinamirrorslist-0a992c52.png)

### 1.8 安装必须的软件包

使用 [pacstrap](https://git.archlinux.org/arch-install-scripts.git/tree/pacstrap.in) 脚本，安装 [base](https://www.archlinux.org/packages/?name=base) 软件包和 Linux [内核](https://wiki.archlinux.org/index.php/Kernel "Kernel")以及常规硬件的固件：
```
# pacstrap /mnt base linux linux-firmware
```

![image.png](https://img.hacpai.com/file/2020/02/image-96dff6c4.png)

## 2 配置系统

### 2.1 生成Fstab

用以下命令生成 [fstab](https://wiki.archlinux.org/index.php/Fstab "Fstab") 文件 (用 `-U` 或 `-L` 选项设置UUID 或卷标)：
```
# genfstab -U /mnt >> /mnt/etc/fstab
```
**强烈建议** 在执行完以上命令后，后检查一下生成的 `/mnt/etc/fstab` 文件是否正确。

![genfstabumnt.png](https://img.hacpai.com/file/2020/02/genfstabumnt-f879cdb7.png)


### 2.2 Chroot 进新系统

在安装好基本软件后，我们需要Chroot进新系统，安装一些其它的必要软件。

[Change root](https://wiki.archlinux.org/index.php/Change_root "Change root") 到新安装的系统：
```
# arch-chroot /mnt
```

### 2.3 设置时区
```
# ln -sf /usr/share/zoneinfo/*Region*/*City* /etc/localtime
```
例如使用上海时区：
```
# ln -sf /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
```
运行 [hwclock(8)](https://jlk.fjfi.cvut.cz/arch/manpages/man/hwclock.8) 以生成 `/etc/adjtime`：
```
# hwclock --systohc
```
这个命令假定硬件时间已经被设置为 [UTC时间](https://en.wikipedia.org/wiki/UTC "wikipedia:UTC")。

### 2.4 本地化

本地化的程序与库若要本地化文本，都依赖 [Locale](https://wiki.archlinux.org/index.php/Locale "Locale")，后者明确规定地域、货币、时区日期的格式、字符排列方式和其他本地化标准等等。在下面两个文件设置：`locale.gen` 与 `locale.conf`。

`/etc/locale.gen` 是一个仅包含注释文档的文本文件。指定您需要的本地化类型，只需移除对应行前面的注释符号（`＃`）即可，建议选择带 `UTF-8` 的项：
```
# vim /etc/locale.gen
```
```
en_US.UTF-8 UTF-8
zh_CN.UTF-8 UTF-8
zh_TW.UTF-8 UTF-8
```
接着执行 `locale-gen` 以生成 locale 讯息：
```
# locale-gen
```
`/etc/locale.gen` 会生成指定的本地化文件。

创建 `locale.conf` 并编辑 `LANG` 这一 [变量](https://wiki.archlinux.org/index.php/Variable "Variable")，比如：

**Tip:** 将系统 locale 设置为 `en_US.UTF-8`，系统的 Log 就会用英文显示，这样更容易问题的判断和处理。用户可以设置自己的 locale，详情参阅 [Locale](https://wiki.archlinux.org/index.php/Locale#Overriding_system_locale_per_user_session "Locale") 或 [Locale_(简体中文)#设置 locale](https://wiki.archlinux.org/index.php/Locale_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)#.E8.AE.BE.E7.BD.AE_locale "Locale (简体中文)")。
```
/etc/locale.conf
-------
LANG=en_US.UTF-8
```
**警告: **不推荐在此设置任何中文 locale，会导致 TTY 乱码。

另外，如果你需要修改 [#键盘布局](https://wiki.archlinux.org/index.php/Installation_guide_(%E7%AE%80%E4%BD%93%E4%B8%AD%E6%96%87)#%E9%94%AE%E7%9B%98%E5%B8%83%E5%B1%80)，并想让这个设置持续生效，编辑 [vconsole.conf(5)](https://jlk.fjfi.cvut.cz/arch/manpages/man/vconsole.conf.5)，例如：
```
/etc/vconsole.conf

KEYMAP=*de-latin1*
```

### 2.5 安装GRUB

1. 安装GRUB、efi，ntfs支持和获取其它系统的支持`os-prober`。

```
pacman -S grub efibootmgr os-prober ntfs-3g
```

2. 安装grub到efi分区中

```
grub-install --target=x86_64-efi --efi-directory=/efi/ --bootloader-id=GRUB
```

3. 生成内存盘

```
mkinitcpio -P
```

4. 生成grub主配置文件

```
grub-mkconfig -o /boot/grub/grub.cfg
```

### 2.6 安装桌面环境

这里推荐`KDE`，所以暂且放一KDE的安装步骤，如有需要后续会添加其它的DE。

```
pacman -S xorg plasma kio-extras kde-applications
pacman -Ss sddm-breath-theme
systemctl enable sddm.service --force
```

### 2.7 启动网络服务

```
systemctl enable NetworkManager
```

### 2.8 添加用户

```
useradd -mG lp,network,power,sys,wheel username
passwd username
```

### 2.9 用户添加sudo权限

1. 安装sudo
```
sudo pacman -S sudo
```
2. 编辑sudo配置文件
```
vim /etc/sudoers

##
## User privilege specification
##
root ALL=(ALL) ALL
username ALL=(ALL) ALL
```

## 3 重启检验系统状态

### 3.1 退出Chroot环境

```
exit
```

### 3.2 重启

```
reboot
```

### 3.3 最终显示

![installedde.png](https://img.hacpai.com/file/2020/02/installedde-69dba855.png)

