title: QQ 头像 与 QQ 群头像获取 API
date: '2020-04-26 19:30:31'
updated: '2020-04-26 19:41:27'
tags: [待分类]
permalink: /articles/2020/04/26/1587901274867.html
---
![](https://img.hacpai.com/bing/20200318.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# QQ 头像 与 QQ 群头像获取 API

## QQ 头像

https://q1.qlogo.cn/g?b=qq&nk=qq号&s=图像大小


例如 https://q1.qlogo.cn/g?b=qq&nk=123456&s=640

## QQ 群

https://p.qlogo.cn/gh/QQ群/QQ群/0  
  
例如:https://p.qlogo.cn/gh/123456/123456/0
