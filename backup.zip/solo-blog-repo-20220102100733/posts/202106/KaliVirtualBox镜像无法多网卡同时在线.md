title: Kali VirtualBox 镜像无法多网卡同时在线
date: '2021-06-22 20:11:23'
updated: '2021-06-22 20:11:23'
tags: [kali]
permalink: /articles/2021/06/22/1624363883474.html
---
![KaliLogo.png](https://oss.expoli.tech/img/QVW_Kali-Logo.png)

# Kali VirtualBox 镜像无法多网卡同时在线

今天发现 kali 官方的虚拟机镜像已经出到 `2021.2` 版本了、于是就想升级一下自己的基础镜像，在完成虚拟电脑的导入后，想添加一个仅主机网卡，方便自己的 ssh 远程调试，并方便使用 `vscode` 的远程开发环境,然后发现虽然2张网卡都为 `up` 状态，但是没有办法同时在线。

> 具体原因是 kali 的网卡默认是由 NetworkManager 进行管理，默认拥有一个网卡配置文件，将其删除之后恢复默认就行了。

```bash
sudo rm /etc/NetworkManager/system-connections/Wired\ connection\ 1
```

参考资料：[Only one of multiple wired interfaces (eth0, eth1, etc) can be active at a time (kali.org)](https://forums.kali.org/showthread.php?29657-Only-one-of-multiple-wired-interfaces-(eth0-eth1-etc)-can-be-active-at-a-time)
