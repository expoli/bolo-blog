title: Openwrt 根分区扩容
date: '2021-12-10 16:39:04'
updated: '2021-12-10 16:39:04'
tags: [Openwrt]
permalink: /articles/2021/12/10/1639125544720.html
---
![openwrtlogo.jpg](https://oss.expoli.tech/img/AKh_openwrt-logo.jpg)

最近在使用Openwrt的时候、发现根分区只有可怜的 `1.1G` 、最近也遇到了容量吃紧的问题、所以需要对根分区进行扩容。

```log
# root @ OpenWrt in ~ [10:34:52] C:1
$ df -hT            
Filesystem           Type            Size      Used Available Use% Mounted on
/dev/root            ext4            1.1G      1.0G     64.7M  94% /
tmpfs                tmpfs         929.2M     16.0M    913.1M   2% /tmp
/dev/mmcblk0p1       vfat           63.9M     16.4M     47.4M  26% /boot
tmpfs                tmpfs         512.0K         0    512.0K   0% /dev
/dev/root            ext4            1.1G      1.0G     64.7M  94% /opt/docker
overlay              overlay         1.1G      1.0G     64.7M  94% /opt/docker/overlay2/7cce5922783d0dc5192bc171a327320584cd9bd12b76464d2f1565bfccb2f237/merged
```

# 1. 调整分区大小

1. 将存储卡放到一个具有分区工具的系统上，（Linux系统为例）使用 `gparted` 、点击 `resize` 按钮，将大小调整到自己所需的大小
3. 点击 `Edit` 进行更改应用 `Apply` 。

![image.png](https://oss.expoli.tech/img/Adm_image.png)

# 2. 调整文件系统大小

不知道你是不是和我一样，曾经天真地认为只要修改了分区大小文件系统肯定也会自动扩大，事实证明我还是年轻了，再来回倒腾几次后发现文件系统还是那么大，这个时候才后知后觉到。

1. 以前文件系统和分区同步变化是因为自己以前都是在做分区操作，即（`fdisk` 之后，随即执行了 `mkfs` 操作，所以文件系统大小的事情不需要自己再操心）
2. 所以现在需要使用 `ext4` 文件系统的扩容工具 `resize2fs` 、对文件系统进行扩容。

## 2.1 文件系统检测 `e2fsck`

```bash
sudo e2fsck /dev/sdc2
e2fsck 1.46.4 (18-Aug-2021)
rootfs was not cleanly unmounted, check forced.
Pass 1: Checking inodes, blocks, and sizes
Pass 2: Checking directory structure
Pass 3: Checking directory connectivity
Pass 4: Checking reference counts
Pass 5: Checking group summary information
Free blocks count wrong (20650, counted=20647).
Fix<y>? yes
Free inodes count wrong (43376, counted=43373).
Fix<y>? yes
```

## 2.2 开始调整分区大小

```bash
sudo resize2fs /dev/sdc2
resize2fs 1.46.4 (18-Aug-2021)
Resizing the filesystem on /dev/sdc2 to 5445120 (4k) blocks.
The filesystem on /dev/sdc2 is now 5445120 (4k) blocks long.
```

最终结果、扩容完成

```bash
# root @ OpenWrt in ~ [11:12:10] 
$ df -hT        
Filesystem           Type            Size      Used Available Use% Mounted on
/dev/root            ext4           20.5G   1021.4M     19.5G   5% /
tmpfs                tmpfs         929.2M     16.3M    912.8M   2% /tmp
/dev/mmcblk0p1       vfat           63.9M     16.4M     47.4M  26% /boot
tmpfs                tmpfs         512.0K         0    512.0K   0% /dev
/dev/root            ext4           20.5G   1021.4M     19.5G   5% /opt/docker
overlay              overlay        20.5G   1021.4M     19.5G   5% /opt/docker/overlay2/3628ec8070bb326a754c197819c3356d5f5281cd39efe9c26c0cc397daef6f8a/merged

```
