title: Solo(3.6.4) 升级到 的最新的 docker 镜像所遇到的问题
date: '2019-09-03 18:20:20'
updated: '2019-09-03 18:20:20'
tags: [solo, Note, Docker]
permalink: /articles/2019/09/03/1567506020443.html
---
# Solo(3.6.4) 升级到 的最新的 docker 镜像所遇到的问题

## 1. 问题背景

今天在登陆到服务器的时候、发现提示信息中提示 Ubuntu18.03 已经可用，原版本为16.04，于是抱着更新的想法就根据提示进行了更新。

### 1.1 Ubuntu 升级至 18.03

```bash
# 提示信息中的版本更新命令
# 运行后会提示你还有软件未更新至最新版本
# do-release-upgrade
# 更新软件
# apt-get update
# apt-get upgrade
# 如果有被锁定版本的软件还需要更新版本锁定软件
# apt-get 被锁定版本的软件的包名
# 再次进行更新
# do-release-upgrade
# 根据需要选择各种安装提示（Y/N）
```

### 1.2 遇到的问题

因为我所使用的solo为 docker 镜像、在更新系统的时候就无法避免地进行 docker 的版本更新、更新后的版本为 `18.09.07`。随后我又进行了 最新镜像地拉取 `docker-compose pull`。

- docker-compose 各镜像信息
```yaml  
 solo:  
 image: b3log/solo:latest  
  
 mysql:  
 image: mysql:5.5.60  
  
 php:  
 image: tangcuyu/php:7.2-fpm-mysqli  
```

```bash
# docker -v
Docker version 18.09.7, build 2d0083d
```
然而在更新后却发现 solo 镜像无法正常启动老是报错：`Communications link failure`.

```java
solo     | [INFO ]-[2019-09-03 16:16:19]-[com.zaxxer.hikari.HikariDataSource:110]: HikariPool-1 - Starting...
solo     | [WARN ]-[2019-09-03 16:16:19]-[com.zaxxer.hikari.util.DriverDataSource:68]: Registered driver with driverClassName=com.mysql.jdbc.Driver was not found, trying direct instantiation.
solo-mysql | InnoDB: Unable to lock ./ibdata1, error: 11
solo-mysql | InnoDB: Check that you do not already have another mysqld process
solo-mysql | InnoDB: using the same InnoDB data or log files.
solo     | [ERROR]-[2019-09-03 16:16:20]-[com.zaxxer.hikari.pool.HikariPool:574]: HikariPool-1 - Exception during pool initialization.
solo     | com.mysql.cj.jdbc.exceptions.CommunicationsException: Communications link failure
solo     |
solo     | The last packet sent successfully to the server was 0 milliseconds ago. The driver has not received any packets from the server.
solo     |      at com.mysql.cj.jdbc.exceptions.SQLError.createCommunicationsException(SQLError.java:174)
solo     |      at com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping.translateException(SQLExceptionsMapping.java:64)
solo     |      at com.mysql.cj.jdbc.ConnectionImpl.createNewIO(ConnectionImpl.java:835)
solo     |      at com.mysql.cj.jdbc.ConnectionImpl.<init>(ConnectionImpl.java:455)
solo     |      at com.mysql.cj.jdbc.ConnectionImpl.getInstance(ConnectionImpl.java:240)
solo     |      at com.mysql.cj.jdbc.NonRegisteringDriver.connect(NonRegisteringDriver.java:199)
solo     |      at com.zaxxer.hikari.util.DriverDataSource.getConnection(DriverDataSource.java:136)
solo     |      at com.zaxxer.hikari.pool.PoolBase.newConnection(PoolBase.java:369)
solo     |      at com.zaxxer.hikari.pool.PoolBase.newPoolEntry(PoolBase.java:198)
solo     |      at com.zaxxer.hikari.pool.HikariPool.createPoolEntry(HikariPool.java:467)
solo     |      at com.zaxxer.hikari.pool.HikariPool.checkFailFast(HikariPool.java:541)
solo     |      at com.zaxxer.hikari.pool.HikariPool.<init>(HikariPool.java:115)
solo     |      at com.zaxxer.hikari.HikariDataSource.getConnection(HikariDataSource.java:112)
solo     |      at org.b3log.latke.repository.jdbc.util.Connections.getConnection(Connections.java:206)
solo     |      at org.b3log.solo.service.InitService.initTables(InitService.java:178)
solo     |      at org.b3log.solo.service.InitService_$$_jvstecc_49._d7initTables(InitService_$$_jvstecc_49.java)
solo     |      at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
solo     |      at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
solo     |      at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
solo     |      at java.lang.reflect.Method.invoke(Method.java:498)
solo     |      at org.b3log.latke.ioc.JavassistMethodHandler.invoke(JavassistMethodHandler.java:116)
solo     |      at org.b3log.solo.service.InitService_$$_jvstecc_49.initTables(InitService_$$_jvstecc_49.java)
solo     |      at org.b3log.solo.SoloServletListener.contextInitialized(SoloServletListener.java:106)
solo     |      at org.eclipse.jetty.server.handler.ContextHandler.callContextInitialized(ContextHandler.java:952)
solo     |      at org.eclipse.jetty.servlet.ServletContextHandler.callContextInitialized(ServletContextHandler.java:558)
solo     |      at org.eclipse.jetty.server.handler.ContextHandler.startContext(ContextHandler.java:917)
solo     |      at org.eclipse.jetty.servlet.ServletContextHandler.startContext(ServletContextHandler.java:370)
solo     |      at org.eclipse.jetty.webapp.WebAppContext.startWebapp(WebAppContext.java:1497)
solo     |      at org.eclipse.jetty.webapp.WebAppContext.startContext(WebAppContext.java:1459)
solo     |      at org.eclipse.jetty.server.handler.ContextHandler.doStart(ContextHandler.java:847)
solo     |      at org.eclipse.jetty.servlet.ServletContextHandler.doStart(ServletContextHandler.java:287)
solo     |      at org.eclipse.jetty.webapp.WebAppContext.doStart(WebAppContext.java:545)
solo     |      at org.eclipse.jetty.util.component.AbstractLifeCycle.start(AbstractLifeCycle.java:68)
solo     |      at org.eclipse.jetty.util.component.ContainerLifeCycle.start(ContainerLifeCycle.java:138)
solo     |      at org.eclipse.jetty.server.Server.start(Server.java:416)
solo     |      at org.eclipse.jetty.util.component.ContainerLifeCycle.doStart(ContainerLifeCycle.java:108)
solo     |      at org.eclipse.jetty.server.handler.AbstractHandler.doStart(AbstractHandler.java:113)
solo     |      at org.eclipse.jetty.server.Server.doStart(Server.java:383)
solo     |      at org.eclipse.jetty.util.component.AbstractLifeCycle.start(AbstractLifeCycle.java:68)
solo     |      at org.b3log.solo.Starter.main(Starter.java:177)
solo     | Caused by: com.mysql.cj.exceptions.CJCommunicationsException: Communications link failure
solo     |
solo     | The last packet sent successfully to the server was 0 milliseconds ago. The driver has not received any packets from the server.
solo     |      at sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)
solo     |      at sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)
solo     |      at sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)
solo     |      at java.lang.reflect.Constructor.newInstance(Constructor.java:423)
solo     |      at com.mysql.cj.exceptions.ExceptionFactory.createException(ExceptionFactory.java:61)
solo     |      at com.mysql.cj.exceptions.ExceptionFactory.createException(ExceptionFactory.java:105)
solo     |      at com.mysql.cj.exceptions.ExceptionFactory.createException(ExceptionFactory.java:151)
solo     |      at com.mysql.cj.exceptions.ExceptionFactory.createCommunicationsException(ExceptionFactory.java:167)
solo     |      at com.mysql.cj.protocol.a.NativeSocketConnection.connect(NativeSocketConnection.java:91)
solo     |      at com.mysql.cj.NativeSession.connect(NativeSession.java:152)
solo     |      at com.mysql.cj.jdbc.ConnectionImpl.connectOneTryOnly(ConnectionImpl.java:955)
solo     |      at com.mysql.cj.jdbc.ConnectionImpl.createNewIO(ConnectionImpl.java:825)
solo     |      ... 37 more
solo     | Caused by: java.net.ConnectException: Connection refused (Connection refused)
solo     |      at java.net.PlainSocketImpl.socketConnect(Native Method)
solo     |      at java.net.AbstractPlainSocketImpl.doConnect(AbstractPlainSocketImpl.java:350)
solo     |      at java.net.AbstractPlainSocketImpl.connectToAddress(AbstractPlainSocketImpl.java:206)
solo     |      at java.net.AbstractPlainSocketImpl.connect(AbstractPlainSocketImpl.java:188)
solo     |      at java.net.SocksSocketImpl.connect(SocksSocketImpl.java:392)
solo     |      at java.net.Socket.connect(Socket.java:589)
solo     |      at com.mysql.cj.protocol.StandardSocketFactory.connect(StandardSocketFactory.java:155)
solo     |      at com.mysql.cj.protocol.a.NativeSocketConnection.connect(NativeSocketConnection.java:65)
solo     |      ... 40 more
solo     | [ERROR]-[2019-09-03 16:16:20]-[org.b3log.solo.service.InitService:186]: Check tables failed, please make sure database existed and database configuration [jdbc.*] in local.props is correct [msg=Communications link failure
solo     |
solo     | The last packet sent successfully to the server was 0 milliseconds ago. The driver has not received any packets from the server.]
```

### 1.3 解决方案（第一步）

经过一番的搜索发现、最新的 docker 镜像的环境变量发生了改变：即 `JDBC_DRIVER` 由原来的 `com.mysql.jdbc.Driver` 更改为了 `com.mysql.cj.jdbc.Driver`

```bash
# 原环境变量
JDBC_DRIVER=com.mysql.jdbc.Driver
JDBC_URL=jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC

# 新环境变量
JDBC_DRIVER=com.mysql.cj.jdbc.Driver
JDBC_URL=jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC

```

### 1.4 解决方案（第二步）

在更改了环境变量之后、再次启动相应的docker 镜像发现依旧报错、但是错误信息已经发生了变化、这是一个好消息！

新的报错信息为 ` Connection Java-MySql : Public Key Retrieval is not allowed`

解决方法为：更改 JDBC_URL 为下面的示例、即添加 `allowPublicKeyRetrieval=true` 这一信息、再次启动镜像即可：

```bash
JDBC_URL=jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&allowPublicKeyRetrieval=true&useSSL=false&serverTimezone=UTC
```

