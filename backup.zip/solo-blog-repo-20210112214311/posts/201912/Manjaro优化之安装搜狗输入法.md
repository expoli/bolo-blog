title: Manjaro 优化之——安装搜狗输入法
date: '2019-12-27 12:00:08'
updated: '2019-12-27 12:00:08'
tags: [Manjaro, 坑, 转载, Note]
permalink: /articles/2019/12/27/1577419208880.html
---
![](https://img.hacpai.com/bing/20180913.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Manjaro 优化之——安装搜狗输入法

1. 首先，如果以前安装了fcitx，全部删除：

```text
sudo pacman -Rsn fcitx-im fcitx-configtool
```

2. 然后安装fcitx-lilydjwg-git这个包和搜狗输入法包（需要archlinuxcn源），fcitx-lilydjwg-git这个包用来替换fcitx-im包组中除fcitx-qt5之外的所有包，其中包含了fcitx-qt4包。

```text
sudo pacman -S fcitx-lilydjwg-git fcitx-sogoupinyin
```

3. 到这里，archlinux下的搜狗输入法基本就安装好了，但是还没有安装fcitx图形设置界面，另外少了个fcitx-qt5包，不能在qt5程序下输入，需要继续安装：

- GNOME（GTK）用户：

```text
sudo pacman -S fcitx-configtool fcitx-qt5
```

注意：fcitx-qt5可选依赖于fcitx-configtool，可以直接安装fcitx-configtool，然后选择fcitx-qt5。

- KDE（QT）用户：

```text
sudo pacman -S kcm-fcitx
```

kcm-fcitx这个包依赖于fcitx-qt5，所以后者就不用再次安装了。

4. 至此，archlinux下的搜狗输入法就安装好了，不要忘了添加用户变量环境：

```text
~/.xprofile

export GTK_IM_MODULE=fcitx
export QT_IM_MODULE=fcitx
export XMODIFIERS="@im=fcitx"
```

最后注销再重新登录就OK了！
