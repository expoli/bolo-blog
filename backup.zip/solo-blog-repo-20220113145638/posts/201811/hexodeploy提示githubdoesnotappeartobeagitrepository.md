title: hexo deploy 提示 'github' does not appear to be a git repository
date: '2018-11-17 11:30:08'
updated: '2018-11-17 11:30:08'
tags: [Hexo]
permalink: /articles/2018/11/17/1564656235419.html
---
![image.png](./18-11-17-hexo-deploy-'github'-does-not-appear-to-be-a-git-repository/image.png)

## 解决方案

<!-- more -->

* 删除 `.deploy` 文件夹再 `hexo d`

* 配置：global user.email/user.name

* 执行：hexo deploy，成功

在执行 `hexo clean` 的时候只删除了 `db.json` 和 `public` 文件夹，并没有删除`.deploy` 文件夹

所以才有可能出现 `'github' does not appear to be a git repository` 的现象

参考链接：[https://github.com/hexojs/hexo/issues/612](https://github.com/hexojs/hexo/issues/612)