title: 阿里云内网OSS测试
date: '2021-06-08 08:39:35'
updated: '2021-06-08 08:40:13'
tags: [待分类]
permalink: /articles/2021/06/08/1623112775697.html
---
[20210607193802.mp4](https://oss.expoli.tech/img/EHD_2021-06-07-19-38-02.mp4)
