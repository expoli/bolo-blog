title: GRUB 设置默认启动项
date: '2020-01-27 12:57:12'
updated: '2020-01-27 18:31:09'
tags: [Linux, Arch, GRUB]
permalink: /articles/2020/01/27/1580101032107.html
---
![](https://img.hacpai.com/bing/20190604.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# GRUB 设置默认启动项

原来在使用 NVIDIA 的官方。run 文件安装 NVIDIA 驱动程序的时候，需要安装 linux-headers 文件，但是在操作的时候一不小心，安装了另一个内核。（原来的内核是`5.4.15`，新安装的内核版本为`linux-lts 4.19.98-1`）。

所以想在开机的 GRUB 页面自动启用相应的内核，省去了手动选择的麻烦。

## 解决方案

### 1. 查看 GRUB 启动菜单

通过查询关键字 `menuentry` 分析启动菜单的情况。

从下面的输出我们可以看到，现在的默认启动项为`Arch Linux`，经测试这个启动项的默认启动内核为 LTS 内核，如果你想切换为较新的内核，可以看到在`Arch Linux` 的高级选项子菜单内有着使用哪个内核的提示。

- `menuentry 'Arch Linux, with Linux linux-lts'`
  - 此启动项使用的是 LTS 内核
- `menuentry 'Arch Linux, with Linux linux'`
  - 此启动项使用的是最新内核

```
sudo grep menuentry /boot/grub/grub.cfg
if [ x"${feature_menuentry_id}" = xy ]; then
  menuentry_id_option="--id"
  menuentry_id_option=""
export menuentry_id_option
menuentry 'Arch Linux' --class arch --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-simple-f66fe267-a68c-' {
submenu 'Advanced options for Arch Linux' $menuentry_id_option 'gnulinux-advanced-f66fe267-a68c-' {
        menuentry 'Arch Linux, with Linux linux-lts' --class arch --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-linux-lts-advanced-f66fe267-a68c-' {
        menuentry 'Arch Linux, with Linux linux-lts (fallback initramfs)' --class arch --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-linux-lts-fallback-f66fe267-a68c-' {
        menuentry 'Arch Linux, with Linux linux' --class arch --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-linux-advanced-f66fe267-a68c-' {
        menuentry 'Arch Linux, with Linux linux (fallback initramfs)' --class arch --class gnu-linux --class gnu --class os $menuentry_id_option 'gnulinux-linux-fallback-f66fe267-a68c-' {
menuentry 'Windows Boot Manager (on /dev/sda1)' --class windows --class os $menuentry_id_option 'osprober-efi-0CAE-0' {
```

### 2. 设置默认启动项

设置默认启动项需要`grub-set-default`这个命令，如果没有可自行安装。

1. 查看命令帮助

从帮助信息里面可以看到，如果想让此命令发挥相应的作用需要在`/etc/default/grub`文件内设置`GRUB_DEFAULT=saved`参数。

```
sudo grub-set-default                    
Menu entry not specified.
Usage: grub-set-default [OPTION] MENU_ENTRY
Set the default boot menu entry for GRUB.
This requires setting GRUB_DEFAULT=saved in /etc/default/grub.

  -h, --help              print this message and exit
  -V, --version           print the version information and exit
  --boot-directory=DIR    expect GRUB images under the directory DIR/grub
                          instead of the /boot/grub directory

MENU_ENTRY is a number, a menu item title or a menu item identifier.

Report bugs to <bug-grub@gnu.org>.
```

2. 开始设置

运行下面的命令即可设置默认的启动项，如果你想默认启用其他启动项，设置方法类似。

`sudo grub-set-default 'Advanced options for Arch Linux>Arch Linux, with Linux linux'`

`Advanced options for Arch Linux` ：主菜单

`Arch Linux, with Linux linux`：子菜单

### 3. 生成 GRUB 主配置文件

```
sudo grub-mkconfig -o /boot/grub/grub.cfg
```

### 4. 重启验证

参考：https://unix.stackovernet.com/cn/q/54488
