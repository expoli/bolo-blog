title: saltstack项目实战-haproxy
date: '2019-08-30 21:26:54'
updated: '2019-08-30 21:26:54'
tags: [Saltstack, 运维]
permalink: /articles/2019/08/30/1567171614602.html
---
![](https://oss.expoli.tech/img/XWT_201801261042508850294320935.jpg)

# saltstack项目实战-haproxy

## 1. 源码安装 haproxy

### 1. 创建文件夹

```bash
# 
cd /srv/salt/prod

mkdir -p haproxy keepalived nginx php memcached pkg
```

### 2. pkg 基础的包安装

```yaml
# make.sls

make-pkg:
  pkg.installed:
    - pkgs:
      - gcc
      - gcc-c++
      - glibc
      - make
      - autoconf
      - openssl
      - openssl-devel
      - pcre
      - pcre-devel
      - systemd-devel.x86_64
```

### 3. 下载编译 haproxy

```bash
cp ~/haproxy-2.0.3.tar.gz /usr/local/src 
tar zxf haproxy-2.0.3.tar.gz
make -j $(nproc) TARGET=linux-glibc \
                USE_OPENSSL=1 USE_ZLIB=1 USE_PCRE=1 

make install PREFIX=/usr/local/haproxy-2.0.3
ln -s /usr/local/haproxy-2.0.3/ /usr/local/haproxy
```
### 4. 修改启动脚本

文件路径：`./haproxy-2.0.3/examples`

修改 haproxy.init 的 BIN 路径

```bash
BIN=/usr/sbin/$BASENAME -->
BIN=/usr/local/haproxysbin/$BASENAME
```

复制 init 文件到 /srv/salt/prod/haproxy/files

```bash
cp haproxy.init /srv/salt/prod/haproxy/files
```

### 5. 编写 sls 脚本

```yaml
# vim install.sls
include:
  - pkg.make

haproxy-install:
  file.managed:
    - name: /usr/local/src/haproxy-2.0.3.tar.gz
    - source: salt://haproxy/files/haproxy-2.0.3.tar.gz
    - mode: 755
    - user: root
    - group: root
  cmd.run:
    - name: cd /usr/local/src && tar zxf haproxy-2.0.3.tar.gz && cd haproxy-2.0.3 && make -j $(nproc) TARGET=linux-glibc USE_OPENSSL=1 USE_ZLIB=1 USE_PCRE=1 PREFIX=/usr/local/haproxy-2.0.3 && make install PREFIX=/usr/local/haproxy-2.0.3 && ln -s /usr/local/haproxy-2.0.3/ /usr/local/haproxy 
    - require:
      - pkg: make-pkg
      - file: haproxy-install



```

### 6. 测试：


```bash
salt '*' state.sls haproxy.install saltenv=prod
```

### 7. 继续学习状态之间的关系

1. unless 如果unless 后面的命令为Ture 那么cmd.run 不执行
2. onlyif

```yaml
# vim install.sls
include:
  - pkg.make-pkg

haproxy-install:
  file.managed:
    - name: /usr/local/src/haproxy-2.0.3.tar.gz
    - source: salt://haproxy/files/haproxy-2.0.3.tar.gz
    - mode: 755
    - user: root
    - group: root
  cmd.run:
    - name: cd /usr/local/src && tar zxf haproxy-2.0.3.tar.gz && cd haproxy-2.0.3 && make -j $(nproc) TARGET=linux-glibc USE_OPENSSL=1 USE_ZLIB=1 USE_PCRE=1 USE_SYSTEMD=1 PREFIX=/usr/local/haproxy-2.0.3 && make install PREFIX=/usr/local/haproxy-2.0.3 && ln -s /usr/local/haproxy-2.0.3/ /usr/local/haproxy 
    # 查看一个文件是不是软连接
    # 如果为 true 就不执行
    - unless: test -L /usr/local/haproxy
    - require:
      - pkg: make-pkg
      - file: haproxy-install

```

测试：

```bash
salt '*' state.sls haproxy.install saltenv=prod test=True
```

输出：

```js
192.168.0.134:
----------
          ID: make
    Function: pkg.installed
      Result: True
 

```

### 8. 启动脚本



```yaml
# vim install.sls
include:
  - pkg.make-pkg

haproxy-install:
  file.managed:
    - name: /usr/local/src/haproxy-2.0.3.tar.gz
    - source: salt://haproxy/files/haproxy-2.0.3.tar.gz
    - mode: 755
    - user: root
    - group: root
  cmd.run:
    - name: cd /usr/local/src && tar zxf haproxy-2.0.3.tar.gz && cd haproxy-2.0.3 && make -j $(nproc) TARGET=linux-glibc USE_OPENSSL=1 USE_ZLIB=1 USE_PCRE=1 USE_SYSTEMD=1 PREFIX=/usr/local/haproxy-2.0.3 && make install PREFIX=/usr/local/haproxy-2.0.3 && ln -s /usr/local/haproxy-2.0.3/ /usr/local/haproxy 
    # 查看一个文件是不是软连接
    # 如果为 true 就不执行
    - unless: test -L /usr/local/haproxy
    - require:
      - pkg: make-pkg
      - file: haproxy-install

/etc/init.d/haproxy:
  file.managed:
    - source: salt://haproxy/files/haproxy.init
    - mode: 755
    - user: root
    - group: root
    - require_in:
      - file: haproxy-install
# 修改内核参数、管理vip
# vip 非本地参数、在主备机上切换
# 主备机都需要起来 haproxy
# linux 不允许监听非本地端口
net.ipv4.ip_nonlocal_bind:
  sysctl.present:
    - value: 1
```

测试：
```bash
salt '*' state.sls haproxy.install saltenv=prod test=True
```

### 9. 目录管理


```yaml
# vim install.sls
include:
  - pkg.make-pkg

haproxy-install:
  file.managed:
    - name: /usr/local/src/haproxy-2.0.3.tar.gz
    - source: salt://haproxy/files/haproxy-2.0.3.tar.gz
    - mode: 755
    - user: root
    - group: root
  cmd.run:
    - name: cd /usr/local/src && tar zxf haproxy-2.0.3.tar.gz && cd haproxy-2.0.3 && make -j $(nproc) TARGET=linux-glibc USE_OPENSSL=1 USE_ZLIB=1 USE_PCRE=1 USE_SYSTEMD=1 PREFIX=/usr/local/haproxy-2.0.3 && make install PREFIX=/usr/local/haproxy-2.0.3 && ln -s /usr/local/haproxy-2.0.3/ /usr/local/haproxy 
    # 查看一个文件是不是软连接
    # 如果为 true 就不执行
    - unless: test -L /usr/local/haproxy
    - require:
      - pkg: make-pkg
      - file: haproxy-install

/etc/init.d/haproxy:
  file.managed:
    - source: salt://haproxy/files/haproxy.init
    - mode: 755
    - user: root
    - group: root
    - require_in:
      - file: haproxy-install
# 修改内核参数、管理vip
# vip 非本地参数、在主备机上切换
# 主备机都需要起来 haproxy
# linux 不允许监听非本地端口
net.ipv4.ip_nonlocal_bind:
  sysctl.present:
    - value: 1

/etc/haproxy:
  file.directory:
    - user: root
    - group: root
    - mode: 755
```

### 10. 目前的目录结构

```js
➜  files tree /srv/salt/prod/
/srv/salt/prod/
├── haproxy
│   ├── files
│   │   ├── haproxy-2.0.3.tar.gz
│   │   └── haproxy.init
│   └── install.sls
├── keepalived
├── memcached
├── nginx
├── php
└── pkg
    └── make.sls

7 directories, 4 file
```

### 11. 业务层面引用

4台、2台对外、2台对内

修改目录结构

```bash
➜  prod tree
.
├── cluster # 所有的业务
└── modules # 所有的模块
    ├── haproxy
    │   ├── files
    │   │   ├── haproxy-2.0.3.tar.gz
    │   │   └── haproxy.init
    │   └── install.sls
    ├── keepalived
    ├── memcached
    ├── nginx
    ├── php
    └── pkg
        └── make.sls

9 directories, 4 files
```

```yaml
include:
  - modules.pkg.make

haproxy-install:
  file.managed:
    - name: /usr/local/src/haproxy-2.0.3.tar.gz
    - source: salt://modules/haproxy/files/haproxy-2.0.3.tar.gz
    - mode: 755
    - user: root
    - group: root
  cmd.run:
    - name: cd /usr/local/src && tar zxf haproxy-2.0.3.tar.gz && cd haproxy-2.0.3 && make -j $(nproc) TARGET=linux-glibc USE_OPENSSL=1 USE_ZLIB=1 USE_PCRE=1 USE_SYSTEMD=1 PREFIX=/usr/local/haproxy-2.0.3 && make install PREFIX=/usr/local/haproxy-2.0.3 && ln -s /usr/local/haproxy-2.0.3/ /usr/local/haproxy
    # 查看一个文件是不是软连接
    # 如果为 true 就不执行
    - unless: test -L /usr/local/haproxy
    - require:
      - pkg: make-pkg
      - file: haproxy-install

/etc/init.d/haproxy:
  file.managed:
    - source: salt://modules/haproxy/files/haproxy.init
    - mode: 755
    - user: root
    - group: root
    - require_in:
      - file: haproxy-install

net.ipv4.ip_nonlocal_bind:
  sysctl.present:
    - value: 1
/etc/haproxy:
  file.directory:
    - user: root
    - group: root
    - mode: 755

```

测试

```
salt '*' state.sls modules.haproxy.install saltenv=prod test=True
salt '*' state.sls modules.haproxy.install saltenv=prod
```

### 12. 创建业务文件

/srv/salt/prod/cluster/files

```bash
# vim /srv/salt/prod/cluster/files/haproxy-outside.cfg

global
maxconn 100000
chroot /usr/local/haproxy
uid 99  
gid 99 
daemon
nbproc 1 
pidfile /usr/local/haproxy/logs/haproxy.pid 
log 127.0.0.1 local3 info

defaults
option http-keep-alive
maxconn 100000
mode http
timeout connect 5000ms
timeout client  50000ms
timeout server 50000ms

listen stats
mode http
bind 0.0.0.0:8888
stats enable
stats uri     /haproxy-status 
stats auth    haproxy:saltstack

frontend frontend_www_example_com
bind 192.168.56.21:80
mode http
option httplog
log global
    default_backend backend_www_example_com

backend backend_www_example_com
option forwardfor header X-REAL-IP
option httpchk HEAD / HTTP/1.0
balance source
server web-node1  192.168.56.11:8080 check inter 2000 rise 30 fall 15
server web-node2  192.168.56.12:8080 check inter 2000 rise 30 fall 15
```

/srv/salt/prod/cluster/haproxy-outside.sls

```yaml
include:
  - modules.haproxy.install

haproxy-service:
  file.managed:
    - name: /etc/haproxy/haproxy.cfg
    - source: salt://cluster/files/haproxy-outside.cfg
    - user: root
    - group: root
    - mode: 644
  service.running:
    - name: haproxy
    - enable: True
    - reload: True
    - require:
      - cmd: haproxy-install
    - watch:
      - file: haproxy-service

```

### 13. 修改 top file

/srv/salt/base/top.sls

```
base:
  '*':
    - init.init
prod:
  '192.168.*':
    - cluster.haproxy-outside

```

```bash
# haproxy 绑定了 80 端口
systemctl disable httpd
systemctl stop httpd
```

### 14. 高级状态测试与执行

```bash
salt '192.168.0.115' state.highstate test=Ture

salt '*' state.highstate
```

## 2. 源码安装 keepalived-2.0-18

### 0. 目录结构

```js
➜  keepalived tree
.
├── files
│   ├── keepalived-2.0.18.tar.gz
│   ├── keepalived.init
│   └── keepalived.sysconfig
└── install.sls

1 directory, 4 files
```

### 1. install.sls

```yaml
keepalived-install:
  file.managed:
    - name: /usr/local/src/keepalived-2.0.18.tar.gz
    - source: salt://modules/keepalived/files/keepalived-2.0.18.tar.gz
    - mode: 755
    - user: root
    - group: root
  cmd.run:
    - name: cd /usr/local/src && tar zxf keepalived-2.0.18.tar.gz && cd keepalived-2.0.18 && ./configure --prefix=/usr/local/keepalived --disable-fwmark && make && make install
    - unless: test -d /usr/local/keepalived
    - require:
      - file: keepalived-install

/etc/sysconfig/keepalived:
  file.managed:
    - source: salt://modules/keepalived/files/keepalived.sysconfig
    - mode: 644
    - user: root
    - group: root

/etc/init.d/keepalived:
  file.managed:
    - source: salt://modules/keepalived/files/keepalived.init
    - mode: 755
    - user: root
    - group: root

keepalived-init:
  cmd.run:
    - name: chkconfig --add keepalived
    - unless: chkconfig --list | grep keepalived
    - require:
      - file: /etc/init.d/keepalived

/etc/keepalived:
  file.directory:
    - user: root
    - group: root
```

### 2. keepalived.init

```bash
#!/bin/sh
#
# Startup script for the Keepalived daemon
#
# processname: keepalived
# pidfile: /var/run/keepalived.pid
# config: /etc/keepalived/keepalived.conf
# chkconfig: - 21 79
# description: Start and stop Keepalived

# Source function library
. /etc/rc.d/init.d/functions

# Source configuration file (we set KEEPALIVED_OPTIONS there)
. /etc/sysconfig/keepalived

RETVAL=0

prog="keepalived"

start() {
    echo -n $"Starting $prog: "
#    daemon keepalived ${KEEPALIVED_OPTIONS}
    daemon /usr/local/keepalived/sbin/keepalived ${KEEPALIVED_OPTIONS}
    RETVAL=$?
    echo
    [ $RETVAL -eq 0 ] && touch /var/lock/subsys/$prog
}

stop() {
    echo -n $"Stopping $prog: "
    killproc keepalived
    RETVAL=$?
    echo
    [ $RETVAL -eq 0 ] && rm -f /var/lock/subsys/$prog
}

reload() {
    echo -n $"Reloading $prog: "
    killproc keepalived -1
    RETVAL=$?
    echo
}

# See how we were called.
case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    reload)
        reload
        ;;
    restart)
        stop
        start
        ;;
    condrestart)
        if [ -f /var/lock/subsys/$prog ]; then
            stop
            start
        fi
        ;;
    status)
        status keepalived
        RETVAL=$?
        ;;
    *)
        echo "Usage: $0 {start|stop|reload|restart|condrestart|status}"
        RETVAL=1
esac

exit $RETVAL
```

### 3. keepalived.sysconfig

```conf
# Options for keepalived. See `keepalived --help' output and keepalived(8) and
# keepalived.conf(5) man pages for a list of all options. Here are the most
# common ones :
#
# --vrrp               -P    Only run with VRRP subsystem.
# --check              -C    Only run with Health-checker subsystem.
# --dont-release-vrrp  -V    Dont remove VRRP VIPs & VROUTEs on daemon stop.
# --dont-release-ipvs  -I    Dont remove IPVS topology on daemon stop.
# --dump-conf          -d    Dump the configuration data.
# --log-detail         -D    Detailed log messages.
# --log-facility       -S    0-7 Set local syslog facility (default=LOG_DAEMON)
#

KEEPALIVED_OPTIONS="-D"
```

### 4. 测试与运行

```bash
salt '*' state.sls modules.keepalived.install saltenv=prod test=Ture
salt '*' state.sls modules.keepalived.install saltenv=prod
```

### 5. 设置配置文件

```js
➜  cluster tree
.
├── files
│   ├── haproxy-outside.cfg
│   └── haproxy-outside-keepalived.conf
├── haproxy-outside-keepalived.sls
└── haproxy-outside.sls

1 directory, 4 files
```

### 6. haproxy-outside.sls

```yaml
include:
  - modules.haproxy.install

haproxy-service:
  file.managed:
    - name: /etc/haproxy/haproxy.cfg
    - source: salt://cluster/files/haproxy-outside.cfg
    - user: root
    - group: root
    - mode: 644
  service.running:
    - name: haproxy
    - enable: True
    - reload: True
    - require:
      - cmd: haproxy-install
    - watch:
      - file: haproxy-service
```

### 7. haproxy-outside-keepalived.sls

```yaml
include:
  - modules.keepalived.install

keepalived-server:
  file.managed:
    - name: /etc/keepalived/keepalived.conf
    - source: salt://cluster/files/haproxy-outside-keepalived.conf
    - mode: 644
    - user: root
    - group: root
    - template: jinja
    {% if grains['fqdn'] == 'centos7-node1-192.168.0.138' %}
    - ROUTEID: haproxy_ha
    - STATEID: MASTER
    - PRIORITYID: 150
    {% elif grains['fqdn'] == 'centos7-node2-192.168.0.115' %}
    - ROUTEID: haproxy_ha
    - STATEID: BACKUP
    - PRIORITYID: 100
    {% endif %}
  service.running:
    - name: keepalived
    - enable: True
    - watch:
      - file: keepalived-server

```

### 8. haproxy-outside-keepalived.conf

```conf
! Configuration File for keepalived
global_defs {
   notification_email {
     saltstack@example.com
   }
   notification_email_from keepalived@example.com
   smtp_server 127.0.0.1
   smtp_connect_timeout 30
   router_id {{ ROUTEID }}
}

vrrp_instance haproxy_ha {
state {{ STATEID }}
# 网卡名称需要注意
interface enp0s3
    virtual_router_id 36
priority {{ PRIORITYID }}
    advert_int 1
authentication {
auth_type PASS
        auth_pass 1111
    }
    virtual_ipaddress {
       192.168.56.21
    }
}

```

### 9. haproxy-outside.cfg

```cfg
global
maxconn 100000
chroot /usr/local/haproxy
uid 99  
gid 99 
daemon
nbproc 1 
pidfile /usr/local/haproxy/logs/haproxy.pid 
log 127.0.0.1 local3 info

defaults
option http-keep-alive
maxconn 100000
mode http
timeout connect 5000ms
timeout client  50000ms
timeout server 50000ms

listen stats
mode http
bind 0.0.0.0:8888
stats enable
stats uri     /haproxy-status 
stats auth    haproxy:saltstack

frontend frontend_www_example_com
bind 192.168.56.21:80
mode http
option httplog
log global
    default_backend backend_www_example_com

backend backend_www_example_com
option forwardfor header X-REAL-IP
option httpchk HEAD / HTTP/1.0
balance source
server web-node1  192.168.56.21:8080 check inter 2000 rise 30 fall 15
server web-node2  192.168.56.22:8080 check inter 2000 rise 30 fall 15
```

### 10. 测试

随意停止一个服务的名称、可以看到虚拟IP在两台机器进行来回的切换

haproxy 具有会话保持功能：`balance source` 配置项





