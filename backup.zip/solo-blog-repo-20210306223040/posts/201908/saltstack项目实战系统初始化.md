title: saltstack项目实战-系统初始化
date: '2019-08-30 21:24:59'
updated: '2019-08-30 21:24:59'
tags: [Saltstack, 运维]
permalink: /articles/2019/08/30/1567171499458.html
---
![](https://img.hacpai.com/bing/20180128.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# saltstack项目实战-系统初始化

戴明环

## 1. 系统初始化

## 2. 功能模块

尽可能地全、独立、做个基础

### 设置单独的目录
- haproxy
- nginx
- php
- mysql
- memcached

## 3. 业务模块：根据业务类型划分，例如Web服务。论坛 bbs

include 

## 干活

1. salt 环境配置

![https://github.com/zzutcy/saltbook-code](https://github.com/zzutcy/saltbook-code)

开发 测试（功能测试环境、性能测试环境） 预生产 生产

1. base 基础环境 
   1. init目录 环境初始化
      1. DNS配置
      2. history 记录时间
      3. 记录命令操作
      4. 内核参数优化
      5. 安装yum仓库
      6. 安装zabbix-agent
2. prod 生产环境

------------

1. 修改 `/etc/salt/master ` 配置文件中地 file_roots

```yaml
#####      File Server settings      #####
##########################################
# Salt runs a lightweight file server written in zeromq to deliver files to
# minions. This file server is built into the master daemon and does not
# require a dedicated port.

# The file server works on environments passed to the master, each environment
# can have multiple root directories, the subdirectories in the multiple file
# roots cannot match, otherwise the downloaded files will not be able to be
# reliably ensured. A base environment is required to house the top file.
# Example:
# file_roots:
#   base:
#     - /srv/salt/
#   dev:
#     - /srv/salt/dev/services
#     - /srv/salt/dev/states
#   prod:
#     - /srv/salt/prod/services
#     - /srv/salt/prod/states
#
file_roots:
# 基础环境
  base:
    - /srv/salt/base
# 生产环境
  prod:
    - /srv/salt/prod
```

2. 创建相关文件夹

```bash
# mkdir -p /srv/salt/base
# mkdir -p /srv/salt/prod
```

3. 修改 `/etc/salt/master` 中地 `pillar` 配置

```yaml
#####         Pillar settings        #####
##########################################
# Salt Pillars allow for the building of global data that can be made selectively
# available to different minions based on minion grain filtering. The Salt
# Pillar is laid out in the same fashion as the file server, with environments,
# a top file and sls files. However, pillar data does not need to be in the
# highstate format, and is generally just key/value pairs.
pillar_roots:
  base:
    - /srv/pillar/base
  prod:
    - /srv/pillar/prod
```

4. 创建相关文件夹

```bash
mkdir -p /srv/pillar/base
mkdir -p /srv/pillar/prod
```

5. 重启 salt-master

```bash
systemctl restart salt-master
```

6. 创建、`/srv/salt/base/init` `/srv/salt/base/init/files` 文件夹、存放初始化文件、以及相关配置文件

```bash
mkdir -p /srv/salt/base/init
mkdir -p /srv/salt/base/init/files
```

### 7. 配置 DNS
   1. dns.sls
```yaml
/etc/resolv.conf:
  file.managed:
    - source: salt://init/files/resolv.conf
    - user: root
    - gourp: root
    - mode: 644
```

```bash
cp /etc/resolv.conf /srv/salt/base/init/files/
# 目录结构
# .
# ├── dns.sls
# └── files
#     └── resolv.conf

# 1 directory, 2 files

```

### 8. 配置 history 记录时间

- history.sls
```yaml
# 在/etc/profile 文件地末尾追加一行
/etc/profile:
  file.append:
  # 要写的内容
    - text:
      - export HISTTIMEFORMAT="%F %T `whoami` "
```

### 9.记录命令操作哦

- audit.sls

```yaml
/etc/bashrc:
  file.append:
    - text:
      - export PROMPT_COMMAND='{ msg=$(history 1 | { read x y; echo $y; });logger "[euid=$(whoami)]":$(who am i):[`pwd`]"$msg"; }'
```

### 10. 内核参数优化

- sysctl.sls

```yaml
# 本地可用的端口范围
# 作为客户端发起连接时候所使用的
# socket 网络套接字
# 五元组
# 源地址 源端口 目的地址 目的端口 协议
net.ipv4.ip_local_port_range:
  sysctl.present:
    - value: 10000 65000
# 打开的最大文件数
fs.file-max:
  sysctl.present:
    - value: 2000000
# Ip转发
net.ipv4.ip_forward:
  sysctl.present:
    - value: 1
# 交换分区使用的权重
# 0值为尽量不使用
vm.swappiness:
  sysctl.present:
    - value: 0
```

### 11. 安装yum仓库

- epel.sls

```yaml
aliyun_yum_repo_release:
  pkg.installed:
    - sources:
      - epel-release: https://mirrors.aliyun.com/epel/epel-release-latest-7.noarch.rpm
zabbix_4.0_repo:
  cmd.run:
    - names:
      - rpm -ivh https://repo.zabbix.com/zabbix/4.0/rhel/7/x86_64/zabbix-release-4.0-1.el7.noarch.rpm
      - yum clean all
      - yum makecache
    - unless:
      - cat /etc/yum.repos.d/zabbix.repo
```

### 12. 安装 zabbix-agent

```yaml
zabbix-agent:
  pkg.installed:
    - name: zabbix-agent
  file.managed:
    - name: /etc/zabbix/zabbix_agentd.conf
    - source: salt://init/files/zabbix_agentd.conf
    - template: jinja
    - defaults:
    # 取到 Zabbix_Server 的值
      Server: {{ pillar['zabbix-agent']['Zabbix_Server'] }}
    - require:
      - pkg: zabbix-agent
  service.running:
    - enable: True
    - watch:
      - pkg: zabbix-agent
      - file: zabbix-agent
zabbix_agentd.conf.d:
  file.directory:
    - name: /etc/zabbix/zabbix_agentd.d
    - watch_in:
      - service: zabbix-agent
    - require:
      - pkg: zabbix-agent
      - file: zabbix-agent
```

```bash
# 复制文件
cp /etc/zabbix/zabbix_agentd.conf base/init/files
# 修改文件里面的 server 字段
Server= {{ Zabbix_Server }}

# 启动会报错

# 还未配置 pillar
cd /srv/pillar/base

pillar/base/zabbix/agent.sls
```

```yaml
# top.sls
base:
  '*':
    - zabbix.agent

# agent.sls
zabbix-agent:
  Zabbix_Server: 192.168.56.21

# salt "*" state.sls init.zabbix-agent 
# 运行测试
```

### 13. 高级状态的 init.sls 文件

高级状态：按照 top.sls 执行

```yaml
# /srv/salt/base/init
# 文件路径

include:
  - init.dns
  - init.history
  - init.audit
  - init.sysctl
  - init.epel
  - init.zabbix-agent

# salt "*" state.sls init.init
# 运行测试
```

```yaml
# /srv/salt/base/top.sls
base:
  '*':
    - init.init

➜  base tree
.
├── init
│   ├── audit.sls
│   ├── dns.sls
│   ├── epel.sls
│   ├── files
│   │   ├── resolv.conf
│   │   └── zabbix_agentd.conf
│   ├── history.sls
│   ├── init.sls
│   ├── sysctl.sls
│   └── zabbix-agent.sls
└── top.sls
```

```yaml
# zabbix_agent 主动模式
# 在配置文件里面设定
Hostname = {{ Hostname }}


zabbix-agent:
  pkg.installed:
    - name: zabbix-agent
  file.managed:
    - name: /etc/zabbix/zabbix_agentd.conf
    - source: salt://init/files/zabbix_agentd.conf
    - template: jinja
    - defaults:
    # 取到 Zabbix_Server 的值
      Server: {{ pillar['zabbix-agent']['Zabbix_Server'] }}
      Hostname: {{ grains['fqdn'] }}
    - require:
      - pkg: zabbix-agent
  service.running:
    - enable: True
    - watch:
      - pkg: zabbix-agent
      - file: zabbix-agent
zabbix_agentd.conf.d:
  file.directory:
    - name: /etc/zabbix/zabbix_agentd.d
    - watch_in:
      - service: zabbix-agent
    - require:
      - pkg: zabbix-agent
      - file: zabbix-agent

# 测试
# salt '192.168.0.13*' state.highstate test=True
```

### 14. salt backup 对改动文件进行备份

```yaml
zabbix-agent:
  pkg.installed:
    - name: zabbix-agent
  file.managed:
    - name: /etc/zabbix/zabbix_agentd.conf
    - source: salt://init/files/zabbix_agentd.conf
    - template: jinja
    # 更改备份
    - backup: minion
    - defaults:
    # 取到 Zabbix_Server 的值
      Server: {{ pillar['zabbix-agent']['Zabbix_Server'] }}
    - require:
      - pkg: zabbix-agent
  service.running:
    - enable: True
    - watch:
      - pkg: zabbix-agent
      - file: zabbix-agent
zabbix_agentd.conf.d:
  file.directory:
    - name: /etc/zabbix/zabbix_agentd.d
    - watch_in:
      - service: zabbix-agent
    - require:
      - pkg: zabbix-agent
      - file: zabbix-agent

# 备份文件路径在 /var/cache/salt/minion
➜  minion tree
.
├── accumulator
├── extmods
├── extrn_files
│   └── base
│       └── mirrors.aliyun.com
│           └── epel
│               └── epel-release-latest-7.noarch.rpm
├── file_backup
│   └── etc
│       └── zabbix
│           └── zabbix_agentd.conf_Fri_Jul_26_03:53:26_104407_2019

```
