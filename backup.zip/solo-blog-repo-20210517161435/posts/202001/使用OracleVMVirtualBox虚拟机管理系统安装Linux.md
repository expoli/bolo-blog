title: 使用 Oracle VM VirtualBox 虚拟机管理系统安装 Linux
date: '2020-01-18 12:27:23'
updated: '2020-01-18 12:27:49'
tags: [Linux, Note]
permalink: /articles/2020/01/18/1579321643232.html
---
![](https://img.hacpai.com/bing/20190528.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 使用 VirtualBox 虚拟机管理系统安装 Linux

## 1 下载安装包

## 1.1 下载主体安装包

截止今天：2020.01.18 最新版本为，选择对应自己系统版本的安装包即可。下载地址：https://www.virtualbox.org/wiki/Downloads

---
### [VirtualBox](https://www.virtualbox.org/wiki/VirtualBox) 6.1.2 platform packages

* [ Windows hosts](https://download.virtualbox.org/virtualbox/6.1.2/VirtualBox-6.1.2-135663-Win.exe)
* [ OS X hosts](https://download.virtualbox.org/virtualbox/6.1.2/VirtualBox-6.1.2-135662-OSX.dmg)
* [Linux distributions](https://www.virtualbox.org/wiki/Linux_Downloads)
* [ Solaris hosts](https://download.virtualbox.org/virtualbox/6.1.2/VirtualBox-6.1.2-135662-SunOS.tar.gz)

The binaries are released under the terms of the GPL version 2.
--- 

## 1.2 下载拓展包

### [VirtualBox](https://www.virtualbox.org/wiki/VirtualBox) 6.1.2 Oracle VM VirtualBox Extension Pack

* [ All supported platforms](https://download.virtualbox.org/virtualbox/6.1.2/Oracle_VM_VirtualBox_Extension_Pack-6.1.2.vbox-extpack)

Support for USB 2.0 and USB 3.0 devices, VirtualBox RDP, disk encryption, NVMe and PXE boot for Intel cards. See [this chapter from the User Manual](https://www.virtualbox.org/manual/ch01.html#intro-installing) for an introduction to this Extension Pack. The Extension Pack binaries are released under the [VirtualBox Personal Use and Evaluation License (PUEL)](https://www.virtualbox.org/wiki/VirtualBox_PUEL). *Please install the same version extension pack as your installed version of VirtualBox.*

## 2 安装 Oracle VM VirtualBox 

emmm 这个没什么好说的、安装完成 VirtualBox 主体程序之后，双击拓展包即可将拓展包添加至VirtualBox中。

## 3 下载Linux镜像

打开清华大学开源镜像站 [https://mirrors.tuna.tsinghua.edu.cn/](https://mirrors.tuna.tsinghua.edu.cn/)，选择网页右侧获取发行版下载链接，推荐 Ubuntu LTS Desktop 版本，选择 16.04 或者更高版本都可。

## 4 创建虚拟机

根据自己电脑的配置进行内存与硬盘空间的分配。（内存当然越多越好。）

![20200118120635屏幕截图.png](https://img.hacpai.com/file/2020/01/20200118120635屏幕截图-458446e9.png)

选择现在创建磁盘、并且设置为动态分配，当然你想提高一些性能的话可以选择固定大小（要保证宿主机有足够的空间哟）。

![20200118120759屏幕截图.png](https://img.hacpai.com/file/2020/01/20200118120759屏幕截图-206a8fdb.png)

![5.png](https://img.hacpai.com/file/2020/01/5-f27be79c.png)

## 5 配置虚拟机

### 5.1 配置UEFI启动支持

选中你想配置的虚拟机点击 `设置` -> `系统` -> `勾选 启用EFI`（我比较喜欢EFI启动）

![20200118121252屏幕截图.png](https://img.hacpai.com/file/2020/01/20200118121252屏幕截图-1ee964c2.png)

### 5.2 添加光驱启动镜像

选择 `储存` -> `控制器：SATA` -> 点击高亮条目左侧的添加光驱的按钮

![image.png](https://img.hacpai.com/file/2020/01/image-5b8dbc4c.png)
![image.png](https://img.hacpai.com/file/2020/01/image-7c6d0e66.png)

点击注册按钮、找到你的iso镜像目录，打开想安装系统的镜像。

![image.png](https://img.hacpai.com/file/2020/01/image-b243f76c.png)

最终类似于这样

![image.png](https://img.hacpai.com/file/2020/01/image-186867d8.png)

双击你想挂载的镜像文件，会自动退出窗口，看到类似于下方的界面

![image.png](https://img.hacpai.com/file/2020/01/image-c6557dea.png)

最终的设置大概类似于下面

![1.png](https://img.hacpai.com/file/2020/01/1-a6b8e7b4.png)

## 6 启动虚拟机

OK！大功告成。

这个时候就可以点击启动按钮启动你的虚拟机了，祝你玩得愉快！


