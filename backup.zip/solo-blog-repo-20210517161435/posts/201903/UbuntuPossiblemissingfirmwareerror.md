title: Ubuntu Possible missing firmware error
date: '2019-03-22 10:46:08'
updated: '2019-03-22 10:46:08'
tags: [Ubuntu]
permalink: /articles/2019/03/22/1564656237880.html
---
# 一、现象描述

原来的 `Ubuntu 16.04` 系统因为编译 `Openwrt` （我也不清楚是不是因为这个、大雾） 导致系统桌面环境一直报错，同时也因为自己比较懒，同时手边也有实验室同学刚做好的启动盘，于是就顺手重新安装了一下系统，所以就重新安装了一下系统，不知道是因为他镜像版本的原因，在进行 `sudo apt-get update` 的时候会出现以下的错误：

```bash
W: Possible missing firmware /lib/firmware/i915/kbl_guc_ver9_14.bin for module i915
W: Possible missing firmware /lib/firmware/i915/bxt_guc_ver8_7.bin for module i915
```

搜索了一下发现是系统缺少相应的文件，既然找到了原因，那么下面就让我们解决问题吧！

# 二、开始解决问题

```bash
The download files are now called firmware blobs which is new-speak for firmware drivers. It stands for Binary Large OBject (BLOB).

Drivers are sorted by processor:

    bxt Broxton, Canceled in 2016, successor to Cherry Trail processors
    kbl Kabylake, 7th generation, eg i7-7700
    skl Skylake, 6th generation, eg i7-6700

# Match error message to driver needed

Compare the error message you are receiving by update-initramfs or update-grub to find the missing driver. In your example the message was "/lib/firmware/i915/kbl_guc_ver9_14.bin" so you are missing the Kabylake GuC called: kbl_guc_ver9_14.bin in the web page shown above. You don't want the newer one: kbl_guc_ver9_39.bin
```

## 1、下载所缺失的文件

这是下载地址 ： [https://git.kernel.org/pub/scm/linux/kernel/git/firmware/linux-firmware.git/tree/i915](https://git.kernel.org/pub/scm/linux/kernel/git/firmware/linux-firmware.git/tree/i915)

从下载页面找打你需要的文件，拷贝下载链接，然后有下载器进行下载 例如：`wget` `axel`。

```bash
# 使用 wget 进行下载
wget  https://git.kernel.org/pub/scm/linux/kernel/git/firmware/linux-firmware.git/tree/i915/bxt_guc_ver8_7.bin 
# 使用 axel 进行下载
axel -n 30 https://git.kernel.org/pub/scm/linux/kernel/git/firmware/linux-firmware.git/tree/i915/bxt_guc_ver8_7.bin
```

## 2、安装文件

文件安装极其简单就是使用 `sudo cp` 命令把文件放到塔应该在的位置里面。

```bash
sudo cp bxt_guc_ver8_7.bin /lib/firmware/i915/
sudo cp kbl_guc_ver9_14.bin /lib/firmware/i915/

```
## 3、验证

再运行一遍更新，检查错误是否已经消失了。

```bash
# 再运行一遍，发现错误已经消失了,问题解决！
sudo apt-get update
```