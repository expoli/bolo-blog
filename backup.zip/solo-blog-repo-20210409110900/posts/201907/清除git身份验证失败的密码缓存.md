title: 清除 git身份验证失败的密码缓存
date: '2019-07-27 19:46:08'
updated: '2019-08-19 19:54:48'
tags: [Git]
permalink: /articles/2019/07/27/1564656217885.html
---
# 清除 git身份验证失败的密码缓存

## 问题现象

有时候我们在使用 git ，输入密码的时候、有可能会输入错误、于是就会出现类似于下图的问题：

![Center.jpg](http://tc.expoli.tech/images/2019/07/27/Center.jpg)

## 解决方案

正确的操作方式为：

```bash
git config --system --unset credential.helper
```

在经过多方索索发现、大多数人都建议在上面的基础上再允许一条命令即:

```bash
git credential-manager uninstall
```

注意！上调=条命令并不是用来清除掉缓存在git中的用户名和密码的、而是用来 `卸载 credential-manager ` 、不过如果你想以后每次运行 git 的时候都输入密码的话卸载了也没关系。