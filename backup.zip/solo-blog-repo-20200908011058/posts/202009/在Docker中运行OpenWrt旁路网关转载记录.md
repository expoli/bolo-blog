title: 在Docker 中运行 OpenWrt 旁路网关(转载记录)
date: '2020-09-03 09:53:43'
updated: '2020-09-03 09:54:42'
tags: [待分类]
permalink: /articles/2020/09/03/1599098023589.html
---
![image.png](https://oss.expoli.tech/img/NWr_image.png)

# 原文地址：https://mlapp.cn/376.html#more

## 镜像介绍

小苏为大家提供的 OpenWrt 镜像所用系统为基于 Lean 大源码编译的 32位/ IPV4 Only 固件，基本功能与之前的自编译固件相同，并且 Docker 镜像将跟随自编译固件的更新而更新。自编译固件的详细介绍请见：

[https://mlapp.cn/369.html](https://mlapp.cn/369.html)

但值得注意的是，Docker 固件没有无线及无线相关功能。在以后的文章中，小苏将给大家分享 OpenWrt 镜像的制作步骤，敬请期待~（Q：喂！你挖的坑还不够多吗？A：咕咕咕！）。

## 步骤开始

成功登陆到树莓派的 SSH 后，在拉取镜像之前，我们还需要进行一些额外的工作：

### 1.打开网卡混杂模式

```
sudo ip link set eth0 promisc on
```

2.创建网络
**(须结合实际网络情况，不能照抄命令)**

```
docker network create -d macvlan --subnet=192.168.123.0/24 --gateway=192.168.123.1 -o parent=eth0 macnet
```

这一条命令需要根据树莓派所处的网络环境来做修改，可以使用 `sudo ifconfig`命令来查看树莓派 eth0 网卡获得的 IP 地址，如果树莓派获得的 IP 地址为 `192.168.2.154`，那么说明树莓派处在 `192.168.2.x`网段，相应的，命令中的`192.168.123.0`和`192.168.123.1`需要被替换成 `192.168.2.0`和`192.168.2.1`：

```
docker network create -d macvlan --subnet=192.168.2.0/24 --gateway=192.168.2.1 -o parent=eth0 macnet
```

此时，我们使用 `docker network ls`命令可以看到网络`macnet`已建立成功：

```
$ docker network ls
NETWORK ID          NAME                DRIVER              SCOPE
10e676133746        bridge              bridge              local
f5308b94e8fa        host                host                local
16745ea66852        macnet              macvlan             local
5e72e41ea02a        none                null                local
```

### 3.拉取镜像

若身处国内，为提高拉取速度，请拉取阿里云仓库中的镜像：

```
docker pull registry.cn-shanghai.aliyuncs.com/suling/openwrt:latest
```

同时小苏也提供存放在 [Docker 官方仓库](https://hub.docker.com/r/sulinggg/openwrt) 中的镜像：

```
docker pull sulinggg/openwrt:latest
```

镜像拉取完成后，我们可以执行`docker images`命令查看现存镜像：

```
$ docker images
REPOSITORY                                              TAG                 IMAGE ID            CREATED             SIZE
registry.cn-shanghai.aliyuncs.com/suling/openwrt        latest              4f4bc5dca2d9        3 hours ago         112MB
```

可见，镜像已成功拉取到本地。

### 4.创建并启动容器

```
docker run --restart always --name openwrt -d --network macnet --privileged registry.cn-shanghai.aliyuncs.com/suling/openwrt:latest /sbin/init
```

其中：

`--restart always`参数表示容器退出时始终重启，使服务尽量保持始终可用；

`--name openwrt`参数定义了容器的名称；

`-d`参数定义使容器运行在 Daemon 模式；

`--network macnet`参数定义将容器加入 `maxnet`网络；

`--privileged<span> </span>`参数定义容器运行在特权模式下；

`registry.cn-shanghai.aliyuncs.com/suling/openwrt:latest`为 Docker 镜像名，因容器托管在阿里云 Docker 镜像仓库内，所以在镜像名中含有阿里云仓库信息；

`/sbin/init`定义容器启动后执行的命令。

启动容器后，我们可以使用 `docker ps -a`命令查看当前运行的容器：

```
$ docker ps -a
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
a26cee7cade6        openwrt:latest      "/sbin/init"        3 hours ago         Up 3 hours                              openwrt
```

若容器运行信息`STATUS`列为 `UP`状态，则说明容器运行正常。

### 5.进入容器并修改相关参数

**(须结合实际网络情况，不能照抄配置)**

```
docker exec -it openwrt bash
```

其中：

`openwrt`为容器名称；

`bash`为进入容器后执行的命令。

执行此命令后我们便进入 OpenWrt 的命令行界面，首先，我们需要编辑 OpenWrt 的网络配置文件：

```
vim /etc/config/network
```

我们需要更改 Lan 口设置：

```
config interface 'lan'
        option type 'bridge'
        option ifname 'eth0'
        option proto 'static'
        option ipaddr '192.168.123.100'
        option netmask '255.255.255.0'
        option ip6assign '60'
        option gateway '192.168.123.1'
        option broadcast '192.168.123.255'
        option dns '192.168.123.1'
```

其中：

所有的 `192.168.123.x` 需要根据树莓派所处网段修改，`option gateway`和`option dns`填写路由器的 IP，若树莓派获得的 IP 为 `192.168.2.154`，路由器 IP 为`192.168.2.1`，则需要这样修改：

```
config interface 'lan'
        option type 'bridge'
        option ifname 'eth0'
        option proto 'static'
        option ipaddr '192.168.2.100'
        option netmask '255.255.255.0'
        option ip6assign '60'
        option gateway '192.168.2.1'
        option broadcast '192.168.2.255'
        option dns '192.168.2.1'
```

`option ipaddr<span> </span>`项目定义了 OpenWrt 的 IP 地址，在完成网段设置后，IP最后一段可根据自己的爱好修改（前提是符合规则且不和现有已分配 IP 冲突）。

### 6.重启网络

```
/etc/init.d/network restart
```

### 7.进入控制面板

在浏览器中输入第 5 步`option ipaddr<span> </span>`项目中的 IP 进入 Luci 控制面板，若`option ipaddr<span> </span>`的参数为 `192.168.123.100`，则可以在浏览器输入 `http://192.168.123.100`进入控制面板。

用户名：`root`

密码：`password`

### 8.关闭 DHCP 服务

在 “网络 - 接口 - Lan - 修改” 界面中，勾选下方的 “**忽略此接口（不在此接口提供 DHCP 服务）**”，并“**保存&应用**”。

![关闭 “DHCP 服务”](https://file.mlapp.cn/usr/uploads/2019/10/1570370001979.png)

### 9.主路由 DHCP 设置

进入路由器后台中，将主路由的 DHCP 的默认网关和 DNS 服务器设置为第 5 步中`option ipaddr<span> </span>`项目中的 IP。

![主路由 DHCP 设置](https://file.mlapp.cn/usr/uploads/2019/10/1570370097838.png)

### 10.重新连接路由器

完成以上操作后，断开设备（如手机，电脑）与路由器的连接，重新连接路由器，连接路由器的设备将获取到我们设置到的 IP。

