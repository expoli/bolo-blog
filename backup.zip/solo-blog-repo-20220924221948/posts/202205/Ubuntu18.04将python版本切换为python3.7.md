title: Ubuntu 18.04 将python 版本切换为 python3.7
date: '2022-05-30 21:28:22'
updated: '2022-05-30 21:29:07'
tags: [Ubuntu, Linux]
permalink: /articles/2022/05/30/1653917302720.html
---
![tutorials24x7installpython37ubuntu1804banner.jpg](https://oss.expoli.tech/img/UYW_tutorials24x7-install-python-3-7-ubuntu-18-04-banner.jpg)

# 环境准备

## 更新软件源缓存

```bash
apt update
```

## 安装 python3.7

```bash
apt install python3.7 python3-pip -y
```

## 配置

```bash
update-alternatives --install /usr/bin/python3 python3  /usr/bin/python3.7 100
```

```bash
# update-alternatives --query python3                                                                                              [1/1902]Name: python3                                                                                                                                                     Link: /usr/bin/python3
Status: auto
Best: /usr/bin/python3.7
Value: /usr/bin/python3.7

Alternative: /usr/bin/python3.7
Priority: 100
```

```bash
# python3 -V
Python 3.7.5
```

## 更新 pip

```bash
pip3 install --upgrade setuptools
python3 -m pip install --upgrade pip
```

## 安装自己的依赖

```bash
pip3 install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt
```
