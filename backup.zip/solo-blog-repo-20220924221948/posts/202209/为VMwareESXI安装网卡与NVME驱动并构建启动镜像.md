title: 为 VMware ESXI 安装网卡与NVME驱动并构建启动镜像
date: '2022-09-06 20:32:31'
updated: '2022-09-06 20:32:31'
tags: [VMware, 驱动, 网卡, NVME]
permalink: /articles/2022/09/06/1662467551372.html
---
![vsphere7.webp](https://oss.expoli.tech/img/lt7_vsphere-7.webp)

# 无网卡驱动无法完成系统安装

今天在给软路由安装 VMware ESXI 7.X 的时候，发现无法正常安装，同时给出了如下图所示的提示。（提示标题很醒目的给出了具体原因即：**找不到网络接口卡** ，这时我看看着软路由上那 4 个2.5G 电口陷入了沉思）我的设备的网卡型号是 `Intel i225` ，经查询发现官方镜像没有包含此网卡驱动，我们需要手动安装相应的社区驱动。

![6v315v91vnz51.webp](https://oss.expoli.tech/img/zAx_6v315v91vnz51.webp)

# 否决 `esxcli` 解决方案

经搜索发现大部分中文教程都是千篇一律，给出不符合我当前使用状态的解决方案即：使用 SSH 方式连接到已经启动 ESXI 设备上，使用官方工具 `esxcli` 完成驱动的安装，而我们现在甚至都无法安装操作系统，更别说启动 SSH 连接接口，进行远程操作了。。

# 从源头上解决问题——构建自定义镜像

联想到 Windows 操作系统安装的过程，如果我们没有相应设备的驱动，我们可以在启动安装进程之前，将所需要的各种驱动打包到安装镜像中，这样即可解决驱动缺失的问题，经搜索发现拥有相应的解决方案，在这里做个简单的总结，同时也给其他兄弟们一个参考。

## 兵马未动、粮草先行——开始前的准备工作

### 第一步——获取 ESXI 镜像离线构建包

VMware 考虑到 IO 设备的多样性，所以也提供了可进行自定义镜像构建的工具包，我们可以在 [ESXI 下载界面](https://customerconnect.vmware.com/web/vmware/evalcenter?p=free-esxi7)，登录我们的账户后，看到向下图所示的下载入口：

![image.png](https://oss.expoli.tech/img/ZFF_image.png)

> Tips: 如果点击下载没有反应的话，可以右键检查下载按钮，找出相应的下载地址，直接进行访问即可，具体操作可参照下图。
>
> ![image.png](https://oss.expoli.tech/img/CjP_image.png)
>
> 转到上面的链接后，会给出带认证信息的真正的镜像下载链接，再次如法炮制进行连续进行两次链接跳转即可完成文件下载。
>
> ![image.png](https://oss.expoli.tech/img/sCp_image.png)

文件下载好之后是一个压缩包，无需解压，保存好以供后续使用。

### 第二步——获取所需驱动

VMware 官方社区提供一些 IO 设备驱动，在这里我放出我自己使用的两个驱动即

1. [Community Networking Driver for ESXi](https://flings.vmware.com/community-networking-driver-for-esxi)

   ![image.png](https://oss.expoli.tech/img/bkt_image.png)
2. [Community NVMe Driver for ESXi](https://flings.vmware.com/community-nvme-driver-for-esxi)

   ![image.png](https://oss.expoli.tech/img/6rO_image.png)

虽然在这里我只给出了两个常用的驱动程序，不过其它设备的驱动程序安装过程也大同小异，我们将这两个驱动程序（压缩包格式、无需解压）下载好保存备用。

### 第三步——获取官方工具（VMware.PowerCLI）

此工具是一个 Powershell 模块，我们需要在管理员模式下启动 Powershell 运行以下命令完成安装，安装过程中可能会出现一些交互性提示，**选是即可**，等待安装完成。

```powershell
Install-Module -Name VMware.PowerCLI
```

![image.png](https://oss.expoli.tech/img/49X_image.png)

### 第四步——获取镜像构建脚本

为了简化自定义镜像构建的操作步骤，Github 上有大佬做好了相应的自动化脚本，项目地址：

[https://github.com/VFrontDe/ESXi-Customizer-PS](https://github.com/VFrontDe/ESXi-Customizer-PS) ，将其下载备用。

![image.png](https://oss.expoli.tech/img/uZT_image.png)

至此，准备工作已经完成，可以开始进行自定义镜像的构建操作了。

## 万事俱备只欠东风——开始构建自定义镜像

### 第一步——整理文件

将 `ESXi-Customizer-PS-master` 解压，将其他文件按如下文件结构进行存放。

![image.png](https://oss.expoli.tech/img/d98_image.png)

### 第二步——开始镜像构建

在上述文件夹中打开 Powershell ，运行以下命令：

```powershell
.\ESXi-Customizer-PS.ps1 -izip .\VMware-ESXi-7.0U3g-20328353-depot.zip -pkgDir .\pkg\
```

如果出现如下因脚本无数字签名无法运行的提示，可运行如下命令，临时允许运行：

> 此命令的详细解释参见：[https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies?view=powershell-7.2](https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies?view=powershell-7.2)

```powershell
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope CurrentUser
```

![image.png](https://oss.expoli.tech/img/uSL_image.png)

再次运行构建命令，根据提示运行运行即可（即**R**）：

![image.png](https://oss.expoli.tech/img/6Bz_image.png)

然后就是等待完成即可，整个过程大约需要3-4分钟，耐心等待即可，如果成功，你的输出应该类似如下：

![image.png](https://oss.expoli.tech/img/eTb_image.png)

此处就是我们所需要的自定义镜像，将它拷贝到自己的 [Ventoy](https://github.com/ventoy/Ventoy) 启动盘即可，正常使用。

![image.png](https://oss.expoli.tech/img/hps_image.png)
