title: 挂载使用LUKS加密的磁盘(使用  btrfs 文件系统)
date: '2022-09-24 15:20:11'
updated: '2022-09-24 15:20:44'
tags: [linux, btrfs, luks]
permalink: /articles/2022/09/24/1664004011806.html
---
![diskencryption.jpg](https://oss.expoli.tech/img/wnz_disk_encryption.jpg)

# 关于luks加密

LUKS (Linux Unified Key Setup) 为Linux硬盘分区加密提供了一种标准，它不仅能通用于不同的 Linux 发行版本，还支持多用户/口令。因为它的加密密钥独立于口令，所以如果口令失密，我们可以迅速改变口令而无需重新加密整个硬盘。通过提供一个标准的磁盘格式，提供了多个用户密码的安全管理。

# 加密磁盘的挂载

必须首先对加密的卷进行解密,才能挂载其中的文件系统。文件系统在加密层之上，当加密层打开之前，磁盘里的内容就看不到，因为设备还没有解密。

crypsetup工具加密的特点：
（1）加密后不能直接挂载
（2）加密后硬盘丢失也不用担心数据被盗
（3）加密后必须做映射才能挂载

## 挂载加密磁盘

```shell
[root@server ~]# cryptsetup open /dev/vdb5 lala # 打开，也就是解密，lala为虚拟设备
Enter passphrase for /dev/vdb5:
[root@server ~]# ll /dev/mapper/ # 当解密成功时，会发现在这个目录下生成虚拟设备
```

## btrfs 文件系统挂载命令

```shell
mount /dev/mapper/lala -o subvol=@ /mnt # 挂载虚拟设备,btrfs 的@子卷
mount /dev/mapper/lala -o subvol=@home /mnt/home # 挂载虚拟设备就，btrfs 的@home子卷
mount /dev/mapper/lala -o subvol=@var /mnt
```
