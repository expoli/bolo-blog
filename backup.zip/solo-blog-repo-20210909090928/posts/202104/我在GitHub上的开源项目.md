title: 我在 GitHub 上的开源项目
date: '2021-04-02 16:36:19'
updated: '2021-04-02 16:36:19'
tags: [开源, GitHub]
permalink: /github
---
![GitHub Repo](https://expoli.tech/images/github_repo.jpg)

### 1. [docker-compose-files](https://github.com/expoli/docker-compose-files) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[⭐️`10`](https://github.com/expoli/docker-compose-files/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/expoli/docker-compose-files/network/members "分叉数")</span>





---

### 2. [docker-hub-image-php](https://github.com/expoli/docker-hub-image-php) <kbd title="主要编程语言">Dockerfile</kbd> <span style="font-size: 12px;">[⭐️`2`](https://github.com/expoli/docker-hub-image-php/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/expoli/docker-hub-image-php/network/members "分叉数")</span>

Self-compiled php mirror Basic mirror: php:7.2-fpm adds some basic PHP components such as gd \ mysqli \ pdo \ pdo_mysql \ zip



---

### 3. [DrawLotsNew](https://github.com/expoli/DrawLotsNew) <kbd title="主要编程语言">Kotlin</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/expoli/DrawLotsNew/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/DrawLotsNew/network/members "分叉数")</span>

DrawLotsNew 基于 DrawLots mirai 插件进行开发



---

### 4. [Learn-OpenCV-4-By-Building-Projects-Second-Edition](https://github.com/expoli/Learn-OpenCV-4-By-Building-Projects-Second-Edition) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[⭐️`1`](https://github.com/expoli/Learn-OpenCV-4-By-Building-Projects-Second-Edition/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Learn-OpenCV-4-By-Building-Projects-Second-Edition/network/members "分叉数")</span>

Learn OpenCV 4 By Building Projects, Second Edition, published by Packt



---

### 5. [bolo-blog](https://github.com/expoli/bolo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/bolo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/bolo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://expoli.tech`](https://expoli.tech "项目主页")</span>

✍️ 糖醋鱼的小破站 - 🐠生成长记



---

### 6. [bolo-docker-image-builder](https://github.com/expoli/bolo-docker-image-builder) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/bolo-docker-image-builder/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/bolo-docker-image-builder/network/members "分叉数")</span>

bolo-docker builder



---

### 7. [bolo-solo](https://github.com/expoli/bolo-solo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/bolo-solo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/bolo-solo/network/members "分叉数")&nbsp;&nbsp;[🏠`https://demo.stackoverflow.wiki`](https://demo.stackoverflow.wiki "项目主页")</span>

🍍 Bolo 菠萝博客 专为程序员设计的精致 Java 博客系统 | 🎸基于Solo深度定制 | 免登录评论 | 动态邮件/Server酱微信提醒 | 自定义图床 | 一键隐藏交互式模块，备案必备 | ✨精致主题持续更新 | 备份一键导出导入 | 内置防火墙 | 评论过滤 | 独立分类 | 文章同步/备份到链滴 | 离线博客 | ✅安装太轻松！WAR包、Tomcat、Docker、JAR部署支持 | 🚚支持从Solo轻松迁移



---

### 8. [clash-docker-image-builder](https://github.com/expoli/clash-docker-image-builder) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/clash-docker-image-builder/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/clash-docker-image-builder/network/members "分叉数")</span>





---

### 9. [cloudreve-docker](https://github.com/expoli/cloudreve-docker) <kbd title="主要编程语言">Dockerfile</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/cloudreve-docker/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/cloudreve-docker/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hub.docker.com/r/xavierniu/cloudreve`](https://hub.docker.com/r/xavierniu/cloudreve "项目主页")</span>

Source Code of Docker image for Cloudreve V3



---

### 10. [Data-Structure-Learn](https://github.com/expoli/Data-Structure-Learn) <kbd title="主要编程语言">C++</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/Data-Structure-Learn/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Data-Structure-Learn/network/members "分叉数")</span>

Data-Structure-Learn



---

### 11. [Deep_Learning_For_Computer_Vision_With_Python](https://github.com/expoli/Deep_Learning_For_Computer_Vision_With_Python) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/Deep_Learning_For_Computer_Vision_With_Python/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Deep_Learning_For_Computer_Vision_With_Python/network/members "分叉数")</span>

Deep Learning For Computer Vision With Python



---

### 12. [dnscrypt-server-docker-image-builder](https://github.com/expoli/dnscrypt-server-docker-image-builder) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/dnscrypt-server-docker-image-builder/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/dnscrypt-server-docker-image-builder/network/members "分叉数")</span>

dnscrypt-server docker image build repository, support arm



---

### 13. [dnsmasq-server](https://github.com/expoli/dnsmasq-server) <kbd title="主要编程语言">Dockerfile</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/dnsmasq-server/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/dnsmasq-server/network/members "分叉数")</span>

dnsmasq server docker image



---

### 14. [docker-base-ubuntu](https://github.com/expoli/docker-base-ubuntu) <kbd title="主要编程语言">Dockerfile</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/docker-base-ubuntu/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/docker-base-ubuntu/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hub.docker.com/r/tozd/base/`](https://hub.docker.com/r/tozd/base/ "项目主页")</span>

Base Docker image.



---

### 15. [Docker-install-menu-bash](https://github.com/expoli/Docker-install-menu-bash) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/Docker-install-menu-bash/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Docker-install-menu-bash/network/members "分叉数")</span>

Docker install menu bash can run in centos, ubuntu and debian



---

### 16. [docker-nfs-server](https://github.com/expoli/docker-nfs-server) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/docker-nfs-server/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/docker-nfs-server/network/members "分叉数")&nbsp;&nbsp;[🏠`https://hub.docker.com/r/erichough/nfs-server/`](https://hub.docker.com/r/erichough/nfs-server/ "项目主页")</span>

A lightweight, robust, flexible, and containerized NFS server.



---

### 17. [Dockerfile](https://github.com/expoli/Dockerfile) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/Dockerfile/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Dockerfile/network/members "分叉数")</span>

Jumpserver all in one Dockerfile



---

### 18. [dotfiles](https://github.com/expoli/dotfiles) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/dotfiles/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/dotfiles/network/members "分叉数")</span>





---

### 19. [Electronic-system-practice](https://github.com/expoli/Electronic-system-practice) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/Electronic-system-practice/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Electronic-system-practice/network/members "分叉数")</span>

Electronic system practice 郑州大学电子系统设计实践



---

### 20. [expoli](https://github.com/expoli/expoli) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/expoli/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/expoli/network/members "分叉数")</span>





---

### 21. [Fire-Detection-Image-Dataset](https://github.com/expoli/Fire-Detection-Image-Dataset) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/Fire-Detection-Image-Dataset/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Fire-Detection-Image-Dataset/network/members "分叉数")</span>

This dataset contains normal images and images with fire. It is highly unbalanced to reciprocate real world situations. It consists of a variety of scenarios and different fire situations (intensity, luminosity, size, environment etc).



---

### 22. [FireNet-LightWeight-Network-for-Fire-Detection](https://github.com/expoli/FireNet-LightWeight-Network-for-Fire-Detection) <kbd title="主要编程语言">Jupyter Notebook</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/FireNet-LightWeight-Network-for-Fire-Detection/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/expoli/FireNet-LightWeight-Network-for-Fire-Detection/network/members "分叉数")</span>





---

### 23. [kindle-weather-dashboard](https://github.com/expoli/kindle-weather-dashboard) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/kindle-weather-dashboard/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/kindle-weather-dashboard/network/members "分叉数")</span>





---

### 24. [Learn-tensorflow](https://github.com/expoli/Learn-tensorflow) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/Learn-tensorflow/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Learn-tensorflow/network/members "分叉数")</span>

https://www.tensorflow.org/



---

### 25. [loveyue](https://github.com/expoli/loveyue) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/loveyue/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/loveyue/network/members "分叉数")</span>

loveyue系列1到8的源码



---

### 26. [luci-app-shadowsocksr](https://github.com/expoli/luci-app-shadowsocksr) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/luci-app-shadowsocksr/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/luci-app-shadowsocksr/network/members "分叉数")</span>

OpenWrt/LEDE LuCI for ShadowsocksR-libev



---

### 27. [Machine-learning-in-action](https://github.com/expoli/Machine-learning-in-action) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/Machine-learning-in-action/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/Machine-learning-in-action/network/members "分叉数")&nbsp;&nbsp;[🏠`manning.com/pharrington`](manning.com/pharrington "项目主页")</span>

Source Code for the book: Machine Learning in Action published by Manning



---

### 28. [mipay-extract-gitlab-ci](https://github.com/expoli/mipay-extract-gitlab-ci) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/mipay-extract-gitlab-ci/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/mipay-extract-gitlab-ci/network/members "分叉数")</span>

mipay-extract-gitlab-ci



---

### 29. [mipay-extracter-centos](https://github.com/expoli/mipay-extracter-centos) <kbd title="主要编程语言">Dockerfile</kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/mipay-extracter-centos/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/mipay-extracter-centos/network/members "分叉数")</span>

mipay-extracter-centos



---

### 30. [mirai-plugin-keywords](https://github.com/expoli/mirai-plugin-keywords) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[⭐️`0`](https://github.com/expoli/mirai-plugin-keywords/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/expoli/mirai-plugin-keywords/network/members "分叉数")</span>

my mirai plugin

