title: crunch 字典生成与 John ZIP爆破
date: '2021-07-12 18:25:42'
updated: '2021-07-12 18:55:44'
tags: [CTF, ZIP]
permalink: /articles/2021/07/12/1626085541971.html
---
![ZIPPasswordCracker.png](https://oss.expoli.tech/img/IKg_ZIP-Password-Cracker.png)

选手训练营地址：https://www.ichunqiu.com/battalion

# 题目分析

1. 题目简介如下（爱春秋-选手训练营-Misc-小可爱）

![image.png](https://oss.expoli.tech/img/goh_image.png)

- 题目中的图片如下

![wang.4409F5F40438B0C7C4C4E2D9C1883CA4.jpg](https://oss.expoli.tech/img/znk_wang.4409F5F40438B0C7C4C4E2D9C1883CA4.jpg)

# 题目分析

## 文件分析

因为没有其它的附件内容，只有一个密码提示，猜测此图片应该是一个合成文件

- binwalk 查看内容

可以看到图片文件里面装入了一个ZIP文件，使用 `-e` 参数对文件进行提取

```log
┌──(kali㉿kali)-[~/Desktop]
└─$ binwalk ./wang.4409F5F40438B0C7C4C4E2D9C1883CA4.jpg 

DECIMAL       HEXADECIMAL     DESCRIPTION
--------------------------------------------------------------------------------
0             0x0             JPEG image data, JFIF standard 1.01
30            0x1E            TIFF image data, big-endian, offset of first image directory: 8
246614        0x3C356         Zip archive data, encrypted at least v2.0 to extract, compressed size: 671454, uncompressed size: 671942, name: qr.png
918374        0xE0366         End of Zip archive, footer length: 22

                                                                       
┌──(kali㉿kali)-[~/Desktop]
└─$ binwalk -e ./wang.4409F5F40438B0C7C4C4E2D9C1883CA4.jpg 
```

- 查看ZIP文件内容

看到提示显示密码为八位数字，所以现在需要对ZIP进行密码爆破

```log
┌──(kali㉿kali)-[~/Desktop/_wang.4409F5F40438B0C7C4C4E2D9C1883CA4.jpg.extracted]
└─$ tree                                                                                                                                                                                       127 ⨯
.
├── 3C356.zip
├── qr.png
└── 密码为八位数字.txt
```

## ZIP 爆破

1. 使用 `john` 生成密码 `hash`

```log
zip2john 3C356.zip > pass.txt
```

2. 生成密码字典

```log
crunch 8 8 -t %%%%%%%% -o eight.number.wordlist 
```

3. 使用数字字典对ZIP进行爆破

- 得到密码 `34878956`

```log
┌──(kali㉿kali)-[~/Desktop/_wang.4409F5F40438B0C7C4C4E2D9C1883CA4.jpg.extracted]
└─$ john --wordlist=eight.number.wordlist  pass.txt                                                                                                                                              1 ⨯
Using default input encoding: UTF-8
Loaded 1 password hash (PKZIP [32/64])
Press 'q' or Ctrl-C to abort, almost any other key for status
34878956         (3C356.zip)
1g 0:00:00:10 DONE (2021-07-12 06:01) 0.09337g/s 3256Kp/s 3256Kc/s 3256KC/s 34878912..34878975
Use the "--show" option to display all of the cracked passwords reliably
Session completed
```

4. 解压得到二维码（我去你大爷的）这10分不要也罢

- 查看别人的题解得出 `flag{e7df63cb-2786-4c2c-99f9-faeee4354359}`

![qr.png](https://oss.expoli.tech/img/7yj_qr.png)
