title: 免sudo使用docker命令
date: '2019-07-27 13:46:08'
updated: '2020-03-14 21:01:34'
tags: [Docker]
permalink: /articles/2019/07/27/1564656218673.html
---
# 免sudo使用docker命令

date: 2019-07-27

## 背景

相信大家在一台新机器上面安装 docker 时候、都会发现docker 在安装完成之后、如果你想直接使用使用 docker 命令来运行docker 相关的操作、会爆出类似于下面的错误。

```bash
Got permission denied while trying to connect to the Docker daemon socket at unix:///var/run/docker.sock: Get http://%2Fvar%2Frun%2Fdocker.sock/v1.26/images/json: dial unix /var/run/docker.sock: connect: permission denied
```

报错显示权限不够、那么如何解决这个问题呢？

官方文档给出了解决方案，那就是将你添加到 `docker` 这个用户组里面即可。

- 如果还没有 docker group 就添加一个：

```bash
sudo groupadd docker
```

- 将相应的用户加入该 `group` 内。然后退出并重新登录就生效啦。

```bash
sudo gpasswd -a ${USER} docker
```

- 重启 docker 服务
```bash
# centos6
sudo service docker restart
# centos7
sudo systemctl restart docker
```

- 切换当前会话到新 group 或者重启 X 会话

```bash
newgrp docker
```

现在配置就完成了
