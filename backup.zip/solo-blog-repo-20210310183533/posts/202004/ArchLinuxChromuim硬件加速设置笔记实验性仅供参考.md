title: Arch Linux Chromuim 硬件加速设置笔记（实验性，仅供参考）
date: '2020-04-26 11:35:50'
updated: '2020-04-26 11:36:27'
tags: [Arch, NVIDIA]
permalink: /articles/2020/01/08/1587871894897.html
---
![](https://img.hacpai.com/bing/20180111.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Arch Linux Chrome 硬件加速设置笔记（实验性）

最近在使用 Arch Linux 上使用 chromium 观看视频的时候，因为默认没有启用硬件加速，所以那个难受啊，在这里做个笔记（**不保证适用性，仅供参考**）。

在这里因为我的笔记本基本上都是插着电源的，所以就是**完全使用了 N 卡**。

## 0. 禁用 nouveau 驱动

```
sudo pacman -Rs xf86-video-nouveau
```

## 安装 nvidia 驱动

官方 wiki：[https://wiki.archlinux.org/index.php/NVIDIA](https://wiki.archlinux.org/index.php/NVIDIA)

```
sudo pacman -S nvidia nvidia-utils opencl-nvidia nvidia-settings opencl-nvidia
```

### 创建 pacman hook

```
sudo vim /etc/pacman.d/hooks/nvidia.hook
```

填入下面的文本，保存，保证在 nvidia 驱动更新的时候，同步更新内核内存盘。

```
[Trigger]
Operation=Install
Operation=Upgrade
Operation=Remove
Type=Package
Target=nvidia
Target=linux
# Change the linux part above and in the Exec line if a different kernel is used

[Action]
Description=Update Nvidia module in initcpio
Depends=mkinitcpio
When=PostTransaction
NeedsTargets
Exec=/bin/sh -c 'while read -r trg; do case $trg in linux) exit 0; esac; done; /usr/bin/mkinitcpio -P'
```

### 启用 DRM kernel mode

```
vim /etc/default/grub
```

找到这一行、添加 `nvidia-drm.modeset=1`，保存退出。

```
GRUB_CMDLINE_LINUX_DEFAULT=" * nvidia-drm.modeset=1 * "
```

重新生成 grub 启动文件

```
sudo grub-mkconfig -o /boot/grub/grub.cfg
```

### 查看安装状态

```
nvidia-smi
```

输出类似如下基本上驱动就安装完毕了。

```
Sun Apr 26 11:20:52 2020       
+-----------------------------------------------------------------------------+
| NVIDIA-SMI 440.82       Driver Version: 440.82       CUDA Version: 10.2     |
|-------------------------------+----------------------+----------------------+
| GPU  Name        Persistence-M| Bus-Id        Disp.A | Volatile Uncorr. ECC |
| Fan  Temp  Perf  Pwr:Usage/Cap|         Memory-Usage | GPU-Util  Compute M. |
|===============================+======================+======================|
|   0  GeForce GTX 950M    Off  | 00000000:01:00.0 Off |                  N/A |
| N/A   44C    P5    N/A /  N/A |    448MiB /  2004MiB |     22%      Default |
+-------------------------------+----------------------+----------------------+
                                                                               
+-----------------------------------------------------------------------------+
| Processes:                                                       GPU Memory |
|  GPU       PID   Type   Process name                             Usage      |
|=============================================================================|
|    0       524      G   /usr/lib/Xorg                                152MiB |
|    0      1278      G   /usr/bin/kwin_x11                             49MiB |
|    0      1298      G   /usr/bin/plasmashell                          23MiB |
|    0      1408      G   /usr/bin/ksysguard                             1MiB |
|    0      1472      G   /usr/bin/akonadi_archivemail_agent             1MiB |
|    0      1486      G   /usr/bin/akonadi_mailfilter_agent              1MiB |
|    0      1498      G   /usr/bin/akonadi_sendlater_agent               1MiB |
|    0      1502      G   /usr/bin/akonadi_unifiedmailbox_agent          1MiB |
|    0      1774      G   /usr/bin/krunner                              12MiB |
|    0      2875      G   ...AAAAAAAAAAAACAAAAAAAAAA= --shared-files   160MiB |
|    0      8294      G   ...quest-channel-token=4155290172367049800    28MiB |
+-----------------------------------------------------------------------------+
```

## 安装 VDPAU

```
sudo pacman -S libva-vdpau-driver mesa-vdpau libvdpau vdpauinfo lib32-libvdpau
```

### 查看安装状态

```
vainfo 
              
vainfo: VA-API version: 1.7 (libva 2.7.1)
vainfo: Driver version: Splitted-Desktop Systems VDPAU backend for VA-API - 0.7.4
vainfo: Supported profile and entrypoints
      VAProfileMPEG2Simple            : VAEntrypointVLD
      VAProfileMPEG2Main              : VAEntrypointVLD
      VAProfileMPEG4Simple            : VAEntrypointVLD
      VAProfileMPEG4AdvancedSimple    : VAEntrypointVLD
      <unknown profile>               : VAEntrypointVLD
      VAProfileH264Main               : VAEntrypointVLD
      VAProfileH264High               : VAEntrypointVLD
      VAProfileVC1Simple              : VAEntrypointVLD
      VAProfileVC1Main                : VAEntrypointVLD
      VAProfileVC1Advanced            : VAEntrypointVLD
```

## 安装 chromuim

```
sudo pacman -S chromuim
```

### 设置 chromuim 以使用硬件加速

```
vim  ~/.config/chromium-flags.conf
```

可以根据需要添加其它的启动参数。

```
--ignore-gpu-blacklist
--enable-gpu-rasterization
--enable-native-gpu-memory-buffers
--enable-zero-copy
# --disable-gpu-driver-bug-workarounds

```

### 查看加速效果

打开 [chrome://gpu](chrome://gpu/) 可以看到如下图的类似效果。而且在观看视频的时候，GPU有着负载占用。

![](https://oss.expoli.tech/img/20200426112611.png)

使用下方命令，实时参看GPU负载。并观察此时CPU的占用是否降低。

```
watch -n 1 nvidia-smi
```


![](https://oss.expoli.tech/img/20200426112934.png)
