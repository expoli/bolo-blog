title: A Quick Guide to Using the MySQL Yum Repository
date: '2019-07-27 20:47:08'
updated: '2019-07-27 20:47:08'
tags: [Centos, Mysql, yum]
permalink: /articles/2019/07/27/1564656222094.html
---
# A Quick Guide to Using the MySQL Yum Repository

- date:2019-07-27 11:31


官方指导文档:[https://dev.mysql.com/doc/mysql-yum-repo-quick-guide/en/](https://dev.mysql.com/doc/mysql-yum-repo-quick-guide/en/)

## 第一步：添加 MySql Tum 仓库源

### 1. 下载相应的 `MySQL Yum Repository` 文件

下载链接:[https://dev.mysql.com/downloads/repo/yum/](https://dev.mysql.com/downloads/repo/yum/)

**需注册登录**

### 2. 安装相应的 `MySQL Yum Repository`

```bash
shell> sudo rpm -Uvh platform-and-version-specific-package-name.rpm
# shell> sudo rpm -Uvh mysql80-community-release-el6-n.noarch.rpm
```

### 3. 选择发布系列

使用MySQL Yum存储库时，默认选择安装MySQL的最新GA版本。

在MySQL Yum存储库（https://repo.mysql.com/yum/）中，MySQL社区服务器的不同发行版系列托管在不同的子存储库中。默认情况下启用最新GA系列（当前为MySQL 8.0）的子存储库，默认情况下禁用所有其他系列（例如，MySQL 5.7系列）的子存储库。使用此命令查看MySQL Yum存储库中的所有子存储库，并查看哪些子存储库已启用或禁用。

```bash
shell> yum repolist all | grep mysql
```

要从最新的GA系列安装最新版本，无需进行任何配置。要从最新GA系列以外的特定系列安装最新版本，可以使用 `yum-config-manager或dnf config-manager命令` 禁用最新GA系列的子存储库并启用特定系列的子存储库。

下面的命令将禁用8.0系列的子存储库并启用5.7系列的子存储库。

```bash
shell> sudo yum-config-manager --disable mysql80-community
shell> sudo yum-config-manager --enable mysql57-community
```

除了使用 `yum-config-manager或dnf config-manager` 命令外，您还可以通过手动编辑 `/etc/yum.repos.d/mysql-community.repo` 文件来选择系列。这是文件中发布系列的子存储库的典型条目：

```bash
[mysql80-community]
name=MySQL 8.0 Community Server
baseurl=http://repo.mysql.com/yum/mysql-8.0-community/el/6/$basearch/
enabled=1
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-mysql

# Enable to use MySQL 5.7
[mysql57-community]
name=MySQL 5.7 Community Server
baseurl=http://repo.mysql.com/yum/mysql-5.7-community/el/6/$basearch/
enabled=1
gpgcheck=1
gpgkey=file:///etc/pki/rpm-gpg/RPM-GPG-KEY-mysql
```

**注意**：**在任何时候应该只启用一个发布系列子存储库**。**当启用多个版本系列的子存储库时**，**Yum将使用最新的系列**。

通过运行以下命令并检查其输出来验证是否已启用和禁用了正确的子存储库

```bash
shell> yum repolist enabled | grep mysql
```

### 4. 开始安装MySQL

```
shell> sudo yum install mysql-community-server
```

### 5. 启动 MySQL Server

```bash
# centos6
shell> sudo service mysqld start
shell> sudo service mysqld status
# centos7
shell> sudo systemctl start mysqld.service
shell> sudo systemctl status mysqld.service
```