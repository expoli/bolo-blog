title: Linux 强制 gnome 使用 wayland 通信协议
date: '2022-07-04 08:11:39'
updated: '2022-07-04 08:13:00'
tags: [Linux]
permalink: /articles/2022/07/04/1656893499729.html
---
![webpcpassthru.webp](https://oss.expoli.tech/img/sRQ_webpc-passthru.webp)

最近将桌面环境换成了 gnome ，使用了一段时间感觉还不错，不过不知道是我使用的系统 [EndeavourOS ](https://endeavouros.com/) 原因（我觉得这个可能性比较大），还是其他的原因，导致我在登陆界面无法更换桌面服务器所使用的协议，（即 X11 和 wayland 的切换按钮），从而导致回退到默认的 X11 。由于现在的主流系统都在慢慢地切换到 wayland ，所以研究了一下如何强制使用 wayland 协议。

# 解决方案

只需要添加一个文件即可，只要下面的文件存在，gdm 就会强制使用 wayland 协议（重启生效），如果遇到问题，只需要删除下面的文件即可。

```bash
sudo ln -s /dev/null /etc/udev/rules.d/61-gdm.rules
```

![image.png](https://oss.expoli.tech/img/XUh_image.png)
