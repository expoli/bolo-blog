title: Windows GO 语言 CGO 运行时环境配置
date: '2022-10-18 18:02:01'
updated: '2022-10-18 19:37:48'
tags: [go]
permalink: /articles/2022/10/18/1666087321618.html
---
![1vCF3FN6EqUkJaJ0vL7fzw.png](https://oss.expoli.tech/img/GvG_1_vCF3FN6EqUkJaJ0v-L7fzw.png)

要使用 CGO 特性，需要安装 C/C++ 构建工具链，在 macOS 和 Linux 下是要安装 GCC，在 windows 下是需要安装 MinGW 工具。同时需要保证环境变量 `CGO_ENABLED` 被设置为 1，这表示 CGO 是被启用的状态。在本地构建时 `CGO_ENABLED` 默认是启用的，当交叉构建时 CGO 默认是禁止的。比如要交叉构建 ARM 环境运行的 Go 程序，需要手工设置好 C/C++ 交叉构建的工具链，同时开启 `CGO_ENABLED` 环境变量。然后通过 `import "C"` 语句启用 CGO 特性。如果没有安装对应的 CGO 运行时环境、则在运行的时候会引发如下错误。

```go
exec: “gcc”: executable file not found in %PATH%
```

MinGW，又称mingw32，是将GCC编译器和GNU Binutils移植到Win32平台下的产物，包括一系列头文件、库和可执行文件。 另有可用于产生32位及64位Windows可执行文件的MinGW-w64项目，是从原本MinGW产生的分支。如今已经独立发展。

安装 MingW 有好多种方式、在经历过多次不成功的尝试之后、在这里记录一下使用预编译文件的快捷安装方式。

# 1. 下载预编译文件

打开这个网站 [WinLibs standalone build of GCC and MinGW-w64 for Windows](https://winlibs.com/) 即 https://winlibs.com/ 。

导航至 `MSVCRT runtime` ，选择你需要的版本进行下载。

![image.png](https://oss.expoli.tech/img/PfI_image.png)

# 2. 解压压缩包，修改 PATH 环境变量

将解压后的文件夹路径添加到你的 PATH 环境变量里面，可以是用户级别的、也可以是系统级别的（看你需求）

![image.png](https://oss.expoli.tech/img/GEz_image.png)

# 3. 这个时候就可以进行一些 CGO 特性的编译测试了

就比如下面的🌰、你可以进行编译运行测试、如果不出意外，会正常运行

```go
package main

/*
#include <stdio.h>

void printint(int v) {
    printf("printint: %d\n", v);
}
*/
import "C"

func main() {
    v := 42
    C.printint(C.int(v))
}

```
