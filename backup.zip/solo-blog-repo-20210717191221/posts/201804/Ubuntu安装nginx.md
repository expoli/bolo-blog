title: Ubuntu 安装 nginx
date: '2018-04-16 22:21:39'
updated: '2018-04-16 22:21:39'
tags: [Nginx, Ubuntu]
permalink: /articles/2018/04/16/1564656224516.html
---
![Ubuntu and nginx](https://ws2.sinaimg.cn/large/006tNbRwly1fwbm6k5jtdj30lb0c0t9t.jpg)

## Ubuntu 安装 nginx

<!-- more -->

### 命令操作

```bash
$ sudo apt-get update
$ sudo apt-get upgrade
$ sudo apt-get install nginx
```

**初次安装会自动要求安装一堆的依赖**，**接受并安装即可**。

**Nginx** **会自动安装为服务并开机自启**。

### 安装验证

从浏览器输入自己的公网IP（或者是指向该IP的域名）即可验证是否安装成功。

### 正常情况会看到如下Nginx欢迎页
![image956f44210618f766.png](./18-04-16-Ubuntu-install-nginx/image956f44210618f766.png)

### ok! 安装已经完成、就是这么简单!

跑起来个样例站简单，但配置实际上很有学问可讲，玩法很多。