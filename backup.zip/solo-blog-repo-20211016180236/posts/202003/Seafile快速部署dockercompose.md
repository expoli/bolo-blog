title: Seafile 快速部署（docker-compose）
date: '2020-03-13 12:05:58'
updated: '2020-03-13 12:13:00'
tags: [Seafile, Note]
permalink: /articles/2020/03/13/1584072358245.html
---
![](https://img.hacpai.com/bing/20171205.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# Seafile 部署分享

## Seafile 介绍

Seafile 是一款开源的企业云盘，注重可靠性和性能。支持 Windows, Mac, Linux, iOS, Android 平台。支持文件同步或者直接挂载到本地访问。其官网地址：[https://www.seafile.com/home/](https://www.seafile.com/home/)

说实话、像 Seafile、Nextcloud、可道云这一类的开源云盘系统也都用过好几个、但是说实话都不是那么的称心如意;尤其是 Nextcloud 这性能是真的有点让人着急啊。在踩坑了 Nextloud 那性能着急、容易断线、而且不支持断点续传那些令人牙疼的操作之后、峰回路转遇到了 Seafile，再体验了一番之后、感觉真的很不错而且还支持全平台同步。抛弃可道云的原因是因为、它只可以网页版而且没办法做到自动同步、不过性能也不错、如果考虑简单的文件分享完全够用。

## Seafile 官方部署文档

这是官方部署文档的地址[https://cloud.seafile.com/published/seafile-manual-cn/home.md](https://cloud.seafile.com/published/seafile-manual-cn/home.md)
可以从下图看出、官方提供了多种部署方式、Linux、windows 平台；如果你不想手动部署、那么他们也提供了 Docker 部署方式；因为考虑到后期迁移的便利性、和部署的快速性；在这里我选择了 Docker 部署方式。
![image.png](https://img.hacpai.com/file/2020/03/image-9c7ad469.png)

## 开始部署

Docker 部署官方指导文档：[https://cloud.seafile.com/published/seafile-manual-cn/docker/用Docker部署Seafile.md](https://cloud.seafile.com/published/seafile-manual-cn/docker/%E7%94%A8Docker%E9%83%A8%E7%BD%B2Seafile.md)

官方文档上将每个步骤都写清楚了。

### 1. 安装 docker-compose

因为 Seafile v7.x.x 容器是通过 docker-compose 命令运行的，所以您应该先在服务器上安装该命令。

```
# for CentOS
yum install docker-compose -y﻿

# for Ubuntu 
apt-get install docker-compose -y
```

### 2. 下载并修改 docker-compose.yml

下载 [docker-compose.yml](https://docs.seafile.com/d/cb1d3f97106847abbf31/files/?p=/docker/docker-compose.yml) 示例文件到您的服务器上，然后根据您的实际环境修改该文件。尤其是以下几项配置：

* MySQL root 用户的密码 (MYSQL_ROOT_PASSWORD and DB_ROOT_PASSWD)
* 持久化存储 MySQL 数据的 volumes 目录 (volumes)
* 持久化存储 Seafile 数据的 volumes 目录 (volumes)

---
- 官方 docker-compose.yml 文件

```yaml
version: '2.0'
services:
  db:
    image: mariadb:10.1
    container_name: seafile-mysql
    environment:
      - MYSQL_ROOT_PASSWORD=db_dev  # Requested, set the root's password of MySQL service.
      - MYSQL_LOG_CONSOLE=true
    volumes:
      - /opt/seafile-mysql/db:/var/lib/mysql  # Requested, specifies the path to MySQL data persistent store.
    networks:
      - seafile-net

  memcached:
    image: memcached:1.5.6
    container_name: seafile-memcached
    entrypoint: memcached -m 256
    networks:
      - seafile-net
          
  seafile:
    image: seafileltd/seafile-mc:latest
    container_name: seafile
    ports:
      - "80:80"
#      - "443:443"  # If https is enabled, cancel the comment.
    volumes:
      - /opt/seafile-data:/shared   # Requested, specifies the path to Seafile data persistent store.
    environment:
      - DB_HOST=db
      - DB_ROOT_PASSWD=db_dev  # Requested, the value shuold be root's password of MySQL service.
#      - TIME_ZONE=Asia/Shanghai # Optional, default is UTC. Should be uncomment and set to your local time zone.
      - SEAFILE_ADMIN_EMAIL=me@example.com # Specifies Seafile admin user, default is 'me@example.com'.
      - SEAFILE_ADMIN_PASSWORD=asecret     # Specifies Seafile admin password, default is 'asecret'.
      - SEAFILE_SERVER_LETSENCRYPT=false   # Whether use letsencrypt to generate cert.
      - SEAFILE_SERVER_HOSTNAME=seafile.example.com # Specifies your host name.
    depends_on:
      - db
      - memcached
    networks:
      - seafile-net

networks:
  seafile-net:
```

---
根据观察不难发现：官方的 docker-compose.yaml 只是给予了一个大致的框架、当然你可以直接跳过修改直接进行运行，不过我建议还是根据自己的需要进行适当的修改，比如更改一个更加有效的密码；比如加上 restart: always 保证容器开机随着 Docker service 自行启动。

---
修改后的文件如下，我们修改了数据文件的储存路径、由原来的/opt 目录转移到现在的跟 docker-compose 的同级目录、当然你也可以选择其它你喜欢的路径。

```yaml
version: '2.0'
services:
  db:
    image: mariadb:10.1
    container_name: seafile-mysql
    restart: always
    environment:
      - MYSQL_ROOT_PASSWORD=db_dev  # Requested, set the root's password of MySQL service.
      - MYSQL_LOG_CONSOLE=true
    volumes:
      - ./seafile-mysql/db:/var/lib/mysql  # Requested, specifies the path to MySQL data persistent store.
    networks:
      - seafile-net

  memcached:
    image: memcached:1.5.6
    container_name: seafile-memcached
    restart: always
    entrypoint: memcached -m 256
    networks:
      - seafile-net

  seafile:
    image: seafileltd/seafile-mc:latest
    restart: always
    container_name: seafile
    ports:
      - "80:80"
#     - "443:443"  # If https is enabled, cancel the comment.
    volumes:
      - ./seafile-data:/shared   # Requested, specifies the path to Seafile data persistent store.
    environment:
      - DB_HOST=db
      - DB_ROOT_PASSWD=db_dev  # Requested, the value shuold be root's password of MySQL service.
      - TIME_ZONE=Etc/UTC  # Optional, default is UTC. Should be uncomment and set to your local time zone.
      - SEAFILE_ADMIN_EMAIL=me@your_email # Specifies Seafile admin user, default is 'me@example.com'.
      - SEAFILE_ADMIN_PASSWORD=your_seafile_password    # Specifies Seafile admin password, default is 'asecret'.
      - SEAFILE_SERVER_LETSENCRYPT=false   # Whether to use https or not.
      - SEAFILE_SERVER_HOSTNAME=#192.168.0.110 你要访问Seafile的IP地址或者域名 # Specifies your host name if https is enabled.
    depends_on:
      - db
      - memcached
    networks:
      - seafile-net

networks:
  seafile-net:
    #external: 
    #  name:  your_network_name # 如果你想使用已经存在的网络那么把这两句取消注释，并把对应的网络名称填在这里
```

### 3. 启动 Seafile 服务

执行以下命令启动 Seafile 服务

```
docker-compose up -d
```

需要等待几分钟，等容器首次启动时的初始化操作完成后，您就可以在浏览器上访问`http://自己设定的域名` 来打开 Seafile 主页。

**注意：您应该在** `docker-compose.yml` **文件所在的目下执行以上命令。**

## Seafile 用户使用文档

[https://cloud.seafile.com/published/seafile-user-manual/home.md](https://cloud.seafile.com/published/seafile-user-manual/home.md)

### 实际使用体验

- 内网无线传输速率可以大佬 21M/S 还是很可观的、有图有真相（手机与运行 Seafile 的笔记本全是无线）。

![QQ 图片 20200313121017.jpg](https://img.hacpai.com/file/2020/03/QQ%E5%9B%BE%E7%89%8720200313121017-c5fa0285.jpg)
