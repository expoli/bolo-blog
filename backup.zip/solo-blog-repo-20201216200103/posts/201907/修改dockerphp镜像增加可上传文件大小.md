title: 修改 docker php 镜像增加可上传文件大小
date: '2019-07-30 14:47:08'
updated: '2020-02-16 20:01:37'
tags: [Docker, PHP, 坑]
permalink: /articles/2019/07/30/1564656220499.html
---
![](https://img.hacpai.com/bing/20191107.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# 修改 docker php 镜像增加可上传文件大小

## 0. 修改原因

因为默认的 php 容器，的最大上传文件大小为 2M 所以完全满足不了我的需求

![2019-07-30-update-docker-php.ini.png](http://tc.expoli.tech/images/2019/07/30/2019-07-30-update-docker-php.ini.png)

## 1. 进入容器内部查看 php 的配置文件路径

```bash
docker exec -it chevereto /bin/bash
# whereis php
php: /usr/local/bin/php /usr/local/etc/php /usr/local/lib/php /usr/local/php

# /usr/local/bin/php --ini
Configuration File (php.ini) Path: /usr/local/etc/php
Loaded Configuration File:         (none)
Scan for additional .ini files in: /usr/local/etc/php/conf.d
Additional .ini files parsed:      /usr/local/etc/php/conf.d/docker-php-ext-exif.ini,
/usr/local/etc/php/conf.d/docker-php-ext-gd.ini,
/usr/local/etc/php/conf.d/docker-php-ext-mysqli.ini,
/usr/local/etc/php/conf.d/docker-php-ext-pdo_mysql.ini,
/usr/local/etc/php/conf.d/docker-php-ext-sodium.ini,
/usr/local/etc/php/conf.d/docker-php-ext-zip.ini
```

## 2. ini 配置文件路径

```bash
# 从上面的输出可以看出 ini 的文件路径为
Scan for additional .ini files in: /usr/local/etc/php/conf.d
```

## 3. 新建 upload.ini 文件

```php
post_max_size = 100M
upload_max_filesize = 100M
```

## 4. 将 upload.ini 挂载至容器内部

```yaml
version: '3'
services:
  chevereto:
  ......
  ......
  volumes:
    - ./upload.ini:/usr/local/etc/php/conf.d/upload.ini:ro
  ......
```

## 5. 重启容器、生效更改

```bash
docker-compose up -d
```

![2019-07-30-update-docker-php.ini1.png](http://tc.expoli.tech/images/2019/07/30/2019-07-30-update-docker-php.ini1.png)
