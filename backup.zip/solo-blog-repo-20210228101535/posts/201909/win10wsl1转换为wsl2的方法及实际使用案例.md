title: win10 wsl1 转换为 wsl2 的方法及实际使用案例
date: '2019-09-16 14:04:12'
updated: '2019-09-16 14:42:14'
tags: [Windows, WSL, Docker]
permalink: /articles/2019/09/16/1568613852218.html
---
![](https://img.hacpai.com/bing/20190202.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# win10 wsl1 转换为 wsl2 的方法及实际使用案例

## 0.WSL2(win10子系统二代)特殊优势：

- 彻底重构wls一代，速度比上一代快20%

- 支持原生Docker安装，启动（相当于完整的linux系统、虚拟机运行）

- 支持各种一键脚本，比如宝塔一键脚本、佰阅一键脚本等等

- win10文件管理器可访问linux系统文件

- 搭配vs code的插件vs remote可以超低延迟、急速开发基于linux系统的开发环境

- 其它优势。。。。

> 对于Docker，win10 `桌面版docker` 启动耗时大概一分钟左右，在 `wls2` 上，启动docker真的是一瞬间就完成。

## 1.WLS2 win10子系统安装方法(速度很快，一分钟不到)

若要安装并开始使用 WSL 2，请完成以下步骤：

1. 启用“虚拟机平台”可选组件

2. 使用命令行设置要由 WSL 2 支持的发行版

3. 验证发行版使用的 WSL 版本

> 请注意，需要运行 Windows 10 版本 `18917` 或更高版本才能使用 `WSL 2`，并且需要已安装 WSL（可在此处找到有关执行此操作的说明）。
> 
> 关于系统环境，可以到设置，更新与安装，windows预览体验计划，寻找快速版即可。等第一次更新系统后，可以切换到慢速版。否则快速版更新速度太频繁，影响正常工作。

### 1.1 启用“虚拟机平台”可选组件

1. 以 `管理员身份` 打开 PowerShell 并运行：

```bash
Enable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform
```

2. 需要 `重新启动计算机`，这些更改才能更好地生效

3. 查看现有地 WSL 

```bash
wsl -l -v

### 输出结果
PS C:\WINDOWS\system32> wsl -l -v
  NAME            STATE           VERSION
* Ubuntu-18.04    Stopped         1
```

4. 使用命令行将 WSL 1  的发行版转化为 WSL2、在 PowerShell 中运行：

```
wsl --set-version $已经使用的WSL的名字 2

### 输出结果
正在进行转换，这可能需要几分钟时间...
有关与 WSL 2 的主要区别的信息，请访问 https://aka.ms/wsl2
转换完成。
```

5. 此外，如果要使 WSL 2 成为你的默认体系结构，可以通过此命令执行该操作：

```bash
wsl --set-default-version 2

## 输出结果
有关与 WSL 2 的主要区别的信息，请访问 https://aka.ms/wsl2
```

6. 进行转换后的检测

```bash
 wsl -l -v

## 输出结果
  NAME            STATE           VERSION
* Ubuntu-18.04    Stopped         2
```

## 2. 实例之：Docker 安装

### 2.1 更新软件

```bash
sudo apt-get update
sudo apt-get upgrade -y
sudo apt autoremove
```

### 2.2 安装 docker 前准备

#### 2.2.1 卸载旧版本

```bash
sudo apt-get remove docker docker-engine docker.io containerd runc
```

#### 2.2.2 安装依赖使 apt 能够使用基于 https 的仓库

```
sudo apt-get install \
    apt-transport-https \
    ca-certificates \
    curl \
    gnupg-agent \
    software-properties-common -y
```

#### 2.2.3 添加 docker 的离线 gpg key

```
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -
```

#### 2.2.4 验证 key 的信息

```
 sudo apt-key fingerprint 0EBFCD88
    
pub   rsa4096 2017-02-22 [SCEA]
      9DC8 5822 9FC7 DD38 854A  E2D8 8D81 803C 0EBF CD88
uid           [ unknown] Docker Release (CE deb) <docker@docker.com>
sub   rsa4096 2017-02-22 [S]
```

#### 2.2.5 设置 docker 各版本的安装源（此处是 stable 版本）

To add the **nightly** or **test** repository, add the word `nightly` or `test` (or both) after the word `stable` in the commands below.

```
sudo add-apt-repository \
   "deb [arch=amd64] https://download.docker.com/linux/ubuntu \
   $(lsb_release -cs) \
   stable"
```

### 2.3 开始安装 docker

#### 2.3.1 更新软件目录

```
sudo apt-get update
```

#### 2.3.2 安装最新版本的 docker

```
sudo apt-get install docker-ce docker-ce-cli containerd.io -y
```

#### 2.3.3 启动测试

```
# 启动 docker 守护进程
sudo service docker start
# 运行测试
sudo docker run hello-world
```

### 2.4 免sudo使用docker命令

原文章：https://expoli.tech/articles/2019/07/27/1564656218673.html

#### 2.4.1 背景

相信大家在一台新机器上面安装 docker 时候、都会发现docker 在安装完成之后、如果你想直接使用使用 docker 命令来运行docker 相关的操作、会爆出类似于下面的错误。

```bash
Got permission denied while trying to connect to the Docker daemon socket at unix:///var/run/docker.sock: Get http://%2Fvar%2Frun%2Fdocker.sock/v1.26/images/json: dial unix /var/run/docker.sock: connect: permission denied

```

报错显示权限不够、那么如何解决这个问题呢？

官方文档给出了解决方案，那就是将你添加到 `docker` 这个用户组里面即可。

* 如果还没有 docker group 就添加一个：

```bash
sudo groupadd docker
```

* 将相应的用户加入该 `group` 内。然后退出并重新登录就生效啦。

```bash
sudo gpasswd -a ${USER} docker
```

* 重启 docker 服务

```bash
sudo service docker restart
```

* 切换当前会话到新 group 或者重启 X 会话

```
newgrp - docker
```

现在配置就完成了、可以免 sudo 使用，docker 命令了。
