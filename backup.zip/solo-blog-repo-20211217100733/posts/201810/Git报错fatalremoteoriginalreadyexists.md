title: Git 报错 'fatal:remote origin already exists'
date: '2018-10-26 12:35:08'
updated: '2018-10-26 12:35:08'
tags: [Git]
permalink: /articles/2018/10/26/1564656233578.html
---
![image.md.png](./18-10-26-git-report-error-1/image.md.png)

## git报错：`'fatal:remote origin already exists'` 怎么处理？

<!-- more -->

### 解决方案

* 1、先删除
```bash
$ git remote rm origin
```
* 2、再次执行添加就可以了
```bash
$ git remote add # 你的仓库地址
```