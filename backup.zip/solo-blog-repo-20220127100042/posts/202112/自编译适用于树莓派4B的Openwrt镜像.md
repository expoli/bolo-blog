title: 自编译适用于树莓派4B的Openwrt镜像
date: '2021-12-15 18:31:04'
updated: '2021-12-15 21:03:37'
tags: [Openwrt]
permalink: /articles/2021/12/15/1639564263986.html
---
![openwrtraspberrypi.png](https://oss.expoli.tech/img/fp5_openwrt-raspberry-pi.png)

原来一直都在使用 [https://github.com/SuLingGG/OpenWrt-Rpi](https://github.com/SuLingGG/OpenWrt-Rpi) 的镜像，但是不知道因为什么，在使用该镜像的时候，系统总是莫明其妙的间隔一段时间就会重启，排查的一圈也没有找到具体的问题，在自己尝试使用官方原版镜像的时候，发现好像是因为网卡驱动问题，导致网卡工作不正常，具体表现为断流（ping 都无法正常工作）。

而在最近一次使用命令 `opkg list-upgradable | cut -f 1 -d ' ' | xargs -r opkg upgrade` 更新全部系统包的时候，导致系统崩溃，首先是 `wget-ssl` 包，出现`Error relocating /usr/bin/wget-ssl: reallocarray: symbol not found`的错误，通过降级 `wget-ssl` 得到解决；但是后续更新的时候发现 `luci` 出错，而且无法通过 cli 进行固件更新，嘶~头皮发麻。稳定性堪忧，而且最近这个项目还把 `issue` 关闭，简直了。

于是准备自编译固件镜像。

# 自编译 Openwrt 镜像

## 前提准备

### 1. 查询树莓派的官方固件支持情况。

[https://openwrt.org/toh/hwdata/raspberry_pi_foundation/raspberry_pi_foundation_raspberry_pi_4_b](https://openwrt.org/toh/hwdata/raspberry_pi_foundation/raspberry_pi_foundation_raspberry_pi_4_b)

得到CPU型号为 `Broadcom BCM2711`

### 2. 下载对应的 `image-builder`

https://downloads.openwrt.org/releases/21.02.1/targets/bcm27xx/bcm2711/

![image.png](https://oss.expoli.tech/img/DZh_image.png)

### 3. 解压压缩包并查看构建帮助

```bash
tcy@tcy ~/D/openwrt-imagebuilder-21.02.1-bcm27xx-bcm2711.Linux-x86_64> make info
Current Target: "bcm27xx/bcm2711"
Current Revision: "r16325-88151b8303"
Default Packages: base-files ca-bundle dropbear fstools libc libgcc libustream-wolfssl logd mtd netifd opkg uci uclient-fetch urandom-seed busybox procd bcm27xx-gpu-fw kmod-usb-hid kmod-sound-core kmod-sound-arm-bcm2835 kmod-fs-vfat kmod-nls-cp437 kmod-nls-iso8859-1 partx-utils mkf2fs e2fsprogs dnsmasq firewall ip6tables iptables kmod-ipt-offload odhcp6c odhcpd-ipv6only ppp ppp-mod-pppoe
Available Profiles:

rpi-4:
    Raspberry Pi 4B/400/4CM (64bit)
    Packages: cypress-firmware-43455-sdio cypress-nvram-43455-sdio-rpi-4b kmod-brcmfmac wpad-basic-wolfssl iwinfo
    hasImageMetadata: 1
    SupportedDevices: raspberrypi,400 raspberrypi,4-compute-module raspberrypi,4-model-b

```

### 5. 开始构建镜像

考虑到可能是因为驱动问题导致网络不稳定，所以在这里加入了 `kmod-rtl8187 kmod-rtl8192c-common kmod-rtl8192cu kmod-rtlwifi kmod-rtlwifi-usb kmod-usb-net-rtl8150 kmod-usb-net-rtl8152` 这些内核模块，目前外置USB网卡也稳定运行、效果不错。

```bash
make image  PACKAGES="kmod-rtl8187 kmod-rtl8192c-common kmod-rtl8192cu kmod-rtlwifi kmod-rtlwifi-usb kmod-usb-net-rtl8150 kmod-usb-net-rtl8152 luci"
```

### 6. 刷入新镜像

![image.png](https://oss.expoli.tech/img/pCu_image.png)
